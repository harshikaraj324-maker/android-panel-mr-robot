package com.example.admin.views

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class GraphView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // ── Mode ──────────────────────────────────────────────────────────────────
    enum class Mode { RECEIVE, SEND }

    private var mode = Mode.RECEIVE

    /**
     * Call this from DeviceActivity:
     *   sentGraph.setMode(GraphView.Mode.SEND)
     *   receivedGraph.setMode(GraphView.Mode.RECEIVE)
     */
    fun setMode(newMode: Mode) {
        if (mode == newMode) return
        mode = newMode
        applyModeColors()
        rebuildShader()
        invalidate()
    }

    // ── Palette per mode ──────────────────────────────────────────────────────
    // RECEIVE → cyan  (#00E5FF)
    // SEND    → orange (#FF6D00)

    private var colorMain = Color.parseColor("#00E5FF")
    private var colorGlow = Color.parseColor("#00BCD4")

    private val maxPoints = 40
    private val values    = mutableListOf<Float>()

    // Grid lines — very subtle
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.argb(25, 0, 220, 255)
        strokeWidth = 1f
        style       = Paint.Style.STROKE
        pathEffect  = DashPathEffect(floatArrayOf(8f, 8f), 0f)
    }

    // Outer glow (blurred wide stroke)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.argb(55, 0, 229, 255)
        strokeWidth = 10f
        style       = Paint.Style.STROKE
        strokeCap   = Paint.Cap.ROUND
        strokeJoin  = Paint.Join.ROUND
        maskFilter  = BlurMaskFilter(12f, BlurMaskFilter.Blur.NORMAL)
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = colorMain
        strokeWidth = 2.2f
        style       = Paint.Style.STROKE
        strokeCap   = Paint.Cap.ROUND
        strokeJoin  = Paint.Join.ROUND
    }

    private var fillShader: LinearGradient? = null
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val dotRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = colorMain
        strokeWidth = 2f
        style       = Paint.Style.STROKE
    }

    private val curvePath = Path()
    private val fillPath  = Path()

    // ── Apply colors from current mode ────────────────────────────────────────
    private fun applyModeColors() {
        when (mode) {
            Mode.RECEIVE -> {
                colorMain = Color.parseColor("#00E5FF")
                colorGlow = Color.parseColor("#00BCD4")
                glowPaint.color   = Color.argb(55, 0, 229, 255)
                gridPaint.color   = Color.argb(25, 0, 220, 255)
                strokePaint.color = colorMain
                dotRingPaint.color = colorMain
            }
            Mode.SEND -> {
                colorMain = Color.parseColor("#FF6D00")
                colorGlow = Color.parseColor("#E65100")
                glowPaint.color   = Color.argb(70, 255, 109, 0)
                gridPaint.color   = Color.argb(25, 255, 109, 0)
                strokePaint.color = colorMain
                dotRingPaint.color = colorMain
            }
        }
    }

    // ── Rebuild gradient fill for current size + mode ─────────────────────────
    private fun rebuildShader() {
        if (height == 0) return
        fillShader = when (mode) {
            Mode.RECEIVE -> LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(Color.argb(130, 0, 229, 255), Color.argb(0, 0, 180, 212)),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
            Mode.SEND -> LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(Color.argb(130, 255, 109, 0), Color.argb(0, 230, 81, 0)),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        fillPaint.shader = fillShader
    }

    // ── Tick: smooth random walk every 800 ms ────────────────────────────────
    private val updateRunnable = object : Runnable {
        override fun run() {
            if (height == 0) { postDelayed(this, 500); return }

            val pad   = height * 0.10f
            val last  = if (values.isEmpty()) height * 0.5f else values.last()
            val delta = (Math.random() * height * 0.32 - height * 0.16).toFloat()
            val next  = (last + delta).coerceIn(pad, height - pad)

            if (values.size >= maxPoints) values.removeAt(0)
            values.add(next)

            invalidate()
            postDelayed(this, 800)
        }
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)   // required for BlurMaskFilter
        applyModeColors()
        post(updateRunnable)
    }

    // ── Rebuild gradient whenever view size changes ───────────────────────────
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildShader()
    }

    // ── Draw ──────────────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.size < 2) return

        val w = width.toFloat()
        val h = height.toFloat()

        val stepX = w / (values.size - 1)

        // Subtle grid lines
        canvas.drawLine(0f, h * 0.25f, w, h * 0.25f, gridPaint)
        canvas.drawLine(0f, h * 0.50f, w, h * 0.50f, gridPaint)
        canvas.drawLine(0f, h * 0.75f, w, h * 0.75f, gridPaint)

        buildCurve(stepX, w, h)

        // Fill → glow → stroke
        canvas.drawPath(fillPath,  fillPaint)
        canvas.drawPath(curvePath, glowPaint)
        canvas.drawPath(curvePath, strokePaint)

        // Live pulse dot at rightmost (latest) point
        val tipX = (values.size - 1) * stepX
        val tipY = values.last()
        canvas.drawCircle(tipX, tipY, 5f, dotPaint)
        canvas.drawCircle(tipX, tipY, 5f, dotRingPaint)
    }

    // ── Cubic bezier through all points ──────────────────────────────────────
    private fun buildCurve(stepX: Float, w: Float, h: Float) {
        curvePath.reset()
        fillPath.reset()

        val pts = values
        curvePath.moveTo(0f, pts[0])

        for (i in 1 until pts.size) {
            val x0  = (i - 1) * stepX
            val y0  = pts[i - 1]
            val x1  = i * stepX
            val y1  = pts[i]
            val cx0 = x0 + stepX / 3f
            val cx1 = x1 - stepX / 3f
            curvePath.cubicTo(cx0, y0, cx1, y1, x1, y1)
        }

        // Close fill to bottom edge
        fillPath.addPath(curvePath)
        val lastX = (pts.size - 1) * stepX
        fillPath.lineTo(lastX, h)
        fillPath.lineTo(0f, h)
        fillPath.close()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(updateRunnable)
    }
}
