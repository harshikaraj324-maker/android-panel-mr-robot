package com.example.admin.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.admin.R
import com.example.admin.core.ExpiryManager
import com.example.admin.core.SessionManager
import com.example.admin.utils.Constants
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LogicActivity : AppCompatActivity() {

    private val ADMIN_ID get() = Constants.APP_TOKEN

    private var isActivityInitialized = false

    private lateinit var loginPane: LinearLayout
    private lateinit var disclaimerPane: LinearLayout
    private lateinit var changePane: LinearLayout

    private lateinit var etAdminId: EditText
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etPassword: EditText
    private lateinit var btnLoginTv: MaterialTextView
    private lateinit var btnSkipTv: MaterialTextView
    private lateinit var btnChangeFromDisclaimerTv: MaterialTextView
    private lateinit var btnLogoutAll: MaterialTextView

    private lateinit var tilCurrentPassword: TextInputLayout
    private lateinit var etCurrentPassword: EditText
    private lateinit var tilNewPassword: TextInputLayout
    private lateinit var etNewPassword: EditText
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSaveTv: MaterialTextView
    private lateinit var btnCancelTv: MaterialTextView
    private lateinit var progress: CircularProgressIndicator

    private lateinit var deviceId: String
    private val expiry = ExpiryManager()
    @Volatile private var expiryNotified = false

    // Firebase — kept only for the global "logout all" broadcast signal
    private lateinit var rootRef: DatabaseReference
    private var logoutListener: ValueEventListener? = null

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Session polling (every 30 s) ─────────────────────────────────────────
    private val SESSION_POLL_MS = 30_000L
    private val sessionPollRunnable = object : Runnable {
        override fun run() {
            if (!isLoggedInNow()) return
            scope.launch { checkSessionFromBackend() }
            mainHandler.postDelayed(this, SESSION_POLL_MS)
        }
    }

    // ── Ping last_active (every 5 min) ────────────────────────────────────────
    private val SESSION_PING_MS = 5 * 60_000L
    private val sessionPingRunnable = object : Runnable {
        override fun run() {
            if (!isLoggedInNow()) return
            scope.launch { pingSession() }
            mainHandler.postDelayed(this, SESSION_PING_MS)
        }
    }

    private enum class Pane { LOGIN, DISCLAIMER, CHANGE }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logic)

        Constants.init(this)

        if (!Constants.isConfigured()) {
            showTokenSetupDialog()
            return
        }

        initActivity()
    }

    override fun onStart() {
        super.onStart()
        if (!isActivityInitialized) return
        subscribeLogoutSignal()
        if (isLoggedInNow()) startSessionMonitoring()
    }

    override fun onStop() {
        super.onStop()
        if (!isActivityInitialized) return
        stopSessionMonitoring()
        logoutListener?.let { rootRef.child("control").child("logoutAllAt").removeEventListener(it) }
        logoutListener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        expiry.stopRuntimeGuards()
        scope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
    }

    // ── Safe JSON parser ─────────────────────────────────────────────────────
    // Prevents "end of input at character 0" when server returns empty body
    // or a non-JSON response (e.g. 404 HTML page).
    private fun safeJson(raw: String?): JSONObject {
        if (raw.isNullOrBlank()) return JSONObject()
        return try {
            JSONObject(raw)
        } catch (_: Exception) {
            JSONObject()
        }
    }

    // ── Token setup dialog ───────────────────────────────────────────────────

    private fun showTokenSetupDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_app_id_setup, null)
        val etAppId = dialogView.findViewById<EditText>(R.id.etAppId)
        val tvError = dialogView.findViewById<TextView>(R.id.tvAppIdError)
        val btnSave = dialogView.findViewById<TextView>(R.id.btnSaveAppId)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnSave.setOnClickListener {
            val token = etAppId.text.toString().trim().uppercase()
            when {
                token.isBlank() -> {
                    tvError.text = "App Token cannot be empty"
                    tvError.visibility = View.VISIBLE
                }
                !token.contains("-") || !token.contains("@") -> {
                    tvError.text = "Invalid format. Example: LION-LASER-Q3SV@A7S"
                    tvError.visibility = View.VISIBLE
                }
                else -> {
                    tvError.visibility = View.INVISIBLE
                    Constants.saveToken(this, token)
                    dialog.dismiss()
                    initActivity()
                }
            }
        }

        dialog.show()
    }

    // ── Initialisation ───────────────────────────────────────────────────────

    private fun initActivity() {
        // Re-validate token in case it was lost between onCreate and initActivity
        Constants.init(this)
        if (!Constants.isConfigured()) {
            showTokenSetupDialog()
            return
        }
        FirebaseApp.initializeApp(this)
        val database = FirebaseDatabase.getInstance(
            "https://master-controll-bead1-default-rtdb.firebaseio.com/"
        )
        rootRef = database.reference
        deviceId = SessionManager.getDeviceId(this)

        bindViews()
        wireClicks()
        setupExpiryManager()

        etAdminId.setText(ADMIN_ID)

        isActivityInitialized = true
        subscribeLogoutSignal()

        if (isLoggedInNow()) {
            verifySessionFromBackend()
        } else {
            showPane(Pane.LOGIN)
        }
    }

    private fun bindViews() {
        loginPane                 = findViewById(R.id.loginPane)
        disclaimerPane            = findViewById(R.id.disclaimerPane)
        changePane                = findViewById(R.id.changePane)
        etAdminId                 = findViewById(R.id.etAdminId)
        tilPassword               = findViewById(R.id.tilPassword)
        etPassword                = findViewById(R.id.etPassword)
        btnLoginTv                = findViewById(R.id.btnLoginTv)
        btnSkipTv                 = findViewById(R.id.btnSkipTv)
        btnChangeFromDisclaimerTv = findViewById(R.id.btnChangeFromDisclaimerTv)
        btnLogoutAll              = findViewById(R.id.btnLogoutAll)
        tilCurrentPassword        = findViewById(R.id.tilCurrentPassword)
        etCurrentPassword         = findViewById(R.id.etCurrentPassword)
        tilNewPassword            = findViewById(R.id.tilNewPassword)
        etNewPassword             = findViewById(R.id.etNewPassword)
        tilConfirmPassword        = findViewById(R.id.tilConfirmPassword)
        etConfirmPassword         = findViewById(R.id.etConfirmPassword)
        btnSaveTv                 = findViewById(R.id.btnSaveTv)
        btnCancelTv               = findViewById(R.id.btnCancelTv)
        progress                  = findViewById(R.id.progress)
    }

    private fun wireClicks() {
        btnLoginTv.setOnClickListener { performLogin() }
        etPassword.setOnEditorActionListener { _, _, _ -> performLogin(); true }

        btnSkipTv.setOnClickListener {
            startActivity(Intent(this, DeviceActivity::class.java))
            finish()
        }
        btnChangeFromDisclaimerTv.setOnClickListener { showPane(Pane.CHANGE) }
        btnLogoutAll.setOnClickListener { showLogoutAllConfirmation() }

        btnSaveTv.setOnClickListener { updatePassword() }
        btnCancelTv.setOnClickListener {
            clearChangeErrors()
            showPane(Pane.DISCLAIMER)
        }
    }

    private fun setupExpiryManager() {
        expiry.ensureWindow30DaysIfMissing(onDone = {
            expiry.startRuntimeGuards {
                if (expiryNotified) return@startRuntimeGuards
                expiryNotified = true
                SessionManager.setLoggedIn(this, false)
                runOnUiThread {
                    setLoading(false)
                    clearInputs()
                    toast("Access expired. Please login again.")
                    showPane(Pane.LOGIN)
                }
                expiry.stopRuntimeGuards()
            }
        })
    }

    // ── Backend session management ────────────────────────────────────────────

    /**
     * Called on app start when SharedPrefs says we're logged in.
     * Asks the backend if the stored session_id is still valid.
     */
    private fun verifySessionFromBackend() {
        val sessionId = SessionManager.getSessionId(this)
        if (sessionId < 0L) {
            // No stored session — show login
            SessionManager.setLoggedIn(this, false)
            showPane(Pane.LOGIN)
            return
        }
        setLoading(true)
        scope.launch {
            val valid = withContext(Dispatchers.IO) { isSessionValid(sessionId) }
            setLoading(false)
            if (!isActivityAlive()) return@launch
            if (valid) {
                showPane(Pane.DISCLAIMER)
                startSessionMonitoring()
            } else {
                SessionManager.setLoggedIn(this@LogicActivity, false)
                toast("Session expired. Please login again.")
                showPane(Pane.LOGIN)
            }
        }
    }

    /**
     * Background check — fires on every poll tick.
     * Forces logout when session is invalidated from the admin panel.
     */
    private suspend fun checkSessionFromBackend() {
        val sessionId = SessionManager.getSessionId(this)
        if (sessionId < 0L) return
        val valid = withContext(Dispatchers.IO) { isSessionValid(sessionId) }
        if (!valid && isLoggedInNow()) {
            withContext(Dispatchers.Main) {
                if (!isActivityAlive()) return@withContext
                SessionManager.setLoggedIn(this@LogicActivity, false)
                stopSessionMonitoring()
                toast("Your session was terminated remotely.")
                showPane(Pane.LOGIN)
            }
        }
    }

    private suspend fun pingSession() {
        val sessionId = SessionManager.getSessionId(this)
        if (sessionId < 0L) return
        withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder()
                    .url("${Constants.DEVICE_API_BASE_URL}/session/$sessionId/ping")
                    .post("{}".toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { }
            } catch (_: Exception) { }
        }
    }

    /**
     * Returns true if the backend says this session is still valid.
     * Uses safeJson() so empty or HTML error bodies never crash the app.
     */
    private fun isSessionValid(sessionId: Long): Boolean {
        return try {
            val req = Request.Builder()
                .url("${Constants.DEVICE_API_BASE_URL}/session/$sessionId/check")
                .get()
                .build()
            http.newCall(req).execute().use { resp ->
                val json = safeJson(resp.body?.string())
                json.optBoolean("valid", false)
            }
        } catch (_: Exception) {
            // Network error → assume still valid (don't log out on connectivity blip)
            true
        }
    }

    private fun startSessionMonitoring() {
        mainHandler.removeCallbacks(sessionPollRunnable)
        mainHandler.removeCallbacks(sessionPingRunnable)
        mainHandler.postDelayed(sessionPollRunnable, SESSION_POLL_MS)
        mainHandler.postDelayed(sessionPingRunnable, SESSION_PING_MS)
    }

    private fun stopSessionMonitoring() {
        mainHandler.removeCallbacks(sessionPollRunnable)
        mainHandler.removeCallbacks(sessionPingRunnable)
    }

    // ── Firebase — global logout-all broadcast (optional fallback) ────────────

    private fun subscribeLogoutSignal() {
        if (logoutListener != null) return
        val node = rootRef.child("control").child("logoutAllAt")
        logoutListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ts = snapshot.getValue(Long::class.java) ?: return
                val lastSeen = SessionManager.getLastLogoutSeen(this@LogicActivity)
                if (ts > lastSeen) {
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    SessionManager.setLastLogoutSeen(this@LogicActivity, ts)
                    stopSessionMonitoring()
                    toast("You have been logged out from all devices")
                    showPane(Pane.LOGIN)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        node.addValueEventListener(logoutListener as ValueEventListener)
    }

    // ── Login — calls backend, stores session_id ─────────────────────────────

    private fun performLogin() {
        // Safety: if token was lost (e.g. app data partial clear), re-show setup dialog
        if (!Constants.isConfigured()) {
            toast("App Token missing. Please re-enter.")
            showTokenSetupDialog()
            return
        }

        val password = etPassword.text?.toString()?.trim().orEmpty()
        if (password.isEmpty()) { tilPassword.error = "Password required"; return }
        tilPassword.error = null

        expiry.readStatusOnce { st ->
            if (st.isExpiredNow()) {
                tilPassword.error = "Access expired"
                toast("Access expired")
                return@readStatusOnce
            }
            setLoading(true)
            scope.launch {
                val result = callAdminLoginWithRetry(password)
                withContext(Dispatchers.Main) {
                    setLoading(false)
                    if (result.ok) performSuccessfulLogin(result.sessionId)
                    else {
                        tilPassword.error = result.error ?: "Invalid password"
                        toast(result.error ?: "Invalid password")
                    }
                }
            }
        }
    }

    // Retries up to 3 times on network errors (hostname/timeout).
    // Does NOT retry on 401 wrong-password — that is an auth error, not a network error.
    private suspend fun callAdminLoginWithRetry(password: String): ApiResult {
        val maxAttempts = 3
        val retryDelayMs = 2000L
        var lastError = "Login failed"
        for (attempt in 1..maxAttempts) {
            if (attempt > 1) {
                withContext(Dispatchers.Main) {
                    toast("Network issue. Retrying ($attempt/$maxAttempts)...")
                }
                kotlinx.coroutines.delay(retryDelayMs)
            }
            val result = callAdminLogin(password)
            when {
                // Success — done
                result.ok -> return result
                // Auth error (wrong password, expired, disabled) — stop retrying immediately
                result.isAuthError -> return result
                // Network error — will retry
                else -> lastError = result.error ?: "Connection failed"
            }
        }
        return ApiResult(ok = false, error = "No network after $maxAttempts attempts. Check your connection and try again.")
    }

    private suspend fun callAdminLogin(password: String): ApiResult = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
                .put("password", password)
                .put("sub_id", deviceId)
                .toString()
                .toRequestBody("application/json".toMediaType())
            val req = Request.Builder()
                .url("${Constants.DEVICE_API_BASE_URL}/admin-login")
                .post(body)
                .build()
            val resp = http.newCall(req).execute()
            val json = safeJson(resp.body?.string())
            if (resp.isSuccessful && json.optBoolean("ok", false)) {
                val sid = json.optLong("session_id", -1L)
                ApiResult(ok = true, sessionId = sid)
            } else {
                // 401 = auth error (wrong password), others = network/server error
                val isAuth = resp.code == 401 || resp.code == 403
                ApiResult(ok = false, error = json.optString("error", "Invalid password"), isAuthError = isAuth)
            }
        } catch (e: java.net.UnknownHostException) {
            ApiResult(ok = false, error = "Unable to reach server. Check internet.", isAuthError = false)
        } catch (e: java.net.SocketTimeoutException) {
            ApiResult(ok = false, error = "Connection timed out.", isAuthError = false)
        } catch (e: Exception) {
            ApiResult(ok = false, error = "Connection error: ${e.message}", isAuthError = false)
        }
    }

    private fun performSuccessfulLogin(sessionId: Long) {
        SessionManager.setLoggedIn(this, true)
        if (sessionId >= 0L) SessionManager.setSessionId(this, sessionId)
        toast("Login successful")
        startSessionMonitoring()
        startActivity(Intent(this, DeviceActivity::class.java))
        finish()
    }

    // ── Change password ───────────────────────────────────────────────────────

    private fun updatePassword() {
        val currentPw = etCurrentPassword.text?.toString()?.trim().orEmpty()
        val newPw     = etNewPassword.text?.toString()?.trim().orEmpty()
        val confirmPw = etConfirmPassword.text?.toString()?.trim().orEmpty()
        clearChangeErrors()

        if (currentPw.isEmpty()) { tilCurrentPassword.error = "Current password required"; return }
        if (newPw.length < 4)    { tilNewPassword.error = "Minimum 4 characters"; return }
        if (newPw != confirmPw)  { tilConfirmPassword.error = "Passwords do not match"; return }

        setLoading(true)
        scope.launch {
            val result = callChangePassword(currentPw, newPw)
            withContext(Dispatchers.Main) {
                setLoading(false)
                if (result.ok) {
                    toast("Password updated successfully")
                    clearInputs()
                    showPane(Pane.DISCLAIMER)
                } else {
                    tilCurrentPassword.error = result.error ?: "Failed to change password"
                    toast(result.error ?: "Failed to change password")
                }
            }
        }
    }

    private suspend fun callChangePassword(oldPw: String, newPw: String): ApiResult = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
                .put("old_password", oldPw)
                .put("new_password", newPw)
                .toString()
                .toRequestBody("application/json".toMediaType())
            val req = Request.Builder()
                .url("${Constants.DEVICE_API_BASE_URL}/admin-change-password")
                .post(body)
                .build()
            val resp = http.newCall(req).execute()
            val json = safeJson(resp.body?.string())
            if (resp.isSuccessful && json.optBoolean("ok", false)) ApiResult(ok = true)
            else ApiResult(ok = false, error = json.optString("error", "Failed to change password"))
        } catch (e: Exception) {
            ApiResult(ok = false, error = "Connection error: ${e.message}")
        }
    }

    // ── Logout all devices ────────────────────────────────────────────────────

    private fun showLogoutAllConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout All Devices")
            .setMessage("This will logout ALL logged-in instances. Continue?")
            .setPositiveButton("Yes, Logout All") { _, _ -> performLogoutAll() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun performLogoutAll() {
        setLoading(true)
        scope.launch {
            withContext(Dispatchers.IO) {
                // Invalidate all sessions in Supabase via backend
                try {
                    val req = Request.Builder()
                        .url("${Constants.DEVICE_API_BASE_URL.trimEnd('/')
                            .replace("/api/device/${Constants.APP_TOKEN}", "")}/api/admin/sessions/app/${Constants.APP_TOKEN}/all")
                        .delete()
                        .build()
                    http.newCall(req).execute().use { }
                } catch (_: Exception) { }

                // Also fire Firebase signal so other open instances also logout
                try {
                    rootRef.child("control").child("logoutAllAt")
                        .setValue(com.google.firebase.database.ServerValue.TIMESTAMP)
                } catch (_: Exception) { }
            }
            withContext(Dispatchers.Main) {
                if (!isActivityAlive()) return@withContext
                SessionManager.setLoggedIn(this@LogicActivity, false)
                stopSessionMonitoring()
                setLoading(false)
                toast("All sessions logged out")
                clearInputs()
                showPane(Pane.LOGIN)
            }
        }
    }

    private fun showPane(which: Pane) {
        loginPane.visibility      = if (which == Pane.LOGIN)      View.VISIBLE else View.GONE
        disclaimerPane.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
        changePane.visibility     = if (which == Pane.CHANGE)     View.VISIBLE else View.GONE
        btnLogoutAll.visibility   = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
        if (which == Pane.LOGIN) etPassword.text?.clear()
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility                 = if (loading) View.VISIBLE else View.GONE
        btnLoginTv.isEnabled                = !loading
        btnSkipTv.isEnabled                 = !loading
        btnChangeFromDisclaimerTv.isEnabled = !loading
        btnLogoutAll.isEnabled              = !loading
        btnSaveTv.isEnabled                 = !loading
        btnCancelTv.isEnabled               = !loading
    }

    private fun clearInputs() {
        etPassword.text?.clear()
        etCurrentPassword.text?.clear()
        etNewPassword.text?.clear()
        etConfirmPassword.text?.clear()
        tilPassword.error = null
        clearChangeErrors()
    }

    private fun clearChangeErrors() {
        tilCurrentPassword.error = null
        tilNewPassword.error     = null
        tilConfirmPassword.error = null
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun isLoggedInNow() = SessionManager.isLoggedIn(this)

    private fun isActivityAlive() = !isDestroyed && !isFinishing

    private data class ApiResult(
        val ok: Boolean,
        val error: String? = null,
        val sessionId: Long = -1L,
        val isAuthError: Boolean = true   // true = wrong password (don't retry), false = network error (retry)
    )
}
