package com.example.admin.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.admin.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "MyFirebaseMsgSvc"
        private const val CHANNEL_ID = "default_channel_id"

        fun testLogs(context: Context) {
            Log.d(TAG, " FCM Test Log from ${context.packageName}")
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, " MyFirebaseMessagingService STARTED")
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "🔑 Refreshed FCM Token: $token")

        // 👉 Tum yahan token ko apne server ya Firebase Database me bhej sakte ho
        sendTokenToServer(token)
    }

    private fun sendTokenToServer(token: String) {
        // TODO: Apna server API call karo ya Firebase Realtime Database / Firestore me store karo
        Log.d(TAG, "📤 Sending token to server: $token")
    }

    // 🔹 Jab FCM se message aaye
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        Log.d(TAG, "📩 From: ${remoteMessage.from}")
        remoteMessage.notification?.body?.let {
            Log.d(TAG, "📩 Notification Body: $it")
            showNotification(it)
        }
    }

    private fun showNotification(messageBody: String) {
        createNotificationChannel()

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // apna icon lagao
            .setContentTitle("New Message")
            .setContentText(messageBody)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = NotificationManagerCompat.from(this)

        try {
            // ✅ Android 13+ requires POST_NOTIFICATIONS permission
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    Log.w(TAG, "❌ Notification permission not granted, skipping notification")
                    return
                }
            }

            notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())

        } catch (se: SecurityException) {
            Log.e(TAG, "⚠️ Notification failed: ${se.message}")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Default Channel"
            val descriptionText = "General Notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }

            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
