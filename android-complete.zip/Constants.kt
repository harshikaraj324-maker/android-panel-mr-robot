package com.example.admin.utils

import android.content.Context


object Constants {

    private const val PREF              = "app_constants_prefs"
    private const val KEY_TOKEN         = "app_token"
    private const val DEFAULT_APP_TOKEN = "LION-LASER-Q3SV@A7S"

    const val BACKEND_ROOT = "https://android-panel-mr-robot.pages.dev"

    // Always starts with the default so APP_TOKEN is never blank (even before init())
    private var _appToken: String = DEFAULT_APP_TOKEN

    val APP_TOKEN: String
        get() = if (_appToken.isNotBlank()) _appToken else DEFAULT_APP_TOKEN

    val DEVICE_API_BASE_URL: String
        get() = "$BACKEND_ROOT/api/device/$APP_TOKEN"

    val TABLE_NAME: String
        get() = APP_TOKEN

    fun init(context: Context) {
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "")?.trim() ?: ""
        _appToken = if (saved.isNotBlank()) saved else DEFAULT_APP_TOKEN
        // Auto-restore: if prefs was empty/missing, save the default back so it never gets lost
        if (saved.isBlank()) {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY_TOKEN, _appToken).apply()
        }
    }

    fun saveToken(context: Context, token: String) {
        _appToken = token.trim().takeIf { it.isNotBlank() } ?: DEFAULT_APP_TOKEN
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_TOKEN, _appToken).apply()
    }

    fun isConfigured(): Boolean = APP_TOKEN.isNotBlank()

    fun clear(context: Context) {
        // Reset to default instead of empty — token should never be lost
        _appToken = DEFAULT_APP_TOKEN
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_TOKEN, DEFAULT_APP_TOKEN).apply()
    }
}
