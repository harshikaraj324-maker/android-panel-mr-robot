package com.example.admin.utils

import android.content.Context

object Constants {

    private const val PREF      = "app_constants_prefs"
    private const val KEY_TOKEN = "app_token"

    // Backend root is XOR-obfuscated — no plain-text domain in the binary.
    private val E = intArrayOf(
        0x25, 0x06, 0x26, 0x40, 0x11, 0x0A, 0x5B, 0x6E, 0x05, 0x03,
        0x55, 0x1C, 0x24, 0x5A, 0x1D, 0x0C, 0x3D, 0x13, 0x3C, 0x55,
        0x0E, 0x1D, 0x19, 0x33, 0x49, 0x1F, 0x5E, 0x0C, 0x24, 0x47,
        0x57, 0x51, 0x2C, 0x15, 0x37, 0x43, 0x4C, 0x54, 0x11, 0x37
    )
    private val K = charArrayOf(
        '\u004D', '\u0072', '\u0052', '\u0030', '\u0062', '\u0030',
        '\u0074', '\u0041', '\u0064', '\u006D', '\u0031', '\u006E',
        '\u004B', '\u0033', '\u0079', '\u0021'
    )

    private fun r(): String = buildString {
        E.forEachIndexed { i, b -> append((b xor K[i % K.size].code).toChar()) }
    }

    val BACKEND_ROOT: String get() = r()

    private var _appToken: String = ""

    val APP_TOKEN: String
        get() = _appToken

    val DEVICE_API_BASE_URL: String
        get() = "\${r()}/api/device/\$APP_TOKEN"

    val TABLE_NAME: String
        get() = APP_TOKEN

    fun init(context: Context) {
        _appToken = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "")?.trim() ?: ""
    }

    fun saveToken(context: Context, token: String) {
        _appToken = token.trim()
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_TOKEN, _appToken).apply()
    }

    fun isConfigured(): Boolean = _appToken.isNotBlank()

    fun clear(context: Context) {
        _appToken = ""
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
