package com.example.admin.web

import android.webkit.JavascriptInterface
import org.json.JSONObject

class AndroidBridge(
    private val uid: String,
    private val appId: String,
    private val tableName: String,
    private val backendRoot: String,        // our proxy server — replaces supabaseUrl
    private val apiBaseUrl: String          // full device API base url
) {

    @JavascriptInterface
    fun getConfigJson(): String {
        return JSONObject().apply {
            put("uid",          uid)
            put("app_id",       appId)
            put("table_name",   tableName)
            put("backend_root", backendRoot)    // all JS calls go here
            put("api_base_url", apiBaseUrl)
            // supabase_url and supabase_anon_key intentionally removed
            // JS layer must never talk to Supabase directly
        }.toString()
    }

    @JavascriptInterface
    fun getDeviceUID(): String = uid

    @JavascriptInterface
    fun getAppId(): String = appId

    @JavascriptInterface
    fun getTableName(): String = tableName

    @JavascriptInterface
    fun getBackendRoot(): String = backendRoot

    @JavascriptInterface
    fun getApiBaseUrl(): String = apiBaseUrl
}
