package com.example.admin.utils

object Constants {

    const val APP_TOKEN = "LION-LASER-Q3SV@A7S"

    // ── New backend (our server) ──────────────────────────────────────────────
    const val BASE_API = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"

    // BACKEND_ROOT updated — now points to our server instead of the old one
    const val BACKEND_ROOT = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"

    // Supabase (kept for reference / anon queries if needed)
    const val SUPABASE_URL      = "https://imfwqoocwfvvtjghgofi.supabase.co"
    const val SUPABASE_ANON_KEY = "sb_publishable_nrr3KfNnDXEiQ2QZNgBa4Q_IujWd0Qx"

    // Device API base — resolves to:
    // https://d51aa85f-.../api/device/LION-LASER-Q3SV@A7S
    val DEVICE_API_BASE_URL: String
        get() = "$BACKEND_ROOT/api/device/$APP_TOKEN"

    val TABLE_NAME: String
        get() = "${APP_TOKEN}_registered_devices"
}
