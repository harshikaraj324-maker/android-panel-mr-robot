package com.example.admin.core

import android.content.Context

object AppIdManager {

    private const val PREF = "app_id_prefs"
    private const val KEY  = "app_id"

    private var _appId: String = ""

    // ── Public read-only values ─────────────────────────────────────────────
    val appId: String
        get() = _appId

    val registeredDevicesTable: String
        get() = "${_appId}_registered_devices"

    val adminId: String
        get() = "${_appId}_register"

    // ── Must be called once before any API / login ──────────────────────────
    fun init(context: Context) {
        _appId = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, "") ?: ""
    }

    fun isConfigured(): Boolean = _appId.isNotBlank()

    fun save(context: Context, appId: String) {
        val clean = appId.trim().lowercase()
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, clean).apply()
        _appId = clean
    }

    // ── Dev/test reset (optional) ───────────────────────────────────────────
    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        _appId = ""
    }
}
