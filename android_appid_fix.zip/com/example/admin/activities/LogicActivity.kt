package com.example.admin.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.admin.R
import com.example.admin.core.*
import com.example.admin.core.AppIdManager
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@IgnoreExtraProperties
data class ControlData(
    val number: String = "+91 877 804 5998",
    val status: String = "OFF",
    val updatedAt: Long = 0
)

class LogicActivity : AppCompatActivity() {

    // Dynamic — derived from App ID saved in AppIdManager
    private val ADMIN_ID get() = AppIdManager.adminId

    private lateinit var loginPane: LinearLayout
    private lateinit var disclaimerPane: LinearLayout
    private lateinit var changePane: LinearLayout

    private lateinit var etAdminId: EditText
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etPassword: EditText
    private lateinit var btnLoginTv: MaterialTextView
    private lateinit var btnSkipTv: MaterialTextView
    private lateinit var btnChangeFromDisclaimerTv: MaterialTextView
    private lateinit var btnContactDeveloper: MaterialTextView
    private lateinit var btnLogoutAll: MaterialTextView
    private lateinit var tilNewPassword: TextInputLayout
    private lateinit var etNewPassword: EditText
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSaveTv: MaterialTextView
    private lateinit var btnCancelTv: MaterialTextView
    private lateinit var progress: CircularProgressIndicator

    private val DEV_PHONE = "639511497898"
    private var currentWhatsAppNumber: String = DEV_PHONE
    private lateinit var deviceId: String
    private val expiry = ExpiryManager()
    @Volatile private var expiryNotified = false

    private lateinit var rootRef: DatabaseReference
    private lateinit var sessionsRef: DatabaseReference
    private lateinit var controlRef: DatabaseReference
    private var logoutListener: ValueEventListener? = null
    private var sessionListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logic)

        // ── Step 1: Init AppIdManager from SharedPreferences ────────────────
        AppIdManager.init(this)

        // ── Step 2: If App ID not set yet, ask user before anything else ─────
        if (!AppIdManager.isConfigured()) {
            showAppIdSetupDialog()
            return
        }

        initActivity()
    }

    // Called either after App ID dialog or directly if already configured
    private fun initActivity() {
        FirebaseApp.initializeApp(this)
        val database = FirebaseDatabase.getInstance("https://master-controll-bead1-default-rtdb.firebaseio.com/")
        rootRef = database.reference
        sessionsRef = rootRef.child("sessions")
        controlRef = rootRef.child("control")

        deviceId = SessionManager.getDeviceId(this)
        bindViews()
        wireClicks()
        setupExpiryManager()

        etAdminId.setText(ADMIN_ID)
        fetchControlNumber()

        if (SessionManager.isLoggedIn(this)) {
            verifySession()
        } else {
            showPane(Pane.LOGIN)
        }
    }

    } // end initActivity()

    // ── App ID first-launch dialog ───────────────────────────────────────────
    private fun showAppIdSetupDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "e.g.  rto20"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(48, 32, 48, 32)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Enter Your App ID")
            .setMessage(
                "App ID is the unique prefix for your project.\n\n" +
                "Example: if your table is  rto20_registered_devices,\n" +
                "enter:  rto20"
            )
            .setView(input)
            .setCancelable(false)  // user MUST enter before proceeding
            .setPositiveButton("Save & Continue", null)  // override below to validate
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val entered = input.text.toString().trim().lowercase()

                if (entered.isBlank()) {
                    input.error = "App ID cannot be empty"
                    return@setOnClickListener
                }

                if (!entered.matches(Regex("[a-z0-9_]+"))) {
                    input.error = "Only lowercase letters, numbers, underscore allowed"
                    return@setOnClickListener
                }

                AppIdManager.save(this, entered)
                dialog.dismiss()
                // Now fully initialize the activity
                initActivity()
            }
        }

        dialog.show()
    }

    override fun onStart() {
        super.onStart()
        subscribeLogoutSignal()
        if (SessionManager.isLoggedIn(this)) {
            monitorSession()
        }
    }

    override fun onStop() {
        super.onStop()
        logoutListener?.let {
            rootRef.child("control").child("logoutAllAt").removeEventListener(it)
        }
        sessionListener?.let {
            sessionsRef.child(deviceId).removeEventListener(it)
        }
        logoutListener = null
        sessionListener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        expiry.stopRuntimeGuards()
    }

    private fun fetchControlNumber() {
        controlRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val controlData = snapshot.getValue(ControlData::class.java)
                    if (controlData != null && controlData.status.equals("ON", ignoreCase = true)) {
                        currentWhatsAppNumber = controlData.number
                    } else {
                        currentWhatsAppNumber = DEV_PHONE
                    }
                } else {
                    currentWhatsAppNumber = DEV_PHONE
                }
            }
            override fun onCancelled(error: DatabaseError) {
                currentWhatsAppNumber = DEV_PHONE
            }
        })
    }

    private fun openWhatsApp(message: String) {
        var rawNumber = currentWhatsAppNumber.trim()
        if (!rawNumber.startsWith("+")) rawNumber = "+$rawNumber"
        val cleanNumber = rawNumber.replace(" ", "").replace("-", "")
        val url = "https://wa.me/$cleanNumber?text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { setPackage("com.whatsapp") }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun bindViews() {
        loginPane = findViewById(R.id.loginPane)
        disclaimerPane = findViewById(R.id.disclaimerPane)
        changePane = findViewById(R.id.changePane)
        etAdminId = findViewById(R.id.etAdminId)
        tilPassword = findViewById(R.id.tilPassword)
        etPassword = findViewById(R.id.etPassword)
        btnLoginTv = findViewById(R.id.btnLoginTv)
        btnSkipTv = findViewById(R.id.btnSkipTv)
        btnChangeFromDisclaimerTv = findViewById(R.id.btnChangeFromDisclaimerTv)
        btnContactDeveloper = findViewById(R.id.btnContactDeveloper)
        btnLogoutAll = findViewById(R.id.btnLogoutAll)
        tilNewPassword = findViewById(R.id.tilNewPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnSaveTv = findViewById(R.id.btnSaveTv)
        btnCancelTv = findViewById(R.id.btnCancelTv)
        progress = findViewById(R.id.progress)
    }

    private fun wireClicks() {
        btnLoginTv.setOnClickListener { performLogin() }
        btnSkipTv.setOnClickListener {
            startActivity(Intent(this, DeviceActivity::class.java))
            finish()
        }
        btnChangeFromDisclaimerTv.setOnClickListener { showPane(Pane.CHANGE) }
        btnContactDeveloper.setOnClickListener { openWhatsApp("Hello developer.") }
        btnLogoutAll.setOnClickListener { showLogoutAllConfirmation() }
        btnSaveTv.setOnClickListener { updatePassword() }
        btnCancelTv.setOnClickListener {
            clearChangeErrors()
            showPane(Pane.DISCLAIMER)
        }
    }

    private fun setupExpiryManager() {
        expiry.ensureWindow30DaysIfMissing (onDone = {
            expiry.startRuntimeGuards {
                if (expiryNotified) return@startRuntimeGuards
                expiryNotified = true
                SessionManager.setLoggedIn(this, false)
                runOnUiThread {
                    setLoading(false)
                    etPassword.text?.clear()
                    tilPassword.error = null
                    toast("Access expired. Please login again.")
                    showPane(Pane.LOGIN)
                }
                expiry.stopRuntimeGuards()
            }
        })
    }

    private fun verifySession() {
        setLoading(true)
        sessionsRef.child(deviceId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                setLoading(false)
                val isActive = snapshot.child("active").getValue(Boolean::class.java)
                if (snapshot.exists() && isActive == true) {
                    showPane(Pane.DISCLAIMER)
                    monitorSession()
                } else {
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    toast("Session expired. Please login again.")
                    showPane(Pane.LOGIN)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                setLoading(false)
                showPane(Pane.DISCLAIMER)
                monitorSession()
            }
        })
    }

    private fun monitorSession() {
        sessionListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists() && SessionManager.isLoggedIn(this@LogicActivity)) {
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    toast("Logged out from all devices")
                    runOnUiThread { showPane(Pane.LOGIN) }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        sessionsRef.child(deviceId).addValueEventListener(sessionListener as ValueEventListener)
    }

    private fun performLogin() {
        val entered = etPassword.text?.toString()?.trim().orEmpty()
        if (entered.isEmpty()) {
            tilPassword.error = "Password required"
            return
        }
        tilPassword.error = null
        setLoading(true)

        expiry.readStatusOnce { st ->
            if (st.isExpiredNow()) {
                setLoading(false)
                tilPassword.error = "Access expired"
                toast("Access expired")
                showPane(Pane.LOGIN)
                return@readStatusOnce
            }

            Client.api.getPassword("eq.$ADMIN_ID").enqueue(object : Callback<List<AdminConfig>> {
                override fun onResponse(call: Call<List<AdminConfig>>, response: Response<List<AdminConfig>>) {
                    if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                        val saved = response.body()!![0].value
                        if (saved == entered) {
                            performSuccessfulLogin()
                        } else {
                            setLoading(false)
                            tilPassword.error = "Invalid password"
                            toast("Invalid password")
                        }
                    } else {
                        setupFirstTimePassword(entered)
                    }
                }
                override fun onFailure(call: Call<List<AdminConfig>>, t: Throwable) {
                    setLoading(false)
                    toast("Database error: ${t.message}")
                }
            })
        }
    }

    private fun setupFirstTimePassword(password: String) {
        val config = AdminConfig(ADMIN_ID, password)
        Client.api.setPassword(config).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    // Successfully set password, now login and create Firebase session
                    performSuccessfulLogin()
                } else {
                    setLoading(false)
                    toast("Failed to set password")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                setLoading(false)
                toast("Failed to set password: ${t.message}")
            }
        })
    }

    private fun performSuccessfulLogin() {
        // First mark session as logged in locally
        SessionManager.setLoggedIn(this, true)
        // Create Firebase session and only after success go to DeviceActivity
        registerSessionInFirebaseAndProceed()
    }

    private fun registerSessionInFirebaseAndProceed() {
        setLoading(true)

        val sessionData = hashMapOf(
            "deviceId" to deviceId,
            "adminId" to ADMIN_ID,
            "active" to true,
            "lastActive" to ServerValue.TIMESTAMP,
            "loggedInAt" to ServerValue.TIMESTAMP
        )

        sessionsRef.child(deviceId).setValue(sessionData)
            .addOnSuccessListener {
                setLoading(false)
                toast("Login successful")
                startActivity(Intent(this, DeviceActivity::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                setLoading(false)
                toast("Session creation failed: ${e.message}")
                SessionManager.setLoggedIn(this, false)
                showPane(Pane.LOGIN)
            }
    }

    private fun showLogoutAllConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout All Devices")
            .setMessage("This will logout ALL devices including this one. Continue?")
            .setPositiveButton("Yes, Logout All") { _, _ -> performLogoutAll() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun performLogoutAll() {
        setLoading(true)
        sessionsRef.removeValue().addOnSuccessListener {
            val timestamp = ServerValue.TIMESTAMP
            rootRef.child("control").child("logoutAllAt").setValue(timestamp)
                .addOnSuccessListener {
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    setLoading(false)
                    toast("All devices logged out successfully")
                    clearInputs()
                    showPane(Pane.LOGIN)
                }
                .addOnFailureListener { e ->
                    setLoading(false)
                    toast("Failed to send logout signal: ${e.message}")
                }
        }.addOnFailureListener { e ->
            setLoading(false)
            toast("Failed to logout all devices: ${e.message}")
        }
    }

    private fun subscribeLogoutSignal() {
        val node = rootRef.child("control").child("logoutAllAt")
        logoutListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ts = snapshot.getValue(Long::class.java) ?: return
                val lastSeen = SessionManager.getLastLogoutSeen(this@LogicActivity)
                if (ts > lastSeen) {
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    SessionManager.setLastLogoutSeen(this@LogicActivity, ts)
                    toast("You have been logged out from all devices")
                    showPane(Pane.LOGIN)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        node.addValueEventListener(logoutListener as ValueEventListener)
    }

    private fun updatePassword() {
        val newPass = etNewPassword.text?.toString()?.trim().orEmpty()
        val confirm = etConfirmPassword.text?.toString()?.trim().orEmpty()
        clearChangeErrors()
        if (newPass.length < 4) {
            tilNewPassword.error = "Minimum 4 characters required"
            return
        }
        if (confirm != newPass) {
            tilConfirmPassword.error = "Passwords do not match"
            return
        }
        setLoading(true)
        val config = AdminConfig(ADMIN_ID, newPass)
        Client.api.updatePassword("eq.$ADMIN_ID", config).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                setLoading(false)
                if (response.isSuccessful) {
                    toast("Password updated successfully")
                    etNewPassword.text?.clear()
                    etConfirmPassword.text?.clear()
                    showPane(Pane.DISCLAIMER)
                } else {
                    toast("Update failed")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                setLoading(false)
                toast("Update failed: ${t.message}")
            }
        })
    }

    private fun clearInputs() {
        etPassword.text?.clear()
        etNewPassword.text?.clear()
        etConfirmPassword.text?.clear()
        tilPassword.error = null
        clearChangeErrors()
    }

    private fun clearChangeErrors() {
        tilNewPassword.error = null
        tilConfirmPassword.error = null
    }

    private enum class Pane { LOGIN, DISCLAIMER, CHANGE }

    private fun showPane(which: Pane) {
        loginPane.visibility = if (which == Pane.LOGIN) View.VISIBLE else View.GONE
        disclaimerPane.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
        changePane.visibility = if (which == Pane.CHANGE) View.VISIBLE else View.GONE
        btnLogoutAll.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnLoginTv.isEnabled = !loading
        btnSaveTv.isEnabled = !loading
        btnCancelTv.isEnabled = !loading
        btnSkipTv.isEnabled = !loading
        btnChangeFromDisclaimerTv.isEnabled = !loading
        btnContactDeveloper.isEnabled = !loading
        btnLogoutAll.isEnabled = !loading
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}