package com.example.admin.core

import android.content.Context
import com.example.admin.utils.Constants

object AppIdManager {

    val appId: String
        get() = Constants.APP_TOKEN

    val adminId: String
        get() = Constants.APP_TOKEN

    val registeredDevicesTable: String
        get() = "${Constants.APP_TOKEN}_registered_devices"

    /** No-op — APP_TOKEN is fixed in Constants, no dialog needed. */
    fun init(context: Context) {}

    /** Always configured. */
    fun isConfigured(): Boolean = true

    /** No-op. */
    fun save(context: Context, id: String) {}
}
