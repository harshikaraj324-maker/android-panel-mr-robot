package com.example.admin.utils

object Constants {

    // ── App Token (identifies which App ID this device belongs to) ────────────
    const val APP_TOKEN = "LION-LASER-Q3SV@A7S"

    // ── Backend proxy — ALL data goes through here, nothing direct to Supabase ─
    // Android app talks ONLY to this server. Server handles Supabase internally.
    const val BACKEND_ROOT = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"

    // Device API base URL — resolves to:
    // https://d51aa85f-.../api/device/LION-LASER-Q3SV@A7S
    val DEVICE_API_BASE_URL: String
        get() = "$BACKEND_ROOT/api/device/$APP_TOKEN"

    val TABLE_NAME: String
        get() = "${APP_TOKEN}_registered_devices"

    // ── SUPABASE CREDENTIALS ARE INTENTIONALLY REMOVED ────────────────────────
    // Direct Supabase access from the app is a security risk.
    // All requests go through BACKEND_ROOT which uses the service role key
    // server-side only. The backend validates every request before touching DB.
}
