package com.example.admin.core

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings
import java.util.UUID

object SessionManager {
    private const val PREF = "logic_session_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_LAST_LOGOUT_SEEN = "last_logout_seen"
    private const val KEY_DEVICE_ID = "device_id"

    fun isLoggedIn(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY_IS_LOGGED_IN, false)

    fun setLoggedIn(ctx: Context, value: Boolean) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_IS_LOGGED_IN, value).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun getLastLogoutSeen(ctx: Context): Long =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong(KEY_LAST_LOGOUT_SEEN, 0L)

    fun setLastLogoutSeen(ctx: Context, ts: Long) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_LOGOUT_SEEN, ts).apply()
    }

    fun getDeviceId(ctx: Context): String {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        var id = sp.getString(KEY_DEVICE_ID, null)
        if (id.isNullOrBlank()) {
            val androidId = try {
                Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
            } catch (e: Exception) { null }
            id = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") "dev_$androidId"
                 else "dev_${UUID.randomUUID()}"
            sp.edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun forceLogoutAndGoTo(activity: Activity, loginActivityClass: Class<out Activity>) {
        setLoggedIn(activity, false)
        activity.startActivity(
            Intent(activity, loginActivityClass).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
        )
        activity.finish()
    }
}
