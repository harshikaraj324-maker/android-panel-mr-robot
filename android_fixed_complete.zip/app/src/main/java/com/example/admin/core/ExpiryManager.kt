package com.example.admin.core

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import com.google.firebase.database.*

class ExpiryManager {
    companion object {
        private const val TAG = "ExpiryManager"
        private const val THIRTY_DAYS_MS = 30L * 24 * 60 * 60 * 1000
    }

    data class Status(
        val startAt: Long? = null, val endAt: Long? = null,
        val expired: Boolean? = null, val expiredAt: Long? = null,
        val sealed: Boolean? = null, val sealedAt: Long? = null
    ) {
        fun isExpiredNow(): Boolean {
            val now = System.currentTimeMillis()
            return expired == true || (endAt != null && now >= endAt)
        }
        fun millisLeft(): Long = ((endAt ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val db: DatabaseReference = FirebaseDatabase.getInstance().getReference("expiry")
    private val bgThread = HandlerThread("expiry-guard-thread").apply { start() }
    private val bg = Handler(bgThread.looper)
    private var runtimeListener: ValueEventListener? = null
    private var expireRunnable: Runnable? = null
    @Volatile private var firedExpireCallback = false

    fun readStatusOnce(cb: (Status) -> Unit) {
        db.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) { ui.post { cb(snapshot.toStatusSafe()) } }
            override fun onCancelled(error: DatabaseError) { Log.e(TAG, "readStatusOnce: ${error.message}"); ui.post { cb(Status()) } }
        })
    }

    fun ensureWindow30DaysIfMissing(onDone: (() -> Unit)? = null) {
        db.runTransaction(object : Transaction.Handler {
            override fun doTransaction(m: MutableData): Transaction.Result {
                if (m.child("startAt").value != null && m.child("endAt").value != null) return Transaction.success(m)
                val now = System.currentTimeMillis()
                m.child("startAt").value = now; m.child("endAt").value = now + THIRTY_DAYS_MS
                m.child("expired").value = false; m.child("expiredAt").value = null
                m.child("sealed").value = true; m.child("sealedAt").value = now
                return Transaction.success(m)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) Log.e(TAG, "ensureWindow: ${error.message}")
                onDone?.invoke()
            }
        })
    }

    fun startRuntimeGuards(onExpire: () -> Unit) {
        stopRuntimeGuards(); firedExpireCallback = false
        runtimeListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val status = snapshot.toStatusSafe()
                if (status.startAt == null || status.endAt == null) { ensureWindow30DaysIfMissing(); return }
                if (status.isExpiredNow()) {
                    markExpiredIfNeeded { if (!firedExpireCallback) { firedExpireCallback = true; ui.post { onExpire() } } }
                } else { scheduleExpireAt(status.endAt, onExpire) }
            }
            override fun onCancelled(error: DatabaseError) { Log.e(TAG, "runtime guard: ${error.message}") }
        }
        db.addValueEventListener(runtimeListener as ValueEventListener)
    }

    fun stopRuntimeGuards() {
        runtimeListener?.let { db.removeEventListener(it) }; runtimeListener = null
        expireRunnable?.let { bg.removeCallbacks(it) }; expireRunnable = null
    }

    fun shutdown() { stopRuntimeGuards(); try { bgThread.quitSafely() } catch (_: Throwable) {} }

    private fun scheduleExpireAt(endAt: Long?, onExpire: () -> Unit) {
        if (endAt == null) return
        expireRunnable?.let { bg.removeCallbacks(it) }
        val delay = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)
        expireRunnable = Runnable { markExpiredIfNeeded { if (!firedExpireCallback) { firedExpireCallback = true; ui.post { onExpire() } } } }
        bg.postDelayed(expireRunnable!!, delay)
    }

    private fun markExpiredIfNeeded(onDone: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        db.runTransaction(object : Transaction.Handler {
            override fun doTransaction(m: MutableData): Transaction.Result {
                val expired = m.child("expired").getValue(Boolean::class.java) == true
                val endAt = m.child("endAt").longValue()
                if (!expired && endAt != null && now >= endAt) { m.child("expired").value = true; m.child("expiredAt").value = now }
                return Transaction.success(m)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) { if (error != null) Log.e(TAG, "markExpired: ${error.message}"); onDone?.invoke() }
        })
    }

    fun reset30Days(onDone: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        db.setValue(mapOf("startAt" to now, "endAt" to now + THIRTY_DAYS_MS, "expired" to false, "expiredAt" to null, "sealed" to true, "sealedAt" to now))
            .addOnCompleteListener { onDone?.invoke() }
    }

    @Deprecated("Use ensureWindow30DaysIfMissing()") fun ensureWindow32DaysIfMissing(onDone: (() -> Unit)? = null) = ensureWindow30DaysIfMissing(onDone)
    @Deprecated("Use ensureWindow30DaysIfMissing()") fun ensureWindow2MinutesIfMissing(onDone: (() -> Unit)? = null) = ensureWindow30DaysIfMissing(onDone)
    @Deprecated("Use reset30Days()") fun reset32Days(onDone: (() -> Unit)? = null) = reset30Days(onDone)
    @Deprecated("Use reset30Days()") fun reset2Minutes(onDone: (() -> Unit)? = null) = reset30Days(onDone)

    private fun DataSnapshot.toStatusSafe() = Status(long("startAt"), long("endAt"), bool("expired"), long("expiredAt"), bool("sealed"), long("sealedAt"))
    private fun DataSnapshot.long(key: String): Long? = child(key).value?.let { v -> when(v) { is Long->v; is Int->v.toLong(); is Double->v.toLong(); is Float->v.toLong(); is String->v.toLongOrNull(); else->null } }
    private fun MutableData.longValue(): Long? = value?.let { v -> when(v) { is Long->v; is Int->v.toLong(); is Double->v.toLong(); is Float->v.toLong(); is String->v.toLongOrNull(); else->null } }
    private fun DataSnapshot.bool(key: String): Boolean? = child(key).value?.let { v -> when(v) { is Boolean->v; is String->v.equals("true",true)||v=="1"; is Number->v.toInt()!=0; else->null } }
}
