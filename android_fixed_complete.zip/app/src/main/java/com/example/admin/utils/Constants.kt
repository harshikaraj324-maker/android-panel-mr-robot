package com.example.admin.utils

import android.content.Context

object Constants {

    private const val PREF      = "app_constants_prefs"
    private const val KEY_TOKEN = "app_token"

    const val BACKEND_ROOT = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"

    private var _appToken: String = ""

    val APP_TOKEN: String
        get() = _appToken

    val DEVICE_API_BASE_URL: String
        get() = "$BACKEND_ROOT/api/device/$APP_TOKEN"

    val TABLE_NAME: String
        get() = "${APP_TOKEN}_registered_devices"

    fun init(context: Context) {
        _appToken = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "") ?: ""
    }

    fun saveToken(context: Context, token: String) {
        _appToken = token.trim().uppercase()
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_TOKEN, _appToken).apply()
    }

    fun isConfigured(): Boolean = _appToken.isNotBlank()

    fun clear(context: Context) {
        _appToken = ""
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
