package com.example.admin.core

import android.content.Context
import com.example.admin.utils.Constants

object AppIdManager {

    val appId: String
        get() = Constants.APP_TOKEN

    val registeredDevicesTable: String
        get() = Constants.TABLE_NAME

    val adminId: String
        get() = "${Constants.APP_TOKEN}_register"

    fun init(context: Context) = Constants.init(context)

    fun isConfigured(): Boolean = Constants.isConfigured()

    fun save(context: Context, appId: String) = Constants.saveToken(context, appId)

    fun clear(context: Context) = Constants.clear(context)
}
