COMPLETE ANDROID PACKAGE — 7 FILES — ALL ERRORS FIXED
=======================================================

ERRORS FIXED:
  ✓ Unresolved reference 'APP_TOKEN'          — Constants.kt now dynamic (SharedPrefs)
  ✓ Unresolved reference 'DEVICE_API_BASE_URL' — works because APP_TOKEN is a val getter
  ✓ Unresolved reference 'tilCurrentPassword'  — activity_logic.xml now has this field
  ✓ Unresolved reference 'etCurrentPassword'   — activity_logic.xml now has this field

HOW APP TOKEN SETUP WORKS:
  • First launch → dialog appears asking user to enter their App Token
  • User types e.g. "LION-LASER-Q3SV@A7S" → saved to SharedPreferences
  • All future launches skip the dialog and use the saved token
  • To change token: call Constants.clear(context) and restart

FILES:
  utils/Constants.kt
    - APP_TOKEN is now a var backed by SharedPreferences (no hardcoded value)
    - Call Constants.init(context) on app start (LogicActivity does this)
    - BACKEND_ROOT stays hardcoded (same for all users)

  core/AppIdManager.kt
    - Delegates to Constants — backward compatible for any code using AppIdManager

  activities/LogicActivity.kt
    - Calls Constants.init(this) on onCreate
    - Shows token setup dialog if token not saved yet
    - Login/password change via backend API

  network/SupabaseApi.kt
    - Zero Supabase credentials — all calls via BACKEND_ROOT
    - Uses Constants.DEVICE_API_BASE_URL which picks up the saved APP_TOKEN

  res/layout/activity_logic.xml
    - Contains tilCurrentPassword + etCurrentPassword (fixes compile errors)
    - Contact Developer button removed

  core/SessionManager.kt   — unchanged
  core/ExpiryManager.kt    — unchanged

YOUR Constants.kt SHOULD NOW LOOK LIKE THIS:
  package com.example.admin.utils
  import android.content.Context
  object Constants {
      private const val PREF = "app_constants_prefs"
      private const val KEY_TOKEN = "app_token"
      const val BACKEND_ROOT = "https://d51aa85f-07df-422f-b7d0-9f6efd2785d9-00-9sesenw57uo6.sisko.replit.dev"
      private var _appToken: String = ""
      val APP_TOKEN: String get() = _appToken
      val DEVICE_API_BASE_URL: String get() = "$BACKEND_ROOT/api/device/$APP_TOKEN"
      val TABLE_NAME: String get() = "${APP_TOKEN}_registered_devices"
      fun init(context: Context) { _appToken = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_TOKEN, "") ?: "" }
      fun saveToken(context: Context, token: String) { _appToken = token.trim().uppercase(); context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_TOKEN, _appToken).apply() }
      fun isConfigured(): Boolean = _appToken.isNotBlank()
      fun clear(context: Context) { _appToken = ""; context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply() }
  }
